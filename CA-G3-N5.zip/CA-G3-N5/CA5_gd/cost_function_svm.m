function cost = cost_function_svm(X, y_labels__linear_indices, W, hyper_par)


n_out     = size(W,1);
n_samples = size(X,2);

% computing the SVM cost-function (multi-class)
% score function, cf. http://cs231n.github.io/linear-classify/#svm
S_all     = W * X; 
S_y       = zeros(size(S_all));
S_y(:,:)  = repmat(S_all(y_labels__linear_indices).', [n_out, 1]); 

margins_mat                           = max(0.0, S_all - S_y + hyper_par.delta);
margins_mat(y_labels__linear_indices) = 0;
L_unreg__per_sample                   = sum(margins_mat, 1) ;
cost                                  = (sum(L_unreg__per_sample)./n_samples) + hyper_par.lambda/2 * W(:)'*W(:); 

