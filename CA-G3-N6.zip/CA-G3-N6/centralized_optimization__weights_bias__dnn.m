function [W, b, grad_struct, grad_prev_struct, E_abs_square_avg, avg_index] ...
    = centralized_optimization__weights_bias__dnn(X_train, Y_train, n_train, mini_batch_size, mini_batch_rng_gen, ...
    X_test,y_test,n_test,...
    loss_function,...
    W, b, bias_enable_flag, batch_norm_flag, dropout_percent, ...
    z, z_prime, h,...
    a_fun, da_fun, hyperparameters_activation_function, ...
    select_optimization_method, step_struct, step_size_method, grad_prev_struct, ...
    regularization_factor, regularization_type,...
    nrof_nodes_output,nrof_nodes_vec,nrof_hidden_layers,nrof_total_layers,...
    nrof_epochs, epoch_count,...
    E_abs_square_avg, avg_index, enable_online_plotting,file_name)

% Initialize
if epoch_count==1
    res.E_abs_square_avg_over_epoch         = zeros(nrof_epochs, nrof_nodes_output);
    res.classification_accuracy_over_epoch  = zeros(nrof_epochs, 1);
end

%
for lyr = 1:nrof_hidden_layers
    z{lyr}           = zeros(nrof_nodes_vec(lyr+1),mini_batch_size); % output after activation
    h{lyr}           = zeros(nrof_nodes_vec(lyr+1),mini_batch_size); % output before activation
    z_prime{lyr}     = ones(nrof_nodes_vec(lyr+1),mini_batch_size); % output with gradient of the activation
    %diagZ_prime{lyr} = zeros(nrof_nodes_vec(lyr+1), nrof_nodes_vec(lyr+1), mini_batch_size); % output with gradient of the activation
end

%% Sanity Checks
assert((dropout_percent>=0) && (dropout_percent <= 100))

%% divide the data set into appropraite nr of mini-batch sizes

rng(mini_batch_rng_gen);

train_data_rand_indices_set = randperm(n_train, n_train);
perm_indices__set           = buffer(train_data_rand_indices_set, mini_batch_size);

nrof_mini_batches           = size(perm_indices__set, 2);
% if epoch_count==1
%     abs_E_n_per_set  = nan(nrof_epochs, nrof_mini_batches, mini_batch_size, nrof_nodes_output);
% end

%% Weights and Biases Update during training mode

%update_flag = true; % in case of weights and biases updates
t_outer       = tic;
training_mode = true;
training_mode_mini = false; %#ok<NASGU> % used in the mini-batch accuracy
classification_accuracy_mini = zeros(1,nrof_mini_batches); % Save the mini-batch accuracy

% Save previous written information in a file
% res_file_name = strcat('results/',file_name);
fid=fopen(fullfile('result','info',convertStringsToChars(file_name)),'a');
% Save information of mini-batch in a file
file_name_inner = convertStringsToChars(file_name);
file_name_inner(end-3:end) = [];
file_name_inner = strcat(file_name_inner,'_mBatch.txt');
% res_file_name_inner = strcat('results/',file_name_inner);
fid_inner = fopen(fullfile('result','info',file_name_inner),'a');

%profile on;
for t = 1:nrof_mini_batches % [parallelize this loop for decentralized set-up]
    %t_inner = tic;
    if mod(t,100)==0 
        fprintf('nr of minibatches so far=%d \n',t);
    end
    
    % randomly select the mini-batch sizes for the training ...
    % (should be non-overlapping)
    [perm_indices]      = perm_indices__set(:, t);
    X_train__mini_batch = X_train(:,perm_indices);
    Y_train__mini_batch = Y_train(:,perm_indices);
    
    % initialize
    Y_pred__mini_batch  = nan(size(Y_train__mini_batch));
    
    % PREDICTION (feedforward)
    [Y_pred__mini_batch(:,:), h, z, z_prime] = dnn__prediction(X_train__mini_batch, W, b, ...
        bias_enable_flag, mini_batch_size, nrof_total_layers, batch_norm_flag, dropout_percent, ...
        h, z, z_prime, ...
        a_fun, da_fun, hyperparameters_activation_function, training_mode);
    
    % =================================================================
    % error to be utilized for updating Weights & Biases (parameters)
    % =================================================================
    % compute output layer error: (Y - T)
    E_n  = Y_pred__mini_batch(:,:) - Y_train__mini_batch(:,:);
    
    
    % logger (for the cost computation)
    %abs_E_n_per_set(epoch_count, t,:,:) = abs(E_n).';
    [E_abs_square_avg, avg_index]       = recursive_average(E_abs_square_avg, mean(abs(E_n).^2,2), avg_index);
    
    % =================================================================
    % Update the weights and biases (after gradient computation--back propagation)
    % =================================================================            
    switch lower(loss_function)        
        case {'ce'; 'cross_entropy'} % ce: cross-entropy loss
            p       = Y_pred__mini_batch;            
            A       = (outer_product_1dvecsx_1dvecsx (p , ones(size(p))) - eye(size(nrof_nodes_output)));
            t_tilde = mul_2dmatsx_1dvecsx(A,Y_train__mini_batch);
                        
        otherwise % by default {'se'; 'mse'; 'ls'; 'squared_error'; 'least_squares'} % se: squared error; mse: mean squared error; ls: least-squares            
            t_tilde = E_n;
        
    end
    grad_struct = compute_gradients_for_deep_neural_network_ver2(t_tilde, X_train__mini_batch, W, b, z, z_prime, mini_batch_size,...
        nrof_total_layers, regularization_factor, regularization_type);
    
        
    % Now update the weights and biases
    switch lower(select_optimization_method)
        case 'sgd' % sequential SGD
            kk_inner            = t; % valid for sequential
            [W, b, step_struct] = sgd(W, b, grad_struct, step_struct, step_size_method, kk_inner, avg_index, nrof_total_layers);            
        case 'rmsprop' % averaged version of adagrad
            kk_inner            = t; % valid for sequential
            [W, b, step_struct, grad_prev_struct] = rmsprop_ver2(W, b, grad_struct, grad_prev_struct, step_struct, step_size_method, kk_inner, avg_index, nrof_total_layers);
        case 'adagrad' %
            kk_inner            = t; % valid for sequential
            [W, b, step_struct, grad_prev_struct] = adagrad_ver2(W, b, grad_struct, grad_prev_struct, step_struct, step_size_method, kk_inner, avg_index, nrof_total_layers);
        case 'adam'
            error('not supported yet');
    end
    
    % just for debugging... online plotting: caveat --> slow
    if 1 %mod(t,100)==0
        figure(1);
        switch 1
            case (avg_index==1)
                clf;
        end
        semilogy(avg_index, E_abs_square_avg, 'o');
        hold on;
        drawnow;
        xlabel('nr of iterations');
        ylabel('training squared-error loss: |y-t|^2');
        name_fig=strcat('MSE_NrOfMiniBatches',num2str(epoch_count),'_',select_optimization_method);
        cd result/plot;
        savefig(name_fig);
        cd ../../;
        switch 1
            case enable_online_plotting.inner_loop==false                
                close;
        end
        
        % ================================
        % Validating the result with every mini-batch
        % ================================
        % flush these intermediate variables
        for lyr = 1:nrof_hidden_layers
            z_test{lyr}           = zeros(nrof_nodes_vec(lyr+1),n_test); % output after activation
            h_test{lyr}           = zeros(nrof_nodes_vec(lyr+1),n_test); % output before activation
            z_prime_test{lyr}     = ones(nrof_nodes_vec(lyr+1),n_test); % output with gradient of the activation
            %diagZ_prime{lyr} = zeros(nrof_nodes_vec(lyr+1), nrof_nodes_vec(lyr+1), n_test); % output with gradient of the activation
        end
        
        training_mode = false; % it is testing mode
        [Y_pred__test_data] = dnn__prediction(X_test, W, b, bias_enable_flag, size(X_test,2), nrof_total_layers, batch_norm_flag, dropout_percent, ...
            h_test, z_test, z_prime_test,  ...
            a_fun, da_fun, hyperparameters_activation_function, training_mode);
        [~, y_pred__final]    = max(Y_pred__test_data, [], 1);
        y_pred__final         = (y_pred__final-1).';
        [ind, ~]             = find(y_pred__final==y_test);
        classification_accuracy = (numel(ind)/numel(y_test))*100;
        fprintf('classification accuracy (%d epoch) = %1.2f\n', epoch_count, classification_accuracy);
        
        % just for debugging... online plotting: caveat --> slow
        figure(4);
        switch 1
            case (avg_index==1)
                clf;
        end
        plot(avg_index, classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('nr of iterations');
        ylabel('(test) classification accuracy [%]');
        name_fig=strcat('Test_Classification_accuracy_vs_Epoch',num2str(avg_index),'_',select_optimization_method);
        cd result/plot;
        savefig(name_fig);
        cd ../../;
        switch 1
            case enable_online_plotting.outer_loop==false
                close;
        end
        
    end
    
    % Print the result of the test accuracy after this mini-batch update
    %training_accuracy_minibatch;
%     toc(t_inner);
    
end % of t: mini batches
toc(t_outer);

% just for debugging... online plotting: caveat --> slow
figure(2);
switch 1
    case (epoch_count==1)
        clf;
end
semilogy(epoch_count, E_abs_square_avg, 'o');
%semilogy(epoch_count, squeeze(mean(mean(abs_E_n_per_set(epoch_count,:,:,:),3),2)).^2, 'o');
hold on;
drawnow;
xlabel('nr of epochs');
ylabel('mse: |y - t|^2');
name_fig=strcat('MSE_Epoch',num2str(epoch_count),'_',select_optimization_method);
cd result/plot;
savefig(name_fig);
cd ../../;
switch 1
    case enable_online_plotting.outer_loop==false        
        close;
end

%% Validate the result with the updated weights and biases

%update_flag = false; % in case of weights and biases updates

% flush these intermediate variables
for lyr = 1:nrof_hidden_layers
    z{lyr}           = zeros(nrof_nodes_vec(lyr+1),n_test); % output after activation
    h{lyr}           = zeros(nrof_nodes_vec(lyr+1),n_test); % output before activation
    z_prime{lyr}     = ones(nrof_nodes_vec(lyr+1),n_test); % output with gradient of the activation
    %diagZ_prime{lyr} = zeros(nrof_nodes_vec(lyr+1), nrof_nodes_vec(lyr+1), n_test); % output with gradient of the activation
end

training_mode = false; % it is testing mode
[Y_pred__test_data] = dnn__prediction(X_test, W, b, bias_enable_flag, size(X_test,2), nrof_total_layers, batch_norm_flag, dropout_percent, ...
    h, z, z_prime,  ...
    a_fun, da_fun, hyperparameters_activation_function, training_mode);
[~, y_pred__final]    = max(Y_pred__test_data, [], 1);
y_pred__final           = (y_pred__final-1).';
[ind, ~]             = find(y_pred__final==y_test);
classification_accuracy = (numel(ind)/numel(y_test))*100;
fprintf('classification accuracy (%d epoch) = %1.2f\n', epoch_count, classification_accuracy);

%% Save the result every epoch
if enable_online_plotting.outer_loop==false
res.W                       = W;
res.b                       = b;
res.grad                    = grad_struct;
res.E_abs_square_avg        = E_abs_square_avg;
res.E_abs_square_avg_over_epoch(epoch_count,:)      = E_abs_square_avg;
res.classification_accuracy_over_epoch(epoch_count) = classification_accuracy;

save(sprintf('result/cent_%s_%dmini_biasEn%d__%dlyr_dnn.mat',...
    select_optimization_method, mini_batch_size, ...
    bias_enable_flag, nrof_total_layers), '-struct', 'res');

% Save previous written information in a file
fid=fopen(file_name,'a');

fprintf(fid,'Time elapsed (%d epoch) in seconds = %1.2f\n',epoch_count,t_outer);
fprintf(fid,'classification accuracy (%d epoch) = %1.2f\n\n', epoch_count, classification_accuracy);

% Close the file
fclose(fid);
end


% just for debugging... online plotting: caveat --> slow
figure(3);
switch 1
    case (epoch_count==1)
        clf;
end
plot(epoch_count, classification_accuracy, 'o');
hold on;
drawnow;
xlabel('nr of epochs');
ylabel('(test) classification accuracy [%]');
name_fig=strcat('Test_Classification_accuracy_vs_Epoch',num2str(epoch_count),'_',select_optimization_method);
cd result/plot;
savefig(name_fig);
cd ../../;
switch 1
    case enable_online_plotting.outer_loop==false        
        close;
end



end
%%
