function [x_out, signaling_factor] = quantize_sparsify_vector(x_in, parameters, i_node)

signaling_factor   = 1;
switch lower(parameters.sparsify_or_quantize_or_none)
    case 'sparsify'
        [mm, nn]           = size(x_in);
        x_in_vec           = x_in(:);
        x_out_vec          = x_in(:);
        n_len              = length(x_in_vec);
        
        rand_indices_set   = randperm(parameters.seed{i_node}, n_len, n_len);
        perm_indices__set  = rand_indices_set(1:round(n_len * parameters.sparsify_percnt_n_vec/100));
        
        x_out_vec(perm_indices__set) = 0;
        x_out                        = reshape(x_out_vec, [mm, nn]);        
        
        signaling_factor             = parameters.sparsify_percnt_n_vec/100;
    case 'quantize' 
        if ~isinf(parameters.quantization_bits)
            x_out              = quantizenumeric(x_in, 1, parameters.quantization_bits, floor(parameters.quantization_bits*0.5),'round');
            signaling_factor   = 1- 1/parameters.quantization_bits;
        else
            x_out              = x_in;
            signaling_factor   = 1;
        end
    case 'none'
        % do nothing
        x_out = x_in;
    otherwise
        % do nothing
        x_out = x_in;
end