function [labels] = readLabels(labelsFileName)
%READLABELS 

fp = fopen(labelsFileName, 'rb');
assert(fp ~= -1, ['Could not open ', labelsFileName, '']);

magic = fread(fp, 1, 'int32', 0, 'ieee-be');
assert(magic == 2049, ['Bad magic number in ', labelsFileName, '']);

numLabels = fread(fp, 1, 'int32', 0, 'ieee-be');

labels = fread(fp, inf, 'unsigned char');

assert(size(labels,1) == numLabels, 'Mismatch in label count');

fclose(fp);

end

