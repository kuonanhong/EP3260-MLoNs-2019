% Run for the three algorithms when using 9 epochs each
clear;clc;

addpath 'mtimesx_20110223/'; % "borrowed" a fast multiplication of a multi-dimensional matrices
blas_lib = '/Applications/MATLAB_R2018b.app/bin/maci64/libmwblas.dylib';
mex('-DDEFINEUNIX','mtimesx.c',blas_lib);

close all;

%% INPUTS
%%%%%%%%%%%%%%%%%%%%%%%%
% For Single Hidden Layer
%%%%%%%%%%%%%%%%%%%%%%%%
nrof_epochs                = 10;

nrof_hidden_layers         = 1; % not including the input and output layers
nrof_nodes_hidden          = 2000; %[100, 100, 100, 100, 100, 100, 100]; % the length of this row vector should match with nrof_hidden_layers

loss_function              = 'squared_error'; % 'squared_error' 'cross_entropy';

% for 
%activation_functions                = {'se'; 'seLu'; 'se'; 'sigmoid'; 'none'}; %{1 is 'sigmoid', 2 is 'ReLu', and 3 is 'se'
%hyperparameters_activation_function = {1.50;   [];    0.9;     1;       []}; % only used for SE/RBF kernel

activation_functions                = {'SeLu'; 'softmax'}; %{1 is 'sigmoid', 2 is 'ReLu', and 3 is 'se'
hyperparameters_activation_function = {[];       []}; % only used for SE/RBF kernel


regularization_method_number        = 1; % 1: 'nuclear' norm (TBD); 2: 'l2' norm; >3 is no regularization
regularization_factor               = 0.01; 

dropout_percent                     = 0; % 0: no dropout, preferably less than 50
batch_norm_flag                     = false; %'not supported yet'
bias_enable_flag                    = true;

step_size_method_number             = 1; % 1: 'fixed',  2: 'decay_inner' (SGD only), 3: 'decay_outer' (SGD only)
step_size_W_initial                 = 0.1; %225;
step_size_b_initial                 = 0.1; %225;


%% Run all three optimization methods
% SGD
main_ca6_De(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
                   activation_functions,hyperparameters_activation_function,...
                   regularization_method_number, regularization_factor,...
                   batch_norm_flag,bias_enable_flag, dropout_percent, ...
                   step_size_method_number, step_size_W_initial, step_size_b_initial,...
                   1);
              
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
%                   activation_functions,hyperparameters_activation_function,...
%                   loss_function,...
%                   regularization_method_number, regularization_factor,...
%                   batch_norm_flag,bias_enable_flag,dropout_percent,...
%                   step_size_method_number, step_size_W_initial, step_size_b_initial,...
%                   1);
% % RMSprop
% close all;clc;
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
%                   activation_function_number,hyperparameters_activation_function,...
%                   regularization_method_number, regularization_factor,...
%                   batch_norm_flag,bias_enable_flag,...
%                   step_size_method_number, step_size_W_initial, step_size_b_initial,...
%                   3);
% % AdaGrad
% close all;clc;
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
%                   activation_function_number,hyperparameters_activation_function,...
%                   regularization_method_number, regularization_factor,...
%                   batch_norm_flag,bias_enable_flag,...
%                   step_size_method_number, step_size_W_initial, step_size_b_initial,...
%                   2);

