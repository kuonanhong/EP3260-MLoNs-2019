function A = copystruct(A,B)

for fn = fieldnames(B)'
   A.(fn{1}) = B.(fn{1});
end