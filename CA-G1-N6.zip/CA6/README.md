# Computer Assignments in EP3260: Fundamentals of Machine Learning Over Networks

## TL;DR;

1. Install dependencies by running `pip3 install -r requirements.txt`.

## Assignment 6 - Deep neural networks

Defined in [Computer Assignments](https://github.com/hshokrig/EP3260-MLoNs-2019/blob/master/CAs.pdf)

Consider the MNIST dataset. Consider a Deep Neural Network (DNN) with $`J`$ lauers and $`{N_j}` neurons on layer $`j`.

## Datasets

[The MNIST Database](http://yann.lecun.com/exdb/mnist/) of handwritten
digits has 60000 examples and a test set of 10000 examples.

![MNIST](mnist.png)

## Assignments

### a) Train DNN using SGD

> Train DNN using SGD and your choices of hyper-parameters. Report the convergence rate on the training as well as the generalization performance. Feel free to change SGD to any other solver of your choice (give explanation for the choice)
> 


In the figure below we report the results (Loss and accuracy over time and iterations) of a multilayer perceptron trained using SGD and SVRG on the MNIST data set, using a learning rate $`\alpha = 0.01`$, a regularization weight $`\lambda = 0.01`$, and $`l_2`$ normalization, and a batch size of one. 
The network used has two hidden layers with the first having $`400`$ neurons and the second having $`200`$ neurons, trained using cross-entropy loss, with a logistic sigmoid function.

It is obvious that SGD converges to a high loss since it can easily stop to local optimas. 

 
![CA6 results](ca6a.png)

### b) Repeat with mini-batch GD

> Repeat a) with mini-batch GD of your choice of the mini-batchsize, retrain DNN, and show the performance measures. Compare the training performance (speed, accuracy) using various adaptive learning rates (constant, diminishing, AdaGrad, RMSProp).

Below are the results of using a adaptive learning rates with the same hyperparameters as above ($`\lambda = 0.01`$, $`l_2`$ normalization, $`\alpha = 0.01`$, and a batch size of one.), and the same network structure. It is evident that AdaGrad is the only adaptive learning rate method with stable convergence in this setting. 

![Results using adaptive learning rates with a batch size of 1](ca6.B.batch_1.inner_1000.png)

Increasing the batch size serves both to increase the speed of computation per data point, and to reduce the variance of the gradient. When using a batch size of 64, we see a clear improvement for all optimization methods:

![Results using adaptive learning rates with a batch size of 64](ca6.B.batch_64.inner_100.png)

The relatively small improvement we observe by using adaptive learning rates could probably be attributed to the relative simplicity of the MNIST data set, and the rather small network. 


### c) Shallow networks

> Consider design of part a. Fix $`\sum_j N_j`$. Investigate shallower networks (smaller $`J`$) each $`j`$ having potentially more neurons versus deeper network each having fewer neurons per layer, and discuss pros and cons of these two DNN architectures.

Below are the results for different Neural Networks architectures. For this set of experiments, we used the Mini-Batch optimization with 64 batch size and constant learning rate. It is obvious that increasing the neurons improves the accuracy when working on lower number of hidden layers. However, the architecture that has less neurons but more number of hidden layers makes the model to has less accuracy since it doesn't allow to reduce the loss function. 

In the other side of the spectrum, increasing the number of neurons increases the computational cost. 

![CA6c results](ca6c.png)

### d) Master-worker computational graph

> Split the dataset to 6 random disjoint subsets, each for one worker, and repeat part a on master-worker computational graph.

![CA6 distributed results](ca6_dist.png)

### e) Two-star topology

> Consider a two-star topology with communication graph (1,2)-3-4-(5,6). Repeat part a using your choice of distributed optimization solver. You can add communication- efficiency to the iterations, if you like!

See above graph.

### f) Promote sparse solutions

> To promote sparse solutions, you may use l1 regularization or a so-called dropout technique. Explain how you incorporate each of these approaches in the training? Compare their training performance and the size of the final trained models.

See above graph for l1 regularization.


Incorporating $`l_1`$ regularization in the training is relatively straightforward: add a regularization cost $`\sum_i |\theta_i|`$. This cost has as gradient $`\frac{\delta}{\delta \theta_i} \sum_j |\theta_j| = \text{sign}(\theta_i)`$, i.e. each weight is shifted towards zero by the regularization weight $`\lambda`$ in each update. To improve communication cost, one can send only non-zero weights over the network in an appropriate sparse format. For this to be efficient, the sparse format must be smaller than the dense format, which requires that the sparsity must be larger than the overhead induced. 

Another approach is to incorporate dropout during training, which forces some network weights to be zero. This does not directly enforce sparsity in the solution, but rather redundancy, but can be used in a master-worker setting the following way: For each batch, the master samples some dropout mask and sends the corresponding sparse weights to the workers, and collects the resulting sparse gradient.

A third approach is to use a priori sparse networks, for example those proposed in *Scalable training of artifical neural networks with adaptive sparse connectivity inspired by network science* (Mocanu, Decebal Constantin, et.al, Nature). In it, they claim to be able to reduce the number of parameters of a dense network quadratically, with no decrease in accuracy, by sparsifying a dense network structure before training. 

### g) Improving smoothness

> Improving the smoothness of an optimization landscape may substantially improve the convergence properties of first-order iterative algorithms. Batch-normalization is a relatively simple technique to smoothen the landscape. Using the materials of the course, propose an alternative approach to improve the smoothness. Provide numerical justification for the proposed approach.

One direct approach to improve smoothness, at the expense of running time, is to perturb the weights: Given some loss function $`l(x)`$, let $`g(x)`$ be the expectation of $`l(x + n)`$ where $`n`$ is, for example, Gaussian noise. I.e. $`g(x) = \mathbb{E}_{n \sim \mathcal{N}}l(x + n)`$. The gradient of $`g`$ is then the expectation of the gradient of $`l(x + n)`$, which can be approximated using monte-carlo methods. In a master-worker setting, the perturbation could be performed at each worker, limiting the otherwise prohibitive communication costs.

