# CA4: Sensitivity to outliers

**Submitted by Group 3: José Mairton Barros Da Silva Júnior; Xin Zhao; Mohit Mohit Daga; Shashi Kant; Xiaolin Jiang** 

**Direct your emails for clarifications to:** Mohit Daga (mdaga@kth.se)

## Given Questions

1. split “MNIST” dataset to 10 random disjoint P subsets, each for one worker, and consider SVM classifier in the form of $\min_w \sum_{i \in [N]} f_i(w)$ with $N = 10$. Consider the following outlier model: each worker $i$ at every iteration independently and randomly with probability $p$ adds a zero-mean Gaussian noise with a large variance $R$ to the
   information it shares, i.e., $\nabla f_i$ and $w_{j,k}$ in the cases of Algorithm 1 and decentralized sub gradient method respectively.

2. Run decentralized gradient descent (Algorithm 1) with 10 workers. Characterize the convergence against p and R.
   Propose an efficient approach to improve the robustness of Algorithm 1 and characterize its convergence against p and R.
3. Consider a two-star topology with communication graph (1,2,3,4)-5-6-(7,8,9,10) and run decentralized sub gradient method. Characterize the convergence against p and R. Propose an efficient approach to improve the robustness to outliers and characterize its convergence against p and R.
4. Assume that we can protect only three workers in the sense that they would always send the true information. Which workers you protect in Algorithm 1 and which in the two-star topology, running decentralized sub gradient method?

Used Tool : Matlab. Making life easy since childhood :D 

## Solutions

1. Trivial, easy, no explanation required

### 2. Decentralized Gradient Descent

Here, we are asked to characterize the convergence against $p$ and $R$. We do the same with the following figures.

In the below figure, we take different values of $p \in \{0,0.3,0.7,0.9,1.0\}$. We plot the loss function with the number of iterations. Clearly we see a declining loss. 



![distributedGD](/home/mohit/Documents/Course/mlons/CA-G3-N4/Code/distributedGD.bmp)

Below we characterize with different values of $R$, for smaller values we do not see much difference. But as $R$ grows we see greater effect in convergence.

![distributedGD_R](/home/mohit/Documents/Course/mlons/CA-G3-N4/Code/distributedGD_R.bmp)







We now explain the theory behind this experiment. The data of MNIST images is spread across different workers (10) and there is one central/coordination/master node. The role of master node is to gather the gradient from different workers and supply them with the corresponding weights for that particular iteration.

### 3. Decentralized Gradient Descent with Star Topology

Next we are asked to run the same gradient descent in 2-STAR topology, where there are two master nodes each one having 4 workers. The given topology is: (1,2,3,4)-5-6-(7,8,9,10). 

In this kind of topology, the two master nodes (node 5,6) accumulate the gradient from each worker. Lets call this $M_1,M_2$. Suppose in the $k^{th}$, iteration, the master node $M_1$ recieves the gradient information from it's workers, it then uses the gradient information and $k-1^{th}$ gradient from $M_2$ to compute the weights. After computing the weights $M_1$ communicates the aggregated gradient from $M_2$. This reduces the communication complexity of an iteration by an order of $2$ and gives same convergence guarantees. We show the convergence property for different values of $p$ in the following figure

![](/home/mohit/Documents/Course/mlons/CA-G3-N4/Code/distributedGD2-topology.bmp)

### 4. Protecting workers and explanation

If we want to save $3$ nodes we need to save 2 master nodes in the 2-Star topology and one another node. If we need to save three nodes in the first topology then we need to safeguard the master node and two other nodes.



