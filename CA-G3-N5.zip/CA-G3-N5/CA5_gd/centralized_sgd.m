function [res_struct, weights, grad_struct, step_struct] ...
                = centralized_sgd( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_workers, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name)

if epoch_count==1
    res_struct.total_iter_nr         = 0;
    res_struct.total_nr_of_signaling = 0;
end

%% Decompose the training the data for each mini-batch

X_train_per_minibatch             = zeros(nrof_workers, nrof_nodes_input, n_train__per_worker);
Y_train_per_minibatch             = zeros(nrof_workers, nrof_nodes_output, n_train__per_worker);
y_train_lin_indices_per_minibatch = zeros(nrof_workers, 1, n_train__per_worker);

for n_work = 1:nrof_workers
    X_train_per_minibatch(n_work,:,:)             = X_train(:, perm_indices__set(n_work,:));
    Y_train_per_minibatch(n_work,:,:)             = Y_train_matrix__zeros_ones(:, perm_indices__set(n_work,:));       
    y_train_lin_indices_per_minibatch(n_work,:,:) = sub2ind([nrof_nodes_output,n_train__per_worker],y_train_(perm_indices__set(n_work,:)), (1:n_train__per_worker).');

end


%% training on given training-data-set

for inner_iter_nr = 1:nrof_workers
    
    res_struct.total_iter_nr = res_struct.total_iter_nr + 1;
    n_work                   = inner_iter_nr;
        
    %% Prediction
    P                       = prediction_softmax_regression(X_test, weights.W, weights.b, parameters.hyper_par);
    [~, y_pred__final]      = max(P, [], 1);
    y_pred__final           = (y_pred__final).';
    [ind, ~]                = find(y_pred__final==y_test_);
    classification_accuracy = (numel(ind)/numel(y_test_))*100;
    res_struct.classification_accuracy(inner_iter_nr, epoch_count) = classification_accuracy;
    fprintf('classification accuracy (%d epoch) = %1.2f\n', res_struct.total_iter_nr, classification_accuracy);
    
    if enable_online_plotting
        figure(1);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        plot(res_struct.total_iter_nr, classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('nr of iterations');
        ylabel('(test) classification accuracy [%]');
    end
    
    
    %% Training
    
    % run SGD
    switch lower(loss_function)
        case {'softmax'; 'logistic'}
            
            X = squeeze(X_train_per_minibatch(n_work,:,:));
            Y = squeeze(Y_train_per_minibatch(n_work,:,:));
                        
            grad_struct_instant                                     = gradient_softmax_loss_fun(X, Y, weights.W, weights.b, parameters.hyper_par);
            res_struct.loss__per_worker(inner_iter_nr, epoch_count) = cost_softmax(X, Y, weights.W, weights.b, parameters.hyper_par);
                        
        otherwise
            % for multi-class SVM (without bias)
            X                        = squeeze(X_train_per_minibatch(n_work,:,:));
            y_labels__linear_indices = squeeze(y_train_lin_indices_per_minibatch(n_work,:,:));
                        
            grad_struct_instant                                     = subgradient_weight__svm_cost__per_sample(X, y_labels__linear_indices, weights.W, parameters.hyper_par);
            res_struct.loss__per_worker(inner_iter_nr, epoch_count) = cost_function_svm(X, y_labels__linear_indices, weights.W, parameters.hyper_par);
            
    end
    
    % only W:s are required
    [grad_struct_instant.dW, signaling_factor] = quantize_sparsify_vector(grad_struct_instant.dW, parameters, n_work);   
    [grad_struct_instant.db]                   = quantize_sparsify_vector(grad_struct_instant.db, parameters, n_work); 
    
    % also update the nr of signaling (if quantized / compressed)
    res_struct.total_nr_of_signaling = res_struct.total_nr_of_signaling + signaling_factor*2; % increase by 2 since the Weights and Gradients are exchanged among master and each worker
    
    %grad_struct = catstruct(grad_struct, grad_struct_instant);   
    %grad_struct.dW = [];
    %grad_struct.db = [];
    grad_struct = copystruct(grad_struct,grad_struct_instant);

    
    switch lower(parameters.select_optimization_method)
        case {'sgd'; 'gd'}
            [weights.W, weights.b, step_struct] = sgd(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
        case 'adagrad'
            [weights.W, weights.b, step_struct, grad_struct] = adagrad(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
        case 'rmsprop'
            [weights.W, weights.b, step_struct, grad_struct] = rmsprop(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
        case 'adam'
            [weights.W, weights.b, step_struct, grad_struct] = adam(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
         case 'nag'
            [weights.W, weights.b, step_struct, grad_struct] = nesterovag(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
    end
    
    if enable_online_plotting
        figure(2);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        semilogy(res_struct.total_iter_nr, res_struct.loss__per_worker(inner_iter_nr, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('nr of iterations');
        ylabel('cost');
    end
    %name_fig=strcat('MSE_NrOfMiniBatches',num2str(epoch_count),'_',select_optimization_method);
    %cd result/plot;
    %savefig(name_fig);
    %cd ../../;
    %switch 1
    %    case enable_online_plotting.inner_loop==false
    %        close;
    %end
    
    if enable_online_plotting
        figure(3);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        semilogy(res_struct.total_nr_of_signaling, res_struct.loss__per_worker(inner_iter_nr, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('nr of signaling exchanges (T)');
        ylabel('cost');
    end
    
end



end
%%
