from io import StringIO
import numpy as np
import time
import math

# normalize the data set


def normalizedata(my_data):
    start = time.clock()
    for i in range(my_data.shape[0]):
        norm_temp = np.linalg.norm(my_data[i, 1:(my_data.shape[1])])
        if norm_temp != 0:
            my_data[i, 1:(my_data.shape[1])] = my_data[i,
                                                       1:(my_data.shape[1])] / norm_temp

        stop = time.clock()
        if i % 10000 == 0:
            print("Normalize the data at sample {}   time {}".format(i, stop))

    return my_data

# function of gradient computations over slices of data and x


def gradient_LS_loss(A_slice, b_slice, x):
    # initialize the gradient
    gradient = np.zeros(x.shape[0])
    for i in range(b_slice.shape[0]):
        temp = b_slice[i] * np.dot(A_slice[i, :], x)
        if temp < 1:
            gradient -= b_slice[i] * A_slice[i, :]

    return gradient

def gradient_and_loss(A, b):

    bA = b[:, np.newaxis] * A

    def gradient(x):
        bAx = bA @ x
        mask = bAx < 1
        return -(mask @ bA)

    def loss(x):
        bAx = bA @ x
        mask = bAx < 1
        return mask.sum() - bAx @ mask

    return gradient, loss


def ComputeLoss(my_data, x):
    loss = 0.0
    for i in range(my_data.shape[0]):
        loss += max(0, 1 - my_data[i, 0] *
                    np.dot(my_data[i, 1:(my_data.shape[1])], x))
        # if (i % 10000) == 0:
        #    print("finish computing the loss at sample {}".format(i))

    return loss


def two_star_topology_adj_matrix(num_workers):
    """
    Consider a two-star topology with communication graph
    (1,2,3,4)-5-6-(7,8,9,10) and run decentralized subgradient method.
    =>
    (0,1,2,3)-4,5-(6,7,8,9) and run decentralized subgradient method.

    Note that if we have more workers, the extra workers will not be
    connected to anyone else.
    """

    A = np.zeros((num_workers, num_workers))

    # Everyone is connected to themselves
    for m in range(num_workers):
        A[m, m] = 1

    # Nodes 0-3 are connected to node 4
    for m in [0, 1, 2, 3]:
        A[m, 4] = A[4, m] = 1

    # Nodes 6-9 are connected to node 5
    for m in [6, 7, 8, 9]:
        A[m, 5] = A[5, m] = 1

    # Nodes 4 and 5 are connected to each other
    A[4, 5] = A[5, 4] = 1

    # Divide a column of the matrix with the sum of the column.
    A = A / np.sum(A, axis=0)

    print("Adjacency matrix A: {}".format(A))
    return A


def DecentralizedGD(my_data, xstart, stepsize,
                    num_workers, maxIter, printIter, prob, Var_R):
    """
    Decentralized gradient descent in two-star topology
    """

    grad, loss = gradient_and_loss(my_data[:, 1:], my_data[:, 0])
    # This whole thing is just to make all the clients
    # start with the same weights (xstart) and have the dimensions
    # work out nicely.
    xstart = xstart[:, np.newaxis]
    print("xstart shape: {}".format(xstart.shape))
    x = np.tile(xstart, [1, num_workers])
    print("x shape: {}".format(x.shape))
    print("x[:, 1] shape: {}".format(x[:, 1].shape))

    start = time.clock()
    fcn_loss = np.zeros((maxIter, num_workers))

    assert (xstart.shape[0] == (my_data.shape[1] - 1)), "not the same size"

    # Adjacency matrix (We expect 10 workers in this exercise ...)
    assert num_workers == 10
    A = two_star_topology_adj_matrix(num_workers)

    stop = time.clock() - start

    print("decentralized gradient descent: iteration {} fcn_loss = {} time = {}"
          .format(0, fcn_loss[0, :], stop))

    batchsize = math.floor(my_data.shape[0] / num_workers)
    gradient_collected = np.zeros((xstart.shape[0], num_workers))

    for i in range(1, maxIter):

        # Iterate over workers and calculate the gradients
        # Store this in calculated_gradients (one column per client)
        for n_gp in range(num_workers):

            if n_gp != (num_workers - 1):
                end_idx = n_gp * batchsize - 1
            else:
                end_idx = my_data.shape[0] - 1

            start_idx = (n_gp - 1) * batchsize

            A_slice = my_data[start_idx:end_idx, 1:(my_data.shape[1])]
            b_slice = my_data[start_idx:end_idx, 0]

            gradient_collected[:, n_gp] = gradient_LS_loss(
                A_slice, b_slice, x[:, n_gp])

            if np.random.binomial(1, prob) == 1:
                gradient_collected[:, n_gp] += Var_R * \
                    np.random.randn(x[:, n_gp].shape[0])

        # Iterate over workers and propagate the gradients, (use @)
        propagated_gradient_collected = np.dot(gradient_collected, A)
        # x -= stepsize * propagated_gradient_collected / batchsize
        x = np.dot(x, A) - stepsize * propagated_gradient_collected / batchsize
        #print(propagated_gradient_collected[0, 0] / batchsize)

        # average the gradient
        # gradient = np.mean(gradient_collected, axis=1) / batchsize

        # update the solution

        # Master node collects {∇fi(wk)}i and computes wk+1
        # Shouldn't this be 1/N * . since we're adding one gradient
        # asynchronously

        # x -= stepsize * gradient

        # data logging
        for n_gp in range(num_workers):
            fcn_loss[i, n_gp] = loss(x[:, n_gp])
            stop = time.clock()

        if (i % printIter) == 0:
            print("distributed gradient descent:"
                  "iteration {} fcn_loss = {} time = {}"
                  .format(i, fcn_loss[i, 0], stop - start))

    print("finish distributed gradient descent\n\n")

    return fcn_loss, x


def DistributedGD(my_data, xstart, stepsize,
                  num_workers, maxIter, printIter, prob, Var_R):
    """
    Function of distributed gradient descent in the serial mode.
    This is a special case of DecentralizedGD where all nodes are connected.
    """
    grad, loss = gradient_and_loss(my_data[:, 1:], my_data[:, 0])

    start = time.clock()
    fcn_loss = np.zeros(maxIter)
    assert (xstart.shape[0] == (my_data.shape[1] - 1)), "not the same size"

    x = xstart
    fcn_loss[0] = loss(x)
    stop = time.clock() - start
    print("distributed gradient descent: iteration {} fcn_loss = {} time = {}"
          .format(0, fcn_loss[0], stop))

    batchsize = math.floor(my_data.shape[0] / num_workers)
    gradient_collected = np.zeros((xstart.shape[0], num_workers))

    for i in range(1, maxIter):

        # Iterate over workers
        for n_gp in range(num_workers):

            if n_gp != (num_workers - 1):
                end_idx = n_gp * batchsize - 1
            else:
                end_idx = my_data.shape[0] - 1

            start_idx = (n_gp - 1) * batchsize

            A_slice = my_data[start_idx:end_idx, 1:(my_data.shape[1])]
            b_slice = my_data[start_idx:end_idx, 0]

            gradient_collected[:, n_gp] = gradient_LS_loss(
                A_slice, b_slice, x)

            if np.random.binomial(1, prob) == 1:
                gradient_collected[:, n_gp] += Var_R * \
                    np.random.randn(xstart.shape[0])

        # average the gradient
        gradient = np.mean(gradient_collected, axis=1) / batchsize
        # update the solution

        # Master node collects {∇fi(wk)}i and computes wk+1
        # Shouldn't this be 1/N * . since we're adding one gradient
        # asynchronously
        x -= stepsize * gradient
        # data logging
        fcn_loss[i] = loss(x)
        stop = time.clock()

        if (i % printIter) == 0:
            print("distributed gradient descent:"
                  "iteration {} fcn_loss = {} time = {}"
                  .format(i, fcn_loss[i], stop - start))

    print("finish distributed gradient descent\n\n")
    return fcn_loss, x


def TrainForClassVSAll(my_data, class_label, given_class):
    for i in range(my_data.shape[0]):
        if class_label[i] == given_class:
            my_data[i, 0] = 1
        else:
            my_data[i, 0] = -1

    return my_data


def get_mnist_data():

    # read the data set from csv to the numpy array
    #   the first column of my_data is the class label vector 0,1,...,9
    #   each row corresponds to each training sample with
    # my_data.shape[1] - 1 features

    my_data = np.genfromtxt('mnist_train.csv', delimiter=',')
    print("finish reading the data")
    print("size data ({},{})".format(my_data.shape[0], my_data.shape[1]))

    my_data = normalizedata(my_data)  # normalize the data
    class_label = my_data[:, 0]  # the first colum is the class label

    # train for 0,1,...,9  one vs all
    my_data = TrainForClassVSAll(my_data, class_label, 0)

    print("size data ({},{})".format(my_data.shape[0], my_data.shape[1]))

    return my_data


if __name__ == "__main__":
    my_data = get_mnist_data()
    stepsize = 1   # stepsize <= 1
    num_workers = 10
    maxIter = 300
    printIter = 20

    # Decentralized Gradient Descent
    xstart = np.zeros(my_data.shape[1] - 1)

    var_prob = [0.5, 1]
    var_R = [0, 1000, 10000, 100000]

    stepsize = 0.01

    for prob in var_prob:
        for R in var_R:

            fcn_loss_decentralized, _ = DecentralizedGD(my_data, xstart,
                                                        stepsize,
                                                        num_workers, maxIter,
                                                        printIter,
                                                        prob, R)

            np.savetxt('decentralized_{}_{}.txt'.format(prob, R),
                       fcn_loss_decentralized, delimiter=' ')

    # import sys
    # sys.exit(1)

    # Distributed Gradient Descent
    # Vary p

    prob = [0, 0.3, 0.7, 0.9, 1]
    var_R = 1000

    fcn_loss_vary_prob = np.zeros((maxIter, np.size(prob)))



    for p in range(np.size(prob)):
        xstart = np.zeros(my_data.shape[1] - 1)
        fcn_loss_vary_prob[:, p], x = DistributedGD(my_data, xstart, stepsize,
                                                    num_workers, maxIter,
                                                    printIter,
                                                    prob[p], var_R)

    # save the data into the txt file
    np.savetxt('test_vary_prob.txt', fcn_loss_vary_prob, delimiter=' ')

    # Vary R
    prob = 0.7
    var_R = [0.1, 1, 10, 100, 1000]
    fcn_loss_vary_R = np.zeros((maxIter, np.size(var_R)))
    for r in range(np.size(var_R)):
        xstart = np.zeros(my_data.shape[1] - 1)
        fcn_loss_vary_R[:, r], x = DistributedGD(my_data, xstart, stepsize,
                                                 num_workers, maxIter,
                                                 printIter,
                                                 prob, var_R[r])

    # save the data into the txt file
    np.savetxt('test_vary_R.txt', fcn_loss_vary_R, delimiter=' ')
