% out is a matrix--> % this can be avoided
function out = derivative_softmax(z, hyper_par)

if ~isempty(hyper_par)
    logC = -hyper_par(1);    
else
    logC = -max(z,[],1);
end

[row_z_size, col_z_size] = size(z); % col_z_size==size of the mini-batch

e                        = exp(z + logC);
p                        = e ./ sum(e,1);
out                      = zeros(row_z_size, row_z_size, col_z_size);
P                        = out;

for mm = 1:col_z_size
    P(:,:,mm) = diag(p(:,mm));
end
 
out = P - outer_product_1dvecsx_1dvecsx (p , p);

end