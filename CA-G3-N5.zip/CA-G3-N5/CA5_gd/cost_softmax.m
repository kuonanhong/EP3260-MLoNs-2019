function [cost] = cost_softmax(X, Y, W, b, hyper_par)



P         = prediction_softmax_regression(X, W, b, hyper_par);
cost      = -sum(sum(Y .* log(P), 1),2) + hyper_par.lambda/2 * W(:)'*W(:);

end