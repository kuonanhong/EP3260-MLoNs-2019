clear all;
close all;
X = (readImages('train-images.idx3-ubyte'))';
Y = readLabels('train-labels.idx1-ubyte')/10;
%X = X(1:3000,:);
%Y = Y(1:3000);
numSam = length(X);
numFeatures = size(X,2);
numW = 10;
numIters = 300;
batchSize = numSam/numW;
startIndex = 1:batchSize:numSam;
endIndex = startIndex + batchSize - 1;

probs = [0,0.3,0.7,0.9,1.0];
gradientGlobal = zeros(numFeatures,numW);
loss = zeros(numIters,1);
alpha = 0.01;
h = figure('Name','Convergence of Decentralized Grad. Decent');
for R = [1,2,100,1000,10000]
    %for p = [0,0.3,0.7,0.9,1.0]
    for p = [0.7]
        w = zeros(numFeatures,1); %% varriable for eatch feature X.w
        for k = 1:numIters %% number of iteration
            gradient = zeros(1,numFeatures);
            for j  = 1:numW %% Each worker's code runs here
               % strcat('worker: ',string(j))
               for i = startIndex(j):1:endIndex(j)   
                    temp = Y(i)*(X(i,:)*w);
                    if (temp < 1)               
                        gradient = gradient - Y(i)*X(i,:);
                    end                
                end
                gradientGlobal(:,j) = gradient;
                if(rand() >1-p) %% add random noise
                    gradientGlobal(:,j) = gradientGlobal(:,j) + R*randn(numFeatures,1);
                end
            end
            gradeintAccumulated = mean(gradientGlobal,2)/batchSize;
            w = w - alpha*gradeintAccumulated;
            %% Calculate loss
            loss(k) = sum((Y-X*w))/numSam+10;
            strcat('iteration: ',string(k)', 'loss ',string(loss(k)))
        end

    end
    figure(h)
    hold on;
    plot(loss);
end 
figure(h);
hold on;
xlabel('Number of iterations');
ylabel('Normalized Loss');
legend('R = 1','R = 2','R=100','R=1000','R=10000');

% 
% W = 10; %% Number of Workers
% n = size(X,1); % number of features
% m = size(X,2); %length(y) number of examples
% 
% num_iters = 300;
% grad = zeros(n,W); % Stores gradient for each worker
% w = zeros(n,1);
% Rs = [0.1,100,1000]; % Var of noise
% probs = [0,0.3,0.7,0.9,1.0]; % Probability of noise
% lambda = 0.5;
% J_history = 1 * ones(1, num_iters);
% JtHist = 1 * ones(1, num_iters);
% epsilon = 10^-2;
% 
% %% Divide the data for different workers
% XD = reshape(X, n, floor(m/W), W);
% YD = reshape(Y, floor(m/W), W);
% 
% %% Descentralized Gradient Descent
% tic
% for R = 1
%     h = figure('Name','Convergence of Decentralized Grad. Decent');
%     for p = probs    
%         for num_iter = 1:num_iters
%         %     alpha = 1 / num_iter;
%             alpha = 0.01;
%             for i =1:W
%                 grad(:,i) = gradientLog(XD(:,:,i), YD(:,i), w, R, p);
%             end
% 
%             w = w - alpha * (sum(grad,2)/W + 2 * lambda * w);
%             J_history(num_iter) = cost(X, Y, w, lambda);
% 
%         %     if num_iter >10 && abs(J_history(num_iter) - J_history(num_iter-1)) < epsilon
%         %         break;
%         %     end
%         end
%         figure(h)
%         hold on;
%         plot(J_history);
%         xlabel('Number of iterations');
%         ylabel('Cost for all network');
%    end
%    figure(h);
%    hold on;
%    legend('p = 0.0','p = 0.3','p=0.7','p=0.9','p=1.0');
% end