function P = prediction_softmax_regression(X, W, b, hyper_par)


if ~exist('b','var')     
    b = zeros(size(W,1),1);
elseif (isempty(b))
    b = zeros(size(W,1),1);
end


n_out     = size(W,1);

Z         = exp(W*X + b);
P         = bsxfun(@times, Z, repmat(1./sum(Z,1), [n_out,1]));  


end