function [W1, W2, w3] = coorD(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon)
%GRADIENTDESCENTMULTI Performs gradient descent to learn w

% Initialize some useful values
N = length(y); % number of training examples
m = size(W1,1);
n = size(W1,2);
k = size(W2,1);

gW1 = zeros(m, n, N);
gW2 = zeros(k, m, N);
gw3 = zeros(k, N);

for i = 1:ceil(num_iters/3)
    for iter = 1:num_iters
        for j = 1:N
            a3 = 2 * (w3' * sigmoid(W2 * sigmoid(W1 * X(:,j))) - y(j));
            gw3(:,j) = a3 * sigmoid(W2 * sigmoid(W1 * X(:,j)));
        end
        gaw3 = 1/ N * sum(gw3,2) + 2 * lambda * w3;

        w3 = w3 - alpha * gaw3;
    end

    for iter = 1:num_iters
        for j = 1:N
            a3 = 2 * (w3' * sigmoid(W2 * sigmoid(W1 * X(:,j))) - y(j));
            a2 = dSigmoid(W2 * sigmoid(W1 * X(:,j)));
            gW2(:,:,j) =  a2 * (w3 * sigmoid(W1 * X(:,j))') * a3;
        end
        gaW2 = 1/ N * reshape(sum(gW2,3),size(gW2,1),size(gW2,2)) + 2 * lambda * W2;

        W2 = W2 - alpha * gaW2;
    end

    for iter = 1:num_iters
        for j = 1:N
            a3 = 2 * (w3' * sigmoid(W2 * sigmoid(W1 * X(:,j))) - y(j));
            a2 = dSigmoid(W2 * sigmoid(W1 * X(:,j)));
            gW1(:,:,j) = dSigmoid(W1 * X(:,j)) * W2' * a2 * w3 * X(:,j)';
        end
        gaW1 = 1/ N * reshape(sum(gW1,3),size(gW1,1),size(gW1,2)) + 2 * lambda * W1;

        W1 = W1 - alpha * gaW1;
    end
end
end
