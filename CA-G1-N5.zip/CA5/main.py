# -*- coding: utf-8 -*-

"""
CA5 assignment from SG-1.
See https://github.com/hshokrig/EP3260-MLoNs-2019/blob/master/CAs.pdf
"""

import numpy as np
import mnist  # From https://github.com/hsjeong5/MNIST-for-Numpy
import time
import math
import os
from sklearn import preprocessing
import sys

import cvxpy
import numpy as np
from multiprocessing import Process, Pipe


def gradient_LS_loss(A_slice, b_slice, x):
    # initialize the gradient
    gradient = np.zeros(x.shape[0])
    for i in range(b_slice.shape[0]):
        temp = b_slice[i] * np.dot(A_slice[i, :], x)
        if temp < 1:
            gradient -= b_slice[i] * A_slice[i, :]

    return gradient


def gradient_and_loss(A, b):

    bA = b[:, np.newaxis] * A

    def gradient(x):
        bAx = bA @ x
        mask = bAx < 1
        return -(mask @ bA)

    def loss(x):
        bAx = bA @ x
        mask = bAx < 1
        return mask.sum() - bAx @ mask

    return gradient, loss


def get_number_of_edges(adj):
    return (np.ceil(adj) - np.eye(adj.shape[0])).sum()


def two_star_topology_adj_matrix(num_workers):
    """
    Consider a two-star topology with communication graph
    (1,2,3,4)-5-6-(7,8,9,10) and run decentralized subgradient method.
    =>
    (0,1,2,3)-4,5-(6,7,8,9) and run decentralized subgradient method.

    Note that if we have more workers, the extra workers will not be
    connected to anyone else.
    """

    A = np.zeros((num_workers, num_workers))

    # Everyone is connected to themselves
    for m in range(num_workers):
        A[m, m] = 1

    # Nodes 0-3 are connected to node 4
    for m in [0, 1, 2, 3]:
        A[m, 4] = A[4, m] = 1

    # Nodes 6-9 are connected to node 5
    for m in [6, 7, 8, 9]:
        A[m, 5] = A[5, m] = 1

    # Nodes 4 and 5 are connected to each other
    A[4, 5] = A[5, 4] = 1

    # Divide a column of the matrix with the sum of the column.
    A = A / np.sum(A, axis=0)

    print("Adjacency matrix A: {}".format(A))
    return A


def get_data_slice(x_train, y_train, n_gp, num_workers=10):
    """
    Slice the data for this client
    """

    batchsize = math.floor(x_train.shape[0] / num_workers)

    end_idx = min((n_gp + 1) * batchsize, x_train.shape[0]) - 1
    start_idx = n_gp * batchsize

    A_slice = x_train[start_idx:end_idx, :]
    b_slice = y_train[start_idx:end_idx, np.newaxis]

    return A_slice, b_slice


def run_worker(n_gp, pipe, rho: float = 1.0, lmba: float = 1e-5,
               num_workers=10):

    A_slice, b_slice = get_data_slice(x_train, y_train, n_gp)
    # b_slice = b_slice[:, np.newaxis]

    n = x_train.shape[1]
    m = A_slice.shape[0]

    xbar = cvxpy.Parameter(n, value=np.zeros(n))

    u = cvxpy.Parameter(n, value=np.zeros(n))
    x = cvxpy.Variable(n)

    lambd = cvxpy.Parameter(nonneg=True)
    lambd.value = lmba

    # f = cvxpy.sum(
    #    cvxpy.pos(1 - cvxpy.multiply(b_slice, (A_slice * x)[:, np.newaxis])))

    f = cvxpy.sum(
        cvxpy.pos(1 - cvxpy.multiply(
            b_slice, (A_slice * x)[:, np.newaxis])))

    # ADMM loop.
    # Redefining the problem here probably disables warm start.
    # Not sure if this is needed, however, f2 probably needs redefinition
    # since we change xbar in each iteration.

    while True:
        f2 = f + (rho / 2) * cvxpy.sum_squares(x - xbar + u)
        reg = cvxpy.norm(x, 1)

        prox = cvxpy.Problem(cvxpy.Minimize(f2 / m + lambd * reg))
        prox.solve(scaling=0, polish=0, verbose=False)
        pipe.send(x.value)

        # If we use sparse representation, keep the old values for xbar.
        xbarprime = pipe.recv()
        xbarprime[xbarprime == 0] = xbar.value[xbarprime == 0]
        xbar.value = xbarprime

        u.value += x.value - xbar.value

    # # z-update with relaxation
    # zold = z;
    # x_hat = alpha*x +(1-alpha)*zold;
    # z = N*rho/(1/lambda + N*rho)*mean( x_hat + u, 2 );
    # z = z*ones(1,N);

    # # u-update
    # u = u + (x_hat - z);


def ADMM(x_train, y_train, x_test, y_test, xstart,
         rho=1.0, lmba=1e-5,
         num_workers=10, maxIter=300, printIter=100,
         quantization_method=None):
    """
    The alternating direction method of multipliers (ADMM) is an
    algorithm that solves convex optimization problems by
    breaking them into smaller pieces, each of which are then
    easier to handle.

    Source: http://stanford.edu/~boyd/admm.html
    """

    start = time.process_time()

    # Get gradient and loss function pointers
    train_grad, train_loss = gradient_and_loss(x_train, y_train)
    test_grad, test_loss = gradient_and_loss(x_test, y_test)

    pipes = []
    procs = []
    T = np.zeros(maxIter)
    fcn_loss = np.zeros(maxIter)
    fcn_test_loss = np.zeros(maxIter)

    for n_gp in range(num_workers):
        local, remote = Pipe()
        pipes += [local]

        procs += [Process(target=run_worker, args=(n_gp, remote, rho, lmba))]
        procs[-1].start()

    for i in range(1, maxIter):

        # Select which elements to set to 0
        # if we are using Q1 method. If not, this will be ignored.
        K = math.ceil(xstart.shape[0] * 0.75)
        row_index = np.random.randint(
            xstart.shape[0], size=(xstart.shape[0] - K))

        # Gather and average x_i
        xbar = sum(
            quantize(
                pipe.recv(), method=quantization_method,
                row_index=row_index)[0]
            for pipe in pipes) / num_workers

        # Also return size
        xbar, size = quantize(
            xbar, method=quantization_method, row_index=row_index)

        # Scatter xbar
        for pipe in pipes:
            pipe.send(xbar)

        # In each iteration
        # gather x_i^k and average to get \bar{x}^k
        # scatter average \bar{x}^k to clients
        # update y_i^k locally
        # update x_i locally

        T[i] += 2 * num_workers * size

        # Data logging
        fcn_loss[i] = train_loss(xbar) / x_train.shape[0]
        fcn_test_loss[i] = test_loss(xbar) / x_test.shape[0]

        stop = time.process_time()

        if (i % printIter) == 0:
            print("ADMM:"
                  "iteration {} fcn_loss = {} time = {}"
                  .format(i, fcn_loss[i], stop - start))

    [p.terminate() for p in procs]
    print("finish ADMM\n\n")

    return fcn_loss, fcn_test_loss, T, xbar


def quantize(xinput, method=None, row_index=None, bits=16):
    """
    Quantize vector
    """

    x = xinput.copy()

    # Q1 method sparsifies vector
    if method == "Q1":

        # Randomly keep K rows
        if row_index is None:
            K = math.ceil(x.shape[0] * 0.5)
            row_index = np.random.randint(x.shape[0], size=(x.shape[0] - K))
        else:
            K = np.sum(row_index != 0)

        if x.ndim == 2:
            for column in range(x.shape[1]):
                x[row_index, column] = 0
        else:
            x[row_index] = 0

        return x, K

    # Q2 method represents each element with less bits
    elif method == "Q2":

        bins = np.linspace(-1, 1, 2**bits)
        xprime = bins[np.digitize(np.clip(x, -1, 1), bins, right=True)]

        # Return quantized vector in bytes
        return xprime, x.shape[0] * bits / 32.0

    else:

        # None of the above
        return x, x.shape[0]


def DistributedGD(x_train, y_train, x_test, y_test, xstart, stepsize=0.01,
                  num_workers=10, maxIter=300, printIter=100,
                  adjacency_matrix_fcn=two_star_topology_adj_matrix,
                  quantization_method=None):
    """
    Decentralized gradient descent in two-star topology.

    The weights are stored in a matrix where each column represents one client.
    The dimensions are then m x n, where m is the number of features and n
    is the number of clients.
    """

    start = time.process_time()

    # Get gradient and loss function pointers
    train_grad, train_loss = gradient_and_loss(x_train, y_train)
    test_grad, test_loss = gradient_and_loss(x_test, y_test)

    # This whole thing is just to make all the clients
    # start with the same weights (xstart) and have the dimensions
    # work out nicely.
    x = xstart

    print("xstart shape: {}".format(xstart.shape))
    print("x shape: {}".format(x.shape))

    # Initialize empty vectors
    fcn_loss = np.zeros(maxIter)
    fcn_test_loss = np.zeros(maxIter)
    T = np.zeros(maxIter)

    # Same number of weights as columns in training data
    assert (xstart.shape[0] == (x_train.shape[1])), "not the same size"

    # Adjacency matrix (We expect 10 workers in this exercise ...)
    assert num_workers == 10

    stop = time.process_time() - start

    print("Distributed gradient descent: " +
          "iteration {} fcn_loss = {} time = {}"
          .format(0, fcn_loss[0], stop))

    batchsize = math.floor(x_train.shape[0] / num_workers)

    print("batchsize: {}".format(batchsize))

    gradient_collected = np.zeros((xstart.shape[0], num_workers))

    for i in range(1, maxIter):

        # Iterate over workers and calculate the gradients
        # Store this in calculated_gradients (one column per client)
        for n_gp in range(num_workers):
            A_slice, b_slice = get_data_slice(x_train, y_train, n_gp)
            gradient_collected[:, n_gp] = gradient_LS_loss(A_slice, b_slice, x)

        gradient = np.mean(gradient_collected, axis=1) / batchsize
        gradient, size = quantize(gradient, method=quantization_method)
        x -= stepsize * gradient

        # The number of features times the number of edges in the graph.
        # This is the total amount of data sent in each iteration,
        # gradients and weights are quantized, and clients remember the
        # value of the elements set to zero.
        T[i] += 2 * num_workers * size

        # Data logging
        fcn_loss[i] = train_loss(x) / x_train.shape[0]
        fcn_test_loss[i] = test_loss(x) / x_test.shape[0]

        stop = time.process_time()

        if (i % printIter) == 0:
            print("distributed gradient descent:"
                  "iteration {} fcn_loss = {} time = {}"
                  .format(i, fcn_loss[i], stop - start))

    print("finish distributed gradient descent\n\n")

    return fcn_loss, fcn_test_loss, T, x


def DecentralizedGD(x_train: np.array, y_train: np.array,
                    x_test: np.array, y_test: np.array,
                    xstart: np.array, stepsize: float = 0.01,
                    num_workers=10, maxIter=300, printIter=100,
                    adjacency_matrix_fcn=two_star_topology_adj_matrix,
                    quantization_method=None):
    """
    Decentralized gradient descent in two-star topology
    """

    start = time.process_time()

    # Get gradient and loss function pointers
    train_grad, train_loss = gradient_and_loss(x_train, y_train)
    test_grad, test_loss = gradient_and_loss(x_test, y_test)

    # This whole thing is just to make all the clients
    # start with the same weights (xstart) and have the dimensions
    # work out nicely.
    xstart = xstart[:, np.newaxis]
    x = np.tile(xstart, [1, num_workers])

    print("xstart shape: {}".format(xstart.shape))
    print("x shape: {}".format(x.shape))
    print("x[:, 1] shape: {}".format(x[:, 1].shape))

    # Initialize empty vectors
    fcn_loss = np.zeros((maxIter, num_workers))
    fcn_test_loss = np.zeros((maxIter, num_workers))
    T = np.zeros(maxIter)

    # Same number of weights as columns in training data
    assert (xstart.shape[0] == (x_train.shape[1])
            ), "not the same size"  # nosec

    # Adjacency matrix (We expect 10 workers in this exercise ...)
    assert num_workers == 10
    A = adjacency_matrix_fcn(num_workers)

    stop = time.process_time() - start

    print("Decentralized gradient descent: " +
          "iteration {} fcn_loss = {} time = {}"
          .format(0, fcn_loss[0, :], stop))

    batchsize = math.floor(x_train.shape[0] / num_workers)

    print("batchsize: {}".format(batchsize))

    gradient_collected = np.zeros((xstart.shape[0], num_workers))

    for i in range(1, maxIter):

        # Iterate over workers and calculate the gradients
        # Store this in calculated_gradients (one column per client)
        for n_gp in range(num_workers):
            A_slice, b_slice = get_data_slice(x_train, y_train, n_gp)
            gradient_collected[:, n_gp] = gradient_LS_loss(A_slice, b_slice,
                                                           x[:, n_gp])

        # Iterate over workers and propagate the gradients
        propagated_gradient_collected = (gradient_collected @ A) / batchsize

        # First we propagate the gradients, then we quantize and pretend
        # we did it beforehand. No difference, just easier.
        propagated_gradient_collected, size = quantize(
            propagated_gradient_collected, quantization_method)

        # Decentralized subgradient method (primal method), v2:
        x = (x @ A) - stepsize * propagated_gradient_collected

        # The number of features times the number of edges in the graph.
        # This is the total amount of data sent in each iteration.
        T[i] += get_number_of_edges(A) * size

        # Data logging
        for n_gp in range(num_workers):
            fcn_loss[i, n_gp] = train_loss(x[:, n_gp]) / x_train.shape[0]
            fcn_test_loss[i, n_gp] = test_loss(x[:, n_gp]) / x_test.shape[0]

        stop = time.process_time()

        if (i % printIter) == 0:
            for n_gp in range(num_workers):
                print("Decentralized gradient descent:"
                      "iteration {} fcn_loss = {} time = {}, client = {}"
                      .format(i, fcn_loss[i, n_gp], stop - start, n_gp))

    print("finish Decentralized gradient descent\n\n")

    return fcn_loss, fcn_test_loss, T, x


def mk_one_vs_all(y, c):
    return np.where(y == c, 1, -1)


def get_dataset():
    """
    Load and normalize dataset. Download if necessary.
    """
    if not os.path.exists('mnist.pkl'):
        mnist.init()
    x_train, y_train, x_test, y_test = mnist.load()

    x_train = preprocessing.normalize(x_train, norm='l2')
    x_test = preprocessing.normalize(x_test, norm='l2')

    return x_train, mk_one_vs_all(y_train, 0), x_test, mk_one_vs_all(y_test, 0)


def initialize_weights(features: int) -> np.array:
    """
    Return initialized weights (to 0).
    """

    return np.zeros(features)


if __name__ == "__main__":

    # Constants
    num_workers: int = 10
    stepsize: float = 0.01
    maxIter: int = 600
    printIter: int = 20

    # Load and normalize dataset
    x_train, y_train, x_test, y_test = get_dataset()

    for lmba, rho in zip([1e-3, 1e-4, 1e-5], [5000.0, 5000.0, 5000.0]):
        for quantization_method in ["Q1"]:

            # Initialize weights
            xstart = initialize_weights(x_train.shape[1])

            # Start distributed training
            fcn_loss_dist, fcn_test_loss_dist, T, x = ADMM(
                x_train, y_train,
                x_test, y_test, xstart,
                rho=rho,
                lmba=lmba,
                maxIter=300,
                printIter=printIter,
                quantization_method=quantization_method)

            # Save data
            np.savetxt('fcn_loss_admm_test_{}_{}_{}.txt'.format(rho, lmba, quantization_method),
                       fcn_loss_dist, delimiter=' ')
            np.savetxt('fcn_test_loss_admm_test_{}_{}_{}.txt'.format(rho, lmba, quantization_method),
                       fcn_test_loss_dist, delimiter=' ')
            np.savetxt('T_admm_test_{}_{}_{}.txt'.format(rho, lmba, quantization_method),
                       T, delimiter=' ')
            np.savetxt('x_admm_test_{}_{}_{}.txt'.format(rho, lmba, quantization_method),
                       x, delimiter=' ')

    sys.exit(0)

    # for quantization_method in [None, "Q1", "Q2"]:
    for quantization_method in ["Q1"]:

        print("Quantization method: {}".format(quantization_method))

        # Initialize weights
        xstart = initialize_weights(x_train.shape[1])

        # Start distributed training
        fcn_loss_dist, fcn_test_loss_dist, T, x = DistributedGD(
            x_train, y_train,
            x_test, y_test, xstart,
            stepsize, maxIter=maxIter,
            printIter=printIter,
            quantization_method=quantization_method)

        # Save data
        np.savetxt('fcn_loss_distributed_{}.txt'.format(quantization_method),
                   fcn_loss_dist, delimiter=' ')
        np.savetxt('fcn_test_loss_distributed_{}.txt'.format(quantization_method),
                   fcn_test_loss_dist, delimiter=' ')
        np.savetxt('T_distributed_{}.txt'.format(quantization_method),
                   T, delimiter=' ')
        np.savetxt('x_distributed_{}.txt'.format(quantization_method),
                   x, delimiter=' ')

        # Initialize weights
        xstart = initialize_weights(x_train.shape[1])

        # Start decentralized training
        fcn_loss_dcent, fcn_test_loss_dcent, T, x = DecentralizedGD(
            x_train, y_train,
            x_test, y_test, xstart,
            stepsize, maxIter=maxIter,
            printIter=printIter,
            quantization_method=quantization_method)

        # Save data
        np.savetxt('fcn_loss_decentralized_{}.txt'.format(quantization_method),
                   fcn_loss_dcent, delimiter=' ')
        np.savetxt('fcn_test_loss_decentralized_{}.txt'.format(quantization_method),
                   fcn_test_loss_dcent, delimiter=' ')
        np.savetxt('T_decentralized_{}.txt'.format(quantization_method),
                   T, delimiter=' ')
        np.savetxt('x_decentralized_{}.txt'.format(quantization_method),
                   x, delimiter=' ')
