#!/bin/bash 

# Set the allocation to be charged for this job
# not required if you have set a default allocation

# My allocation number on SUPR
#  the name of the project to be charged for this run. 
# Note the name should not normally contain PDC or SNIC, so PDC-2015-1 is 
# just 2015-1 and SNIC 2015/1-1 is just 2015-1-1
#SBATCH -A 2018-131

# Only 1 hour wall-clock time will be given to this job
#SBATCH -t 24:00:00

# Number of nodes
#SBATCH --nodes=1
# Number of MPI processes per node (24 is recommended for most cases)
# 48 is the default to allow the possibility of hyperthreading
#SBATCH --ntasks-per-node=24
# Number of MPI processes.

# The name of the script is 
