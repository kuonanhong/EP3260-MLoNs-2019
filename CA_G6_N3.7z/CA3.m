%% Initializations
% load('household_power_consumption_.csv');
clear all;
clc;
data = load('household_v3.txt');
X = data(:,1:6)';
y = data(:,9);
N = length(y);
d = size(X,1);
D = 0;
 
lambda = 0.1;
num_iters = 33;
epsilon = 0.1;
% L = 1/(4*N) * norm(Z,'fro')^2 + 2*lambda;
alpha = 0.1;
m = 10;
n = size(X,1);
k = 5;

W1 = zeros(m, n);
W2 = zeros(k, m);
w3 = zeros(k, 1);

%% GD
tic
[W1GD, W2GD, w3GD] = gradientDescent(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon);
f =  lambda * (norm(W1GD,'fro')^2 + norm(W2GD,'fro')^2 + norm(w3GD)^2);
for i = 1 : N
    f = f + 1/N * (w3GD' * sigmoid(W2GD * sigmoid(W1GD * X(:,i)) - y(i)))^2;
end
fprintf("GD f = %f \n", f);
toc
%% SGD
tic
[W1SG, W2SG, w3SG] = stochasticGradient(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon);
f =  lambda * (norm(W1SG,'fro')^2 + norm(W2SG,'fro')^2 + norm(w3SG)^2);
for i = 1 : N
    f = f + 1/N * (w3SG' * sigmoid(W2SG * sigmoid(W1SG * X(:,i)) - y(i)))^2;
end
fprintf("SGD f = %f \n", f);
toc
 %% SVRG
tic
[W1SV, W2SV, w3SV] = stochasticVarReduced(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon);
f =  lambda * (norm(W1SV,'fro')^2 + norm(W2SV,'fro')^2 + norm(w3SV)^2);
for i = 1 : N
    f = f + 1/N * (w3SV' * sigmoid(W2SV * sigmoid(W1SV * X(:,i)) - y(i)))^2;
end
fprintf("SVRG f = %f \n", f);
toc
%% Perturbed GD
tic
[W1PGD, W2PGD, w3PGD] = perturbGD(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon);
f =  lambda * (norm(W1PGD,'fro')^2 + norm(W2PGD,'fro')^2 + norm(w3PGD)^2);
for i = 1 : N
    f = f + 1/N * (w3PGD' * sigmoid(W2PGD * sigmoid(W1PGD * X(:,i)) - y(i)))^2;
end
fprintf("Perturbed GD f = %f \n", f);
toc

%% BLOCKED Coordinate Decent
tic
[W1CD, W2CD, w3CD] = coorD(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon);
f =  lambda * (norm(W1CD,'fro')^2 + norm(W2CD,'fro')^2 + norm(w3CD)^2);
for i = 1 : N
    f = f + 1/N * (w3CD' * sigmoid(W2CD * sigmoid(W1CD * X(:,i)) - y(i)))^2;
end
fprintf("BLOCKED Coordinate Decent f = %f \n", f);
toc
