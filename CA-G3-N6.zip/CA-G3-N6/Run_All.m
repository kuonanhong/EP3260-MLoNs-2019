% Run for the three algorithms when using 7 epochs each
close all;clear;clc;

%%%%%%%%%%%%%%%%%%%%%%%%
nrof_hidden_layers         = 4; % not including the input and output layers
nrof_nodes_hidden          = 5e2; %[100, 100, 100, 100, 100, 100, 100]; % the length of this row vector should match with nrof_hidden_layers
activation_function_number = 1; %{1 is 'sigmoid', 2 is 'ReLu', and 3 is 'se'
nrof_epochs = 5;

% SGD
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,activation_function_number,1);
% RMSprop
close all;clc;
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,activation_function_number,3);
% AdaGrad
close all;clc;
main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,activation_function_number,2);

