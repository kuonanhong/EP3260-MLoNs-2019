% clear variables;

function function_for_ca5(...
                  opt_meth_number,...
                  nrof_epochs,...
                  sparsify_or_quantize_or_none, ...                  
                  sparsify_percnt_n_vec, ...
                  quantization_bits, ...
                  enable_online_plotting)

%%% INPUTs
% opt_meth_number              -  11:'gd' (decentralized), 
%                                 21: 'gd' (distributed two-star),
%                                 25: 'nag' (distributed two-star)                                
%                                 25: 'nag' (distributed two-star)
% nrof_epochs                  - Number of epochs to train (50 by default).
% sparsify_or_quantize_or_none - 'quantize' 'sparsify' 'none' (default)
% sparsify_percnt_n_vec        - percentage to sparsify the weights/gradients (if sparsify_or_quantize_or_none == 'sparsify')
% quantization_bits            - bitwidth for the quantization (if sparsify_or_quantize_or_none == 'quantize')
% enable_online_plotting       - for online printing

% =====================================
%% Load the training and test MNIST data
% =====================================

% training data
train_x_data_file_name = 'train-images.idx3-ubyte'; % X: INPUT (images)
train_y_data_file_name = 'train-labels.idx1-ubyte'; % y: OUTPUT (label)
[X_train, y_train_]    = load_mnist_data(train_x_data_file_name, train_y_data_file_name);
y_train_               = y_train_ + 1;


% test data
test_x_data_file_name = 't10k-images.idx3-ubyte'; % X: INPUT (images)
test_y_data_file_name = 't10k-labels.idx1-ubyte'; % y: OUTPUT (label)
[X_test, y_test_]      = load_mnist_data(test_x_data_file_name, test_y_data_file_name);
y_test_                = y_test_ + 1;

% derived parameters from the data
n_train            = size(X_train, 2); % total nr of samples
d                  = size(X_train, 1); % dimension of the feature vector
n_test             = size(X_test, 2);  % total nr of samples
d_                 = size(X_test, 1);  % dimension of the feature vector (test) should be same as train
assert(d==d_);

nrof_nodes_input   = d;
nrof_nodes_output  = numel(unique(y_train_)); % = 10

%% Default values

% load some default parameters if the inputs are not given
if ~exist('opt_meth_number','var')
    opt_meth_number = 21;
end
if ~exist('step_size_method_number','var')
    step_size_method_number = 1;
end
if ~exist('step_size_W_initial','var')
    step_size_W_initial = 0.1;
end
if ~exist('step_size_b_initial','var')
    step_size_b_initial = 0.1;
end
if ~exist('loss_function','var')
    loss_function = 'svm';
end
if ~exist('bias_enable_flag','var')
    bias_enable_flag = false;
end
if ~exist('regularization_factor','var')
    regularization_factor = 1;
end
if ~exist('nrof_epochs','var')
    nrof_epochs = 50;
end
if ~exist('nrof_workers','var')
    nrof_workers = 10;
end
if ~exist('sparsify_or_quantize_or_none','var')
    sparsify_or_quantize_or_none = 'none'; %'quantize' 'sparsify' 'noquant';
end
if ~exist('sparsify_percnt_n_vec','var')
    sparsify_percnt_n_vec = 40;
end
if ~exist('quantization_bits','var')
    quantization_bits = 4;
end
if ~exist('enable_online_plotting','var')
    enable_online_plotting = false;
end


%% derived parameters from the inputs

% ====================================================
% Optimization for Weights computation
% ====================================================

regularization_type = 'l2'; %'l2','none';

% Select the optimization method based on the input
switch opt_meth_number
    % ----------------CENTRALIZED----------------------------
    case {1} % centralized GD: reference
        select_optimization_method = 'gd';
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 1;
        
    case {2} % centralized adagrad: reference
        select_optimization_method = 'adagrad';
        step_size_W_initial        = 0.5; % default paramters
        step_size_method_number    = 2;
        
    case {3} % centralized rmsprop: reference
        select_optimization_method = 'rmsprop';
        step_size_W_initial        = 0.075; % default paramters
        step_size_method_number    = 2; 
        
    case {4} % centralized adam: reference
        select_optimization_method = 'adam';
        step_size_W_initial        = 2.25; % default paramters
        step_size_method_number    = 2;
        
    case {5} % centralized Nesterov Accelerated Gradient: reference
        select_optimization_method = 'nag';
        step_size_W_initial        = 0.5; % default paramters
        step_size_method_number    = 2;
    
    % -----------DECENTRALIZED---------------------------------
    
    case 11 % decentralized SGD
        select_optimization_method = 'dgd';
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 1;
        
    case 12 % decentralized AdaGrad
        select_optimization_method = 'dadagrad'; % distributed adagrad
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 2;
        
    case 13 % decentralized RMSprop
        select_optimization_method = 'drmsprop'; % distributed rmsprop
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 2;
        
    case 14 % decentralized ADAM
        select_optimization_method = 'dadam'; % distributed adam
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 2;
        
    case 15 % decentralized Nesterov Accelerated Gradient (NAG)
        select_optimization_method = 'dnag'; % distributed adagrad
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 2;
    
    % -----------DISTRIBUTED TWO STAR TOPOLOGY ---------------------------
    
    case 21 % decentralized SGD
        select_optimization_method = 'dsgd_2star_topology';
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 1;
        
    case 22 % decentralized AdaGrad
        select_optimization_method = 'dadagrad_2star_topology'; % distributed adagrad
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 3;
        
    case 23 % decentralized RMSprop
        select_optimization_method = 'drmsprop_2star_topology'; % distributed rmsprop
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 3;
        
    case 24 % decentralized ADAM
        select_optimization_method = 'dadam_2star_topology'; % distributed adam
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 3;
        
    case 25 % decentralized Nesterov Accelerated Gradient (NAG)
        select_optimization_method = 'dnag_2star_topology'; % distributed adagrad
        step_size_W_initial        = 0.125; % default paramters
        step_size_method_number    = 3;
    
    case 26
        select_optimization_method = 'admm_2star_topology';
        error('not supported yet');
            
    otherwise
        select_optimization_method = 'gd'; % for reference (centralized SGD)
end

%% Common for all the distributed GD based schemes
% Struct to save information throughout epochs and updates
% doubly stochastic matrix for two star topoloy is fixed
ll = 0.8; rr = 0.2;
A = [ll 0  0  0  rr 0  0  0  0  0;  ...
     0  ll 0  0  rr 0  0  0  0  0;  ...
     0  0  ll 0  rr 0  0  0  0  0;  ...
     0  0  0  ll rr 0  0  0  0  0;  ...
     rr rr rr rr 0  rr 0  0  0  0;  ...
     0  0  0  0  rr 0  rr rr rr rr; ...
     0  0  0  0  0  rr ll 0  0  0;  ...
     0  0  0  0  0  rr 0  ll 0  0;  ...
     0  0  0  0  0  rr 0  0  ll 0;  ...
     0  0  0  0  0  rr 0  0  0  ll];
assert(nrof_workers==10); % since this A matrix is defined for 10 nodes only
nrof_signaling_exchange = [1; 1; 1; 1; 5; 5; 1; 1; 1; 1];

for ii = 1:size(A,1)
    [~, neighbours{ii}] = find(A(ii,:) > 0);
end

%%

switch step_size_method_number
    case 1
        step_size_method  = 'fixed';
    case 2
        step_size_method  = 'decay1'; % diminishing (step size decays every epoch iteration but also utilizes the nr of minibatches so far)
    case 3
        step_size_method  = 'decay2'; % diminishing (step size decays every epoch iteration but also utilizes the nr of minibatches so far)
            
    otherwise % valid for all optimization method; for RMSProp and AdaGrad it utilizes it as an initial value
        step_size_method  = 'fixed';
end
% step_size_W_initial_string = num2str(step_size_W_initial,'%1.0e');
% step_size_W_initial_string = strrep(step_size_W_initial_string,'.','-');


% for training the multioutput DNN,
% create an output matrix (Y_traing): nrof_nodes_output x n_train, such
% that t-th sample in the y_train is mapped as 1 in the respective Y_train
% matrix
Y_train_matrix__zeros_ones      = zeros(nrof_nodes_output, n_train);
Y_train_matrix__correct_labels  = zeros(nrof_nodes_output, n_train);
for tt = 1:n_train
    Y_train_matrix__zeros_ones(y_train_(tt),tt)     = 1; % 1: where the label is correct
    Y_train_matrix__correct_labels(y_train_(tt),tt) = y_train_(tt); % index of the label is stored
end

Y_test_matrix__zeros_ones      = zeros(nrof_nodes_output, n_test);
Y_test_matrix__correct_labels  = zeros(nrof_nodes_output, n_test);
for tt = 1:n_test
    Y_test_matrix__zeros_ones(y_test_(tt),tt)     = 1; % 1: where the label is correct
    Y_test_matrix__correct_labels(y_test_(tt),tt) = y_test_(tt); % index of the label is stored
end


% % =========================================================
% % creating linear indices of the respective output labels
% % =========================================================
% y_labels__linear_indices__train  = sub2ind([nrof_nodes_output,n_train],y_train_, (1:n_train).');
% y_labels__linear_indices__test   = sub2ind([nrof_nodes_output,n_test], y_test_,  (1:n_test).');
% 

%% Cost function and gradient handle 

switch lower(loss_function)
    case {'softmax'; 'logistic'}
        %cost_fun_handle             = @cost_softmax; % @(X, Y, W, b, hyper_par)
        grad_struct.grad_loss_func  = @gradient_softmax_loss_fun;
        
    otherwise
        % for multi-class SVM (without bias)
        %cost_fun_handle             = @cost_function_svm; % @(X, y_labels__linear_indices, W, hyper_par)
        grad_struct.grad_loss_func  = @subgradient_weight__svm_cost__per_sample; % @(X, y_labels__linear_indices, W, hyper_par)
end


% File name to save result
file_name = strcat(select_optimization_method,'__',sparsify_or_quantize_or_none,...
    '__step_size_', step_size_method,'__',num2str(nrof_epochs),'Epochs');


%% Framework of large-scale linear classifiers (SVM, or softmax-regression)

% step-size
step_struct.W_step_size        = step_size_W_initial; 
step_struct.b_step_size        = step_size_b_initial;
step_struct.lambda             = 2; 

step_struct.W_epsilon          = 1e-10;
step_struct.b_epsilon          = 1e-10;

step_struct.W_mu               = 0.9;
step_struct.b_mu               = 0.9;
step_struct.W_beta1            = 0.9;
step_struct.b_beta1            = 0.9;
step_struct.W_beta2            = 0.99;
step_struct.b_beta2            = 0.99;

step_struct.W_drop_rate        = 0.5;
step_struct.b_drop_rate        = 0.5;
step_struct.W_epochs_drop_rate = 2;
step_struct.b_epochs_drop_rate = 2;

step_struct.step_size_method   = step_size_method;
%% Initialization

[seed{1},seed{2},seed{3},seed{4},seed{5},seed{6},seed{7},seed{8},seed{9},seed{10},seed{11},seed{12}, seed{13}] = RandStream.create('mrg32k3a','NumStreams',nrof_workers+3);
% random weights/biases
weights.W                               =  randn(seed{1},nrof_nodes_output,d);
weights.b                               =  randn(seed{2},nrof_nodes_output,1);

res_struct.loss__per_worker             = zeros(nrof_workers, nrof_epochs);
res_struct.classification_accuracy      = zeros(nrof_workers, nrof_epochs);

parameters.hyper_par.logC               = 10; % not used actually (for softmax regression)
parameters.hyper_par.delta              = 10; % For SVM
parameters.hyper_par.lambda             = regularization_factor; %
parameters.sparsify_or_quantize_or_none = sparsify_or_quantize_or_none; 
parameters.sparsify_percnt_n_vec        = sparsify_percnt_n_vec; % 10 percent of the vector will be zeroed-out
parameters.quantization_bits            = quantization_bits;
parameters.bias_enable_flag             = bias_enable_flag;
parameters.select_optimization_method   = select_optimization_method;
parameters.regularization_type          = regularization_type;
for ii = 1:nrof_workers
    parameters.seed{ii} = seed{ii+3};
end

% save the results that can be used to compare them later
if ~isfolder('./res/')
    mkdir ('./res/');
end

% #########################################################################
%% training mode
% #########################################################################


for epoch_count = 1: nrof_epochs
    
    if mod(epoch_count,10)==0; fprintf('nr of epochs so far=%d \n',epoch_count); end
    
    %% divide the data set into appropraite nr of mini-batch sizes
    
       
    train_data_rand_indices_set   = randperm(seed{3}, n_train, n_train);
    perm_indices__set             = buffer(train_data_rand_indices_set, nrof_workers);    
    
    n_train__per_worker           = size(perm_indices__set, 2);
    
    %%
    
    switch lower(select_optimization_method)
        
        case {'gd'; 'sgd'; 'adagrad'; 'rmsprop'; 'nag'; 'adam'} % full GD: REFERENCE              
            
            [res_struct, weights, grad_struct, step_struct] ...
                = centralized_sgd( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_workers, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name);
        
        case {'dgd'; 'dsgd'; 'dadagrad'; 'drmsprop'; 'dnag'; 'dadam'} % CA5--exercise (a) / (c) or (d) % DECENTRALIZED (S)GD            
            
            [res_struct, weights, grad_struct, step_struct] ...
                = decentralized_sgd( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_workers, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name);
            
            
        case {'dsgd_2star_topology'; 'dadagrad_2star_topology'; 'drmsprop_2star_topology'; 'dnag_2star_topology'; 'dadam_2star_topology'} % CA5--exercise (b) or (d) % PRIMAL (S)GD            
            
            parameters.A                       = A; % doubly stochastic matrix
            parameters.nrof_signaling_exchange = nrof_signaling_exchange;
            
            [res_struct, weights, grad_struct, step_struct] ...
                = distributed_two_star__sgd( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_workers, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name);    
            
            
        case {'admm_2star_topology'} % CA5--exercise (b) or (d) % PRIMAL (S)GD            
            
            parameters.A                       = A; % doubly stochastic matrix
            parameters.nrof_signaling_exchange = nrof_signaling_exchange;
            parameters.neighbours              = neighbours;
            
            [res_struct, weights, grad_struct, step_struct] ...
                = distributed_two_star__admm( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_workers, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name);    
            
           
        otherwise
            error('unknown algorithm')
    end
    
    
    save(strcat('./res/',file_name,'.mat'), '-struct', 'res_struct');
    

    
end



end


