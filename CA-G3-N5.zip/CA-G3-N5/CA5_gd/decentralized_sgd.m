function [res_struct, weights, grad_struct, step_struct] ...
            = decentralized_sgd( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_workers, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name)

if epoch_count==1
    res_struct.total_iter_nr         = 0;
    res_struct.total_nr_of_signaling = 0;
end

res_struct.total_iter_nr = res_struct.total_iter_nr + 1; % in case of DGD, iterations are outer since no mini-batch is considered per worker

%% Decompose the training the data for each mini-batch

X_train_per_minibatch             = zeros(nrof_workers, nrof_nodes_input, n_train__per_worker);
Y_train_per_minibatch             = zeros(nrof_workers, nrof_nodes_output, n_train__per_worker);
y_train_lin_indices_per_minibatch = zeros(nrof_workers, 1, n_train__per_worker);

for n_work = 1:nrof_workers
    X_train_per_minibatch(n_work,:,:)             = X_train(:, perm_indices__set(n_work,:));
    Y_train_per_minibatch(n_work,:,:)             = Y_train_matrix__zeros_ones(:, perm_indices__set(n_work,:));       
    y_train_lin_indices_per_minibatch(n_work,:,:) = sub2ind([nrof_nodes_output,n_train__per_worker],y_train_(perm_indices__set(n_work,:)), (1:n_train__per_worker).');

end


%% training on given training-data-set per worker in decentralized fashion

grad_struct_per_worker = struct('dW',repmat({[]}, 1, nrof_workers)); 

% All workers compute their gradients
for n_work = 1:nrof_workers
                
    %% Training
    
    % run SGD
    switch lower(loss_function)
        case {'softmax'; 'logistic'}
            
            X = squeeze(X_train_per_minibatch(n_work,:,:));
            Y = squeeze(Y_train_per_minibatch(n_work,:,:));
                        
            grad_struct_per_worker_temp                      = gradient_softmax_loss_fun(X, Y, weights.W, weights.b, parameters.hyper_par);                         
            res_struct.loss__per_worker(n_work, epoch_count) = cost_softmax(X, Y, weights.W, weights.b, parameters.hyper_par);
                        
        otherwise
            % for multi-class SVM (without bias)
            X                        = squeeze(X_train_per_minibatch(n_work,:,:));
            y_labels__linear_indices = squeeze(y_train_lin_indices_per_minibatch(n_work,:,:));
                        
            grad_struct_per_worker_temp                      = subgradient_weight__svm_cost__per_sample(X, y_labels__linear_indices, weights.W, parameters.hyper_par);
            res_struct.loss__per_worker(n_work, epoch_count) = cost_function_svm(X, y_labels__linear_indices, weights.W, parameters.hyper_par);
            
    end
    
    % only W:s are required though
    [grad_struct_per_worker_temp.dW, signaling_factor] = quantize_sparsify_vector(grad_struct_per_worker_temp.dW, parameters, n_work);   
    [grad_struct_per_worker_temp.db]                   = quantize_sparsify_vector(grad_struct_per_worker_temp.db, parameters, n_work); 
    
    % copy the structs
    for fn = fieldnames(grad_struct_per_worker_temp)'
        grad_struct_per_worker(n_work).dW = grad_struct_per_worker_temp.dW;
        grad_struct_per_worker(n_work).db = grad_struct_per_worker_temp.db;
    end
        
end

%% Updated Signaling exchanges
% increase by 'nrof_workers' since the Gradients are sent from the workers
% to master.. factor 2 corresponds to the broadcast of Weights to the
% workers
res_struct.total_nr_of_signaling = res_struct.total_nr_of_signaling + signaling_factor*2*nrof_workers; 

%% 
% collect all the gradients from all the workers and take the mean
dW_master = zeros(size(grad_struct_per_worker(1).dW));
db_master = zeros(size(grad_struct_per_worker(1).db));
for n_work = 1:nrof_workers
    dW_master = dW_master + grad_struct_per_worker(n_work).dW;
    db_master = db_master + grad_struct_per_worker(n_work).db;
end
grad_struct.dW = dW_master./nrof_workers;
grad_struct.db = db_master./nrof_workers;

% Now compute weights which will be broadcasted to all the workers in the
% next round
switch lower(parameters.select_optimization_method)
    case {'dsgd'; 'dgd'}
        [weights.W, weights.b, step_struct]              = sgd(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
    case 'dadagrad'
        [weights.W, weights.b, step_struct, grad_struct] = adagrad(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
    case 'drmsprop'
        [weights.W, weights.b, step_struct, grad_struct] = rmsprop(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
    case 'dadam'
        [weights.W, weights.b, step_struct, grad_struct] = adam(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
    case 'dnag'
        [weights.W, weights.b, step_struct, grad_struct] = nesterovag(weights.W, weights.b, grad_struct, step_struct, res_struct.total_iter_nr);
end
   

    %% Prediction
    P                       = prediction_softmax_regression(X_test, weights.W, weights.b, parameters.hyper_par);
    [~, y_pred__final]      = max(P, [], 1);
    y_pred__final           = (y_pred__final).';
    [ind, ~]                = find(y_pred__final==y_test_);
    classification_accuracy = (numel(ind)/numel(y_test_))*100;
    res_struct.classification_accuracy(:, epoch_count) = classification_accuracy;
    fprintf('classification accuracy (%d epoch) = %1.2f\n', res_struct.total_iter_nr, classification_accuracy);

    if enable_online_plotting
        fig1 = figure(1);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        plot(res_struct.total_iter_nr, classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('nr of iterations');
        ylabel('(test) classification accuracy [%]');
        ylim([0 100])        
        saveas(fig1,strcat('./res/classfy_vs_iter__', file_name));
    end

    if enable_online_plotting
        fig2 = figure(2);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        plot(res_struct.total_nr_of_signaling, classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('nr of signaling exchanges (T)');
        ylabel('(test) classification accuracy [%]');
        ylim([0 100])
        saveas(fig2,strcat('./res/classfy_vs_signalng__', file_name));
    end


    if enable_online_plotting
        fig3 = figure(3);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        semilogy(res_struct.total_iter_nr, res_struct.loss__per_worker(n_work, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('nr of iterations');
        ylabel('cost');
        
        saveas(fig3,strcat('./res/loss_vs_iter__', file_name));
    end
    
    
    if enable_online_plotting
        fig4 = figure(4);
        switch 1
            case (res_struct.total_iter_nr==1)
                clf;
        end
        semilogy(res_struct.total_nr_of_signaling, res_struct.loss__per_worker(n_work, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('nr of signaling exchanges (T)');
        ylabel('cost');
        
        saveas(fig4,strcat('./res/loss_vs_signalng__', file_name));
    end
    
   

end
