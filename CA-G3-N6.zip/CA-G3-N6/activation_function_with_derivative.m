function [a, da, da1] = activation_function_with_derivative(activation_fun_type)
% Input: activation function type

% Output: function handles of given activation function type
   % a   : activation function handle
   % da  : derivative of the function handle
   % da_ : alternative derivative of the function handle for sanity check

   % [REF] see the list of the activation functions in the below reference --
   % Comparison of new activation functions in neural network for forecasting financial time series

nrof_total_layers = numel(activation_fun_type);
a   = cell(1, nrof_total_layers);
da  = cell(1, nrof_total_layers);
da1 = cell(1, nrof_total_layers);
   
for ll = 1:nrof_total_layers
    
    switch lower(activation_fun_type{ll})
        case {'relu'}
            a{ll}   = @relu; %(z, hyper_par) max(0, z);  % hyper_par is unused
            da{ll}  = @derivative_relu; %(z, hyper_par) max(sign(z),0) + (z==0).*0.5;  % for z=0, we need to add 0.5 since it is non-differentiable at z=0.
            da1{ll} = da{ll};            
        case {'sigmoid'; 'logsig'}
            a{ll}   = @(z, hyper_par) ( 1 ./ (1 + exp(-z)) );   % hyper_par is unused
            da{ll}  = @(z, hyper_par) ( ( 1 ./ (1 + exp(-z)) )) .* (1 - (1 ./ (1 + exp(-z))) ) ; % == ( exp(-z) ./ ((1 + exp(-z)).^2) ); 
            da1{ll} = @(z) ( exp(-z) ./ ((1 + exp(-z)).^2) ); 
        case {'cloglog'}
            a{ll}   = @(z, hyper_par) ( 1  - exp(-exp(z)) );   % hyper_par is unused
            da{ll}  = @(z, hyper_par) ( 1  - exp(-exp(z)) ) .* exp(z); 
            da1{ll} = da{ll}; 
        case {'cloglogm'}
            a{ll}   = @(z, hyper_par) ( 1  - 2*exp(-0.7*exp(z)) );  % hyper_par is unused
            da{ll}  = @(z, hyper_par) 1.4* exp(-0.7*exp(z)) .* exp(z);
            da1{ll} = da{ll};
        case {'gaussian'; 'se'; 'rbf'} % se reads squared-exponential
            a{ll}   = @(z, hyper_par) ( exp(-0.5 * (z.^2) ./ (hyper_par(1).^2)) );
            da{ll}  = @(z, hyper_par) ( exp(-0.5 * (z.^2) ./ (hyper_par(1).^2)) ) .* (-z./(hyper_par(1).^2));
            da1{ll} = da{ll};            
        case {'selu'} % Scaled exponential linear unit (SELU): 
            a{ll}   = @selu; %%@(z, hyper_par) hyper_par(1)*( exp(-0.5 * (z.^2) ./ (hyper_par(1).^2)) );
            da{ll}  = @derivative_selu; %@(z, hyper_par) ( exp(-0.5 * (z.^2) ./ (hyper_par(1).^2)) ) .* (-z./(hyper_par(1).^2));
            da1{ll} = da{ll};            
        case{'none'; 'identity'; 'id'; ''}
            a{ll}   = @(z, hyper_par) ( z );
            da{ll}  = @(z, hyper_par) ( z );
            da1{ll} = da{ll};
        case{'softmax'}
            a{ll}   = @softmax;
            da{ll}  = @derivative_softmax;
            da1{ll} = da{ll};
        otherwise
            error('unknown activation function types');
    end
end


end

%% Rectified linear unit (ReLU)
function out = relu(z, hyper_par)
% hyper_par is not used

%[row_neg,col_neg]    = find(z<=0); %ind2sub(size(z),find(z<=0));
[row_pos,col_pos]    = find(z>0);
%lin_indices_neg      = sub2ind(size(z),row_neg,col_neg);
lin_indices_pos      = sub2ind(size(z),row_pos,col_pos);

out                  = zeros(size(z));
out(lin_indices_pos) = z(lin_indices_pos);
end

function out = derivative_relu(z, hyper_par)
% hyper_par is not used

%[row_neg,col_neg]    = find(z<=0); %ind2sub(size(z),find(z<=0));
[row_pos,col_pos]    = find(z>0);
%lin_indices_neg      = sub2ind(size(z),row_neg,col_neg);
lin_indices_pos      = sub2ind(size(z),row_pos,col_pos);

out                  = zeros(size(z));
out(lin_indices_pos) = 1; %*z(lin_indices_pos);

end

%% Scaled exponential linear unit (SELU)
function out = selu(z, hyper_par)
% hyper_par(1) = lambda, hyper_par(2) = alpha

if ~isempty(hyper_par)
    lambda =  hyper_par(1);
    alpha  =  hyper_par(2);
else
    lambda =  1.0507;  % recommended value
    alpha  =  1.67326; % recommended value
end

[row_neg,col_neg]    = find(z<=0); %ind2sub(size(z),find(z<=0));
[row_pos,col_pos]    = find(z>0);
lin_indices_neg      = sub2ind(size(z),row_neg,col_neg);
lin_indices_pos      = sub2ind(size(z),row_pos,col_pos);

out                  = zeros(size(z));
out(lin_indices_neg) = lambda*alpha*(exp(z(lin_indices_neg))-1);
out(lin_indices_pos) = lambda*z(lin_indices_pos);
end

function out = derivative_selu(z, hyper_par)

if ~isempty(hyper_par)
    lambda =  hyper_par(1);
    alpha  =  hyper_par(2);
else
    lambda =  1.0507;  % recommended value
    alpha  =  1.67326; % recommended value
end

[row_neg,col_neg]    = find(z<=0); %ind2sub(size(z),find(z<=0));
[row_pos,col_pos]    = find(z>0);
lin_indices_neg      = sub2ind(size(z),row_neg,col_neg);
lin_indices_pos      = sub2ind(size(z),row_pos,col_pos);

out                  = zeros(size(z));
out(lin_indices_neg) = lambda*alpha*(exp(z(lin_indices_neg)));
out(lin_indices_pos) = lambda; %*z(indices_positive);

end




