function [res_struct, weights, grad_struct, step_struct] ...
            = distributed_two_star__admm( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_nodes_two_star_topology, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name)

            
if epoch_count==1
    res_struct.total_iter_nr         = 0;
    res_struct.total_nr_of_signaling = 0;
    weights.weights_per_worker       = struct('W',repmat({[]}, 1, nrof_nodes_two_star_topology)); 
    % initialization
    for i_nodes = 1:nrof_nodes_two_star_topology
        weights.weights_per_worker(i_nodes).W = weights.W;
        weights.weights_per_worker(i_nodes).b = weights.b;
    end
    weights.W = []; % just flush them out to avoid confusion
    weights.b = []; % just flush them out to avoid confusion
end

res_struct.total_iter_nr = res_struct.total_iter_nr + 1; % in case of DGD, iterations are outer since no mini-batch is considered per worker

%% Decompose the training the data for each mini-batch

X_train_per_minibatch             = zeros(nrof_nodes_two_star_topology, nrof_nodes_input, n_train__per_worker);
Y_train_per_minibatch             = zeros(nrof_nodes_two_star_topology, nrof_nodes_output, n_train__per_worker);
y_train_lin_indices_per_minibatch = zeros(nrof_nodes_two_star_topology, 1, n_train__per_worker);

for i_nodes = 1:nrof_nodes_two_star_topology
    X_train_per_minibatch(i_nodes,:,:)             = X_train(:, perm_indices__set(i_nodes,:));
    Y_train_per_minibatch(i_nodes,:,:)             = Y_train_matrix__zeros_ones(:, perm_indices__set(i_nodes,:));       
    y_train_lin_indices_per_minibatch(i_nodes,:,:) = sub2ind([nrof_nodes_output,n_train__per_worker],y_train_(perm_indices__set(i_nodes,:)), (1:n_train__per_worker).');

end


%% training on given training-data-set per worker in distributed fashion

for i_nodes = 1:nrof_nodes_two_star_topology
      
    %% Update gradients and also compute the loss/cost at every node
    
    % run SGD
    switch lower(loss_function)
        case {'softmax'; 'logistic'}
            
            X = squeeze(X_train_per_minibatch(i_nodes,:,:));
            Y = squeeze(Y_train_per_minibatch(i_nodes,:,:));
                        
            grad_struct_i_node_worker                         = gradient_softmax_loss_fun(X, Y, ...
                                                                            weights.weights_per_worker(i_nodes).W, ...
                                                                            weights.weights_per_worker(i_nodes).b, ...
                                                                            parameters.hyper_par);                         
            res_struct.loss__per_worker(i_nodes, epoch_count) = cost_softmax(X, Y, ...
                                                                            weights.weights_per_worker(i_nodes).W, ...
                                                                            weights.weights_per_worker(i_nodes).b, ...
                                                                            parameters.hyper_par);
                        
        otherwise
            % for multi-class SVM (without bias)
            X                        = squeeze(X_train_per_minibatch(i_nodes,:,:));
            y_labels__linear_indices = squeeze(y_train_lin_indices_per_minibatch(i_nodes,:,:));
                        
            grad_struct_i_node_worker                         = subgradient_weight__svm_cost__per_sample(X, y_labels__linear_indices, ...
                                                                weights.weights_per_worker(i_nodes).W, ...
                                                                parameters.hyper_par);
            res_struct.loss__per_worker(i_nodes, epoch_count) = cost_function_svm(X, y_labels__linear_indices, ...
                                                                weights.weights_per_worker(i_nodes).W, ...
                                                                parameters.hyper_par);
            
    end
    
    
    
    
    
                                          
    %% Update Signaling exchanges
    % increase by number of Weight exchanges among the nodes governed by
    % the non-zero rows of the (doubly stochastic) weight matrix A
    % excluding the given node whose weights are utilized for the consensus
    res_struct.total_nr_of_signaling = res_struct.total_nr_of_signaling + parameters.nrof_signaling_exchange(i_nodes); 
end


% Primal variables Updated According to the D-ADMM algorithm. 

% DADMM variables
U            = weights.U;
Diff         = weights.Diff;
X            = weights.X;
rho          = weights.rho;
Stop         = weights.Stop;


% Network variables
P                = nrof_nodes_two_star_topology;
neighbors        = parameters.neighbors;
partition_colors = vars_network.partition_colors;    


% Function handler
user_solver     = vars_prob.handler;


% =========================================================================
% Algorithm

n = length(X{1});

num_colors = length(partition_colors);

for color = 1 : num_colors
    
    X_aux = X;
    for p = partition_colors{color}
        
        if ~Stop(p)              % Only compute if not has not terminated
            neighbs = neighbors{p};
            Dp = length(neighbs);
            
            % Determine the sum of the X's of the neighbors       
            sum_neighbs = zeros(n,1);                        
            for j = 1 : Dp
                sum_neighbs = sum_neighbs + X{neighbs(j)};
            end
            
            % Solving each problem in the alternating direction minimization
            
            v = U{p} - rho*sum_neighbs;
            c = rho*Dp/2;
            [X_aux{p}, vars_prob] = user_solver(p, v, c, X, vars_prob);
        end
    end
    X = X_aux;
    
end
% =========================================================================

% =========================================================================
% Output

for p = 1 : P
    neighbs = neighbors{p};
    Dp = length(neighbs);
    
    % Determine the sum of the X's of the neighbors
    sum_neighbs = zeros(n,1);
    for j = 1 : Dp
        sum_neighbs = sum_neighbs + X{neighbs(j)};
    end
    
    Diff{p} = Dp*X{p} - sum_neighbs;
end

vars.Diff = Diff;
vars.X = X;


% =========================================================================





%% Plots per node


for i_nodes = 1:nrof_nodes_two_star_topology
    
    P                       = prediction_softmax_regression(X_test, weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, parameters.hyper_par);
    [~, y_pred__final]      = max(P, [], 1);
    y_pred__final           = (y_pred__final).';
    [ind, ~]                = find(y_pred__final==y_test_);
    classification_accuracy = (numel(ind)/numel(y_test_))*100;
    res_struct.classification_accuracy(i_nodes, epoch_count) = classification_accuracy;
    fprintf('classification accuracy (%d epoch and %d node) = %1.2f\n', res_struct.total_iter_nr, i_nodes, classification_accuracy);
    
    if enable_online_plotting
        fig1 = figure(1);     
        switch 1
            case (res_struct.total_iter_nr==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        plot(res_struct.total_iter_nr, classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('iterations');
        ylabel('test accuracy [%]');    
        if (res_struct.total_iter_nr==1) 
            title(sprintf('node #%d', i_nodes));
        end
        ylim([0 100])
    end
    
    if enable_online_plotting
        fig2 = figure(2);        
        switch 1
            case (res_struct.total_iter_nr==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        plot(res_struct.total_nr_of_signaling, classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('signaling (T)');
        ylabel('test accuracy [%]');    
        if (res_struct.total_iter_nr==1) 
            title(sprintf('node #%d', i_nodes));
        end
        ylim([0 100])
    end


   
    if enable_online_plotting
        figure(3);        
        switch 1
            case (res_struct.total_iter_nr==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        semilogy(res_struct.total_iter_nr, res_struct.loss__per_worker(i_nodes, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('iterations');
        ylabel('cost');
        if (res_struct.total_iter_nr==1)
            title(sprintf('node #%d', i_nodes));
        end
    end
    %name_fig=strcat('MSE_NrOfMiniBatches',num2str(epoch_count),'_',select_optimization_method);
    %cd result/plot;
    %savefig(name_fig);
    %cd ../../;
    %switch 1
    %    case enable_online_plotting.inner_loop==false
    %        close;
    %end
    
    if enable_online_plotting
        figure(4);        
        switch 1
            case (res_struct.total_iter_nr==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        semilogy(res_struct.total_nr_of_signaling, res_struct.loss__per_worker(i_nodes, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('signaling (T)');
        ylabel('cost');
        if (res_struct.total_iter_nr==1)
            title(sprintf('node #%d', i_nodes));
        end
    end
end


end
