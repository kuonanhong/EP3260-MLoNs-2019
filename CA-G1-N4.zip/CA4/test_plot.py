import matplotlib.pyplot as plt
import numpy as np


file_location = "test_vary_prob.txt"
data = np.loadtxt(file_location, delimiter=" ")

plt.figure()
plt.grid()
plt.plot(data[:, 0], linestyle='-', linewidth=1,
         color='k', label='dist gd: prob = 0')
plt.plot(data[:, 1], linestyle=':', linewidth=1,
         color='b', label='dist gd: prob = 0.3')
plt.plot(data[:, 2], linestyle='-', linewidth=1,
         color='g', label='dist gd: prob = 0.7')
plt.plot(data[:, 3], linestyle='-', linewidth=1,
         color='c', label='dist gd: prob = 0.9')
plt.plot(data[:, 4], linestyle='-', linewidth=1,
         color='r', label='dist gd: prob = 1')

#plt.legend(loc='center left', bbox_to_anchor=(1, 0.5),fontsize=18)
plt.legend(loc='upper right')
plt.ylabel('loss')
plt.xlabel('iteration counts')
plt.xlim([10, np.size(data[:, 4])])
plt.ylim([0, 13000])
plt.savefig('test_vary_prob.png', format='png', dpi=72)


file_location = "test_vary_R.txt"
data1 = np.loadtxt(file_location, delimiter=" ")

plt.figure()
plt.grid()
#plt.plot(data[:,0],linestyle='-',linewidth=0.5,color='k',label='dist gd: R = 0.1')
plt.plot(data1[:, 0], linestyle='-', linewidth=2,
         color='c', label='dist gd: R = 0.1')
plt.plot(data1[:, 3], linestyle='-', linewidth=0.5,
         color='k', label='dist gd: R = 100')
plt.plot(data1[:, 4], linestyle='-', linewidth=0.5,
         color='r', label='dist gd: R = 1000')

#plt.legend(loc='center left', bbox_to_anchor=(1, 0.5),fontsize=18)
plt.legend(loc='upper right')
plt.ylabel('loss')
plt.xlabel('iteration counts')
plt.xlim([10, np.size(data[:, 4])])
plt.ylim([0, 13000])
plt.savefig('test_vary_R.png', format='png', dpi=72)

file_location = "decentralized_{prob}_{R}.txt".format

var_prob = [0.5, 1]
var_R = [0, 1000, 10000, 100000]

for prob in var_prob:
    for R in var_R:

        plt.subplots(1, 1)
        plt.grid()
        data1 = np.loadtxt(file_location(prob=prob, R=R), delimiter=" ")
        l = plt.plot(data1, linestyle='-', linewidth=2)

        plt.legend(l, ("Client " + str(x + 1)
                       for x in range(10)), loc='upper right')
        plt.ylabel('loss')
        plt.xlabel('iteration counts')
        plt.xlim([10, np.size(data1[:, 1])])
        plt.title(file_location(prob=prob, R=R))
        # plt.ylim([0, 13000])
        plt.savefig('decentralized_{}_{}.png'.format(
            prob, R), format='png', dpi=72)
