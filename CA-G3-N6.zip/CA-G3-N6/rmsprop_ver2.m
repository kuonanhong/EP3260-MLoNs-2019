%% (mini-batch) Root Mean Squared step sizes (RMSprop)
function [W, b, step_struct, grad_prev_struct] = rmsprop_ver2(W, b, grad_struct, grad_prev_struct, step_struct, step_size_method, kk_inner, avg_index, nrof_total_layers)

% Define epsilon value for avoiding division by zero

% Define gamma as the dampening effect for close and previous iterations
% gamma = 0.9;
% % Number of accumulated past gradients
% omega = 5;

for lyr = 1:nrof_total_layers
    
%     % Size of gradient squared matrices to be created
%     size_grad_squared = size(grad_struct.W{lyr},1);
    
    switch lower(step_size_method)
        case 'fixed'
            step_struct.W(lyr).step_size = step_struct.W(lyr).step_size;
            step_struct.b(lyr).step_size = step_struct.b(lyr).step_size;
            
        case {'decay_inner'; 'decay1'}
            step_struct.W(lyr).step_size = step_struct.W(lyr).step_size / (1 + kk_inner);
            step_struct.b(lyr).step_size = step_struct.b(lyr).step_size / (1 + kk_inner);
        
        case {'decay_outer'; 'decay2'} 
            if kk_inner==1
                step_struct.W(lyr).step_size = step_struct.W(lyr).step_size / (1 + avg_index);
                step_struct.b(lyr).step_size = step_struct.b(lyr).step_size / (1 + avg_index);
            end
            
        case 'adaptive' % different from other methods
            step_struct.W(lyr).step_size = step_struct.W(lyr).step_size / (1 + step_struct.W(lyr).step_size * step_struct.lambda * kk_inner);
            step_struct.b(lyr).step_size = step_struct.b(lyr).step_size / (1 + step_struct.b(lyr).step_size * step_struct.lambda * kk_inner);
            
        otherwise
            error('unknown step size computation method');
    end
    
    gt__dW   = grad_struct.W{lyr};
    gt__db   = grad_struct.b{lyr};
    a1__dW   = ones(size(gt__dW)); % matrix of ones
    a1__db   = ones(size(gt__db)); % matrix of ones
    
    if avg_index > 1
        vt__dW_prev = grad_prev_struct.vt__dW_prev{lyr};
        vt__db_prev = grad_prev_struct.vt__db_prev{lyr};
    else
        vt__dW_prev = zeros(size(grad_struct.W{lyr}));
        vt__db_prev = zeros(size(grad_struct.b{lyr}));
    end
    
    %% Update Vt for both Weights and biases of the considered layer
    
    vt__dW           = step_struct.W(lyr).beta2 * vt__dW_prev + (1 - step_struct.W(lyr).beta2) * (gt__dW.^2 + step_struct.W(lyr).epsilon * a1__dW);
    inv_sqrt__vt__dW = 1./sqrt(vt__dW); % element-wise square-root and inverse
    grad_prev_struct.vt__dW_prev{lyr} = vt__dW;
    
    vt__db           = step_struct.b(lyr).beta2 * vt__db_prev + (1 - step_struct.b(lyr).beta2) * (gt__db.^2 + step_struct.b(lyr).epsilon * a1__db);
    inv_sqrt__vt__db = 1./sqrt(vt__db); % element-wise square-root and inverse
    grad_prev_struct.vt__db_prev{lyr} = vt__db;
   
           
    %% Update Weights and biases
    W{lyr}  = W{lyr} - step_struct.W(lyr).step_size * inv_sqrt__vt__dW .* gt__dW;
    
    b{lyr}  = b{lyr} - step_struct.b(lyr).step_size * inv_sqrt__vt__db .* gt__db;
    
    
end