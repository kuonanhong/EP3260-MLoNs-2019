 % clear variables;

function wrapper_to_main_ca6(test_case_nr,...
                  nrof_epochs, mini_batch_size,...
                  batch_norm_flag,bias_enable_flag,dropout_percent,...
                  step_size_method_number, step_size_W_initial, step_size_b_initial,...
                  opt_meth_number)
addpath 'mtimesx_20110223\'; % "borrowed" a fast multiplication of a multi-dimensional matrices 
% REF: https://se.mathworks.com/matlabcentral/fileexchange/25977-mtimesx-fast-matrix-multiply-with-multi-dimensional-support?s_tid=FX_rc1_behav
% close all;clc;
%%% INPUT
% test_case_nr                 - 1: centralized 2-layers DNN; 2: centralized 5-layers DNN; 3:  decentralized/distributed 5-layers DNN
% batch_norm_flag              - Indicates whether batch normalization is used
% bias_enable_flag             - Indicates whether bias is used
% dropout_percent              - it performs dropout when dropout_percent > 0. If dropout_percent = 0, then no dropout
% step_size_method_number      - Type of step size used
% step_size_W_initial          - Value of step size for W
% step_size_b_initial          - Value of step size for b
% opt_meth_number              - Type of optimization method: 1 is SGD, 2 is Adagrad, and 3 is RMSprop



%% Loading some predefined parameters for CA6

flag_centralized = true;
switch test_case_nr
    case {1,5} % centralized 5-layers DNN (mini-batch = 100)
        nrof_hidden_layers                   = 4;
        nrof_nodes_hidden                    = [500, 500, 500, 500];
        activation_functions                 = {'SeLu'; 'SeLu'; 'SeLu'; 'SeLu'; 'softmax'};
        hyperparameters_activation_function  = {[];      [];     [];     [];     []};
        loss_function                        = 'squared_error';
        regularization_method_number         = 2; % l2 regularization_factor
        regularization_factor                = 0.001;
        
    case 2 % centralized 2-layers DNN (mini-batch = 100) + {'SeLU'; 'softmax'};
        nrof_hidden_layers                   = 1;
        nrof_nodes_hidden                    = [2000];
        activation_functions                 = {'SeLU'; 'softmax'};
        hyperparameters_activation_function  = {[]; []};
        loss_function                        = 'squared_error';
        regularization_method_number         = 2; % l2 regularization_factor
        regularization_factor                = 0.01;
        
    case 3 % centralized 2-layers DNN (mini-batch = 100) + {'se'; 'none'};
        nrof_hidden_layers                   = 1;
        nrof_nodes_hidden                    = [2000];
        activation_functions                 = {'se'; 'none'};
        hyperparameters_activation_function  = {0.05; []};
        loss_function                        = 'squared_error';
        regularization_method_number         = 2; % l2 regularization_factor
        regularization_factor                = 0.01;
        
    case 4 % decentralized/distributed 5-layers DNN (mini-batch = 100)
        flag_centralized = false;
        %error('to Xin/Xiaolin: please enter your parameters');
        
        nrof_hidden_layers                   = 2;
        nrof_nodes_hidden                    = [1000,1000];
        activation_functions                 = {'SeLu'; 'SeLu'; 'softmax'};
        hyperparameters_activation_function  = {[];     [];    []};
        loss_function                        = 'squared_error';
        regularization_method_number         = 2; % l2 regularization_factor
        regularization_factor                = 0.001;
        
        
    otherwise
        error('unknown test case nr');
end



%% now call main function for CA6 (DNN) based on the input test case

if flag_centralized
    % centralized DNN
    main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,mini_batch_size,...
        activation_functions,hyperparameters_activation_function,...
        loss_function,...
        regularization_method_number, regularization_factor,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        opt_meth_number);
    
    
else
    % decentralized DNN (mini-batch = 100)
    main_ca6_De(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
     activation_functions,hyperparameters_activation_function,...
     regularization_method_number, regularization_factor,...
     batch_norm_flag,bias_enable_flag, dropout_percent, ...
     step_size_method_number, step_size_W_initial, step_size_b_initial,...
     1);
    
end
