function y_dropout = drop_out(x, percentage)
    
    percentage     = percentage/100;
    [m, n]         = size(x);
    y_dropout      = zeros(m, n);
    num            = round(m*n*(1-percentage));
    idx            = randperm(m*n, num);
    y_dropout(idx) = 1 / (1-percentage);
end