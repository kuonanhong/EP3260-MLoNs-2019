%% Softmax
function p = softmax(z, hyper_par)
% hyper_par(1) = lambda, hyper_par(2) = alpha

if ~isempty(hyper_par)
    logC = -hyper_par(1);    
else
    logC = -max(z,[],1);
end

p = exp(z + logC);
p = p ./ sum(p,1);
end