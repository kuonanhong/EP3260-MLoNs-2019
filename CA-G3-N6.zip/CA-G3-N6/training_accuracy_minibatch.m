% This piece of code evaluates the classification accuracy per mini-batch.
% It is not a function, but just a code within the main function. Note that
% the information herein is inherited by the main function.

% flush these intermediate variables
for lyr = 1:nrof_hidden_layers
    z_mini{lyr}           = zeros(nrof_nodes_vec(lyr+1),n_test); %#ok<*SAGROW> % output after activation
    h_mini{lyr}           = zeros(nrof_nodes_vec(lyr+1),n_test); % output before activation
    z_prime_mini{lyr}     = ones(nrof_nodes_vec(lyr+1),n_test); % output with gradient of the activation
end

[Y_pred__test_data_mini] = dnn__prediction(X_test, W, b, bias_enable_flag, size(X_test,2), nrof_total_layers, batch_norm_flag, dropout_percent, ...
    h_mini, z_mini, z_prime_mini,  ...
    a_fun, da_fun, hyperparameters_activation_function, training_mode_mini);
[~, y_pred__final_mini]    = max(Y_pred__test_data_mini, [], 1);
y_pred__final_mini           = (y_pred__final_mini-1).';
[ind_mini, ~]             = find(y_pred__final_mini==y_test);
classification_accuracy_mini(t) = (numel(ind_mini)/numel(y_test))*100;
fprintf(fid_inner,'classification accuracy (%d epoch and %d mini-batch) = %1.2f\n', epoch_count, t,classification_accuracy_mini(t));