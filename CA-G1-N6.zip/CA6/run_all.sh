#!/bin/bash

TIMEOUT=10


for LAMBDA in 0.01 0.1 1
do
  for LR in 0.01 0.1 1
  do
    for NS in 10 120 10
    do
        python3 ca3.py --lambda $LAMBDA --lr $LR --w_size NS >> runs.json
    done
  done

done
