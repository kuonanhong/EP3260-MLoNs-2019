clear variables;

close all;

%% run the given test case

select_test_case = 6;


%% Parameters according to the test case

nrof_epochs            = 30;
enable_online_plotting = true;

switch select_test_case
    case 1 % part A: Decentralized GD + Unquantized
        opt_meth_number              = 11;        
        sparsify_or_quantize_or_none = 'none';
        sparsify_percnt_n_vec        = [];
        quantization_bits            = [];
        
    case 2 % part B: Two-Star Topology Distributed SGD + Unquantized
        opt_meth_number              = 21;        
        sparsify_or_quantize_or_none = 'none';
        sparsify_percnt_n_vec        = [];
        quantization_bits            = [];
        
    case 3 % part C: Two-Star Topology Distributed Nesterov Accelerated Gradient (NAG) + Unquantized
        opt_meth_number              = 25;        
        sparsify_or_quantize_or_none = 'none';
        sparsify_percnt_n_vec        = [];
        quantization_bits            = [];
        
    case 4 % part D+A: Decentralized GD + Sparsified
        opt_meth_number              = 11;        
        sparsify_or_quantize_or_none = 'sparsify';
        sparsify_percnt_n_vec        = 50;
        quantization_bits            = [];
        
    case 5 % part D+B: Two-Star Topology Distributed SGD + Sparsified
        opt_meth_number              = 21;        
        sparsify_or_quantize_or_none = 'sparsify';
        sparsify_percnt_n_vec        = 50;
        quantization_bits            = [];
        
    case 6 % part D+A: Decentralized GD + Quantized (4 bits)
        opt_meth_number              = 11;        
        sparsify_or_quantize_or_none = 'quantize';
        sparsify_percnt_n_vec        = [];
        quantization_bits            = 4;
        
    case 7 % part D+B: Two-Star Topology Distributed SGD + Quantized (4 bits)
        opt_meth_number              = 21;        
        sparsify_or_quantize_or_none = 'quantize';
        sparsify_percnt_n_vec        = [];
        quantization_bits            = 4;
        
    otherwise
        error('undefined test case');
end

%% run the selected test case
function_for_ca5(                   ...
                    opt_meth_number,...
                    nrof_epochs,...
                    sparsify_or_quantize_or_none, ...
                    sparsify_percnt_n_vec, ...
                    quantization_bits, ...
                    enable_online_plotting ...
                    );
