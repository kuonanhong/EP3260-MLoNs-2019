function grad = subgradient_weight__svm_cost__per_sample(X, y_labels__linear_indices, W, hyper_par)

% obtaining the subgradient of SVM cost-function per sample
% cf. http://cs231n.github.io/optimization-1/#gradcompute



[n_out,d]                = size(W);   % W: n_out x d;   n_out: nrof outputs ... d: feature_vector length
n_samples                = size(X,2); % X: d x n_samples
dW                       = zeros(n_out,d, n_samples);
db                       = zeros(n_out,1); % for completeness


S_all                    = W * X; 
S_y                      = zeros(size(S_all));
indicator_fun            = zeros(n_out, n_samples); % intialized as zeros: n_out x n_samples
indicator_fun__full      = zeros(n_out, d, n_samples); % intialized as zeros: n_out x n_samples

S_y(:,:)                 = repmat(S_all(y_labels__linear_indices).', [n_out, 1]); 
margins_mat__withoutmax  = S_all - S_y + hyper_par.delta;

indicator_fun(margins_mat__withoutmax>0) = 1; % 

% modify the indicator function: at y position, it comprises negative of the sum of non-y-positions indicator values
indicator_fun(y_labels__linear_indices)    = -sum(indicator_fun,1);

indicator_fun__full(:,:,:)  = permute(repmat(indicator_fun, [1, 1, d]), [1 3 2]);
X__grad_W                   = permute(repmat(X, [1,1,n_out]), [3,1,2]);

dW(:,:,:)                   = indicator_fun__full .* X__grad_W + repmat(hyper_par.lambda*W, [1,1,n_samples]);

grad.dW                     = mean(dW,3);
grad.db                     = db; % just dummy

end


            