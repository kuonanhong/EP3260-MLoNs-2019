function main_ca5_admm()
% (MLoNs) Computer Assignment - 1
% Group 3

%% 
clear variables;
% 
close all;
% % 
clc; 
% % 
% =====================================
% Load the training and test MNIST data
% =====================================

% training data
train_x_data_file_name = 'train-images.idx3-ubyte'; % X: INPUT (images)
train_y_data_file_name = 'train-labels.idx1-ubyte'; % y: OUTPUT (label)
[X_train, y_train]    = load_mnist_data(train_x_data_file_name, train_y_data_file_name);
%%%%%%%%% for accelerating when debugging
% X_train = X_train(:,1:600);
% y_train = y_train(1:600,1);

% test data
test_x_data_file_name = 't10k-images.idx3-ubyte'; % X: INPUT (images)
test_y_data_file_name = 't10k-labels.idx1-ubyte'; % y: OUTPUT (label)
[X_test, y_test]      = load_mnist_data(test_x_data_file_name, test_y_data_file_name);

% derived parameters from the data
n_train            = size(X_train, 2); % total nr of samples
d                  = size(X_train, 1); % dimension of the feature vector
n_test             = size(X_test, 2);  % total nr of samples
d_                 = size(X_test, 1);  % dimension of the feature vector (test) should be same as train
assert(d==d_);

%% Inputs
% algorithms                = {'DGD'};

lambda = 1;

max_iter                  = 1000;
num_workers               = 10;
% size_training_batch       = n_train / num_workers;

step_size = 0.01;
% enable_cvx                = false; % it's very slow
% 
% if enable_cvx
%     run 'cvx_setup.m'
%     run 'cvx_startup.m';
% end

% Create directory to save data
if ~exist('CA5_results', 'dir')
       mkdir('CA5_results')
end
% Create directory to save figures
if ~exist('CA5_figures', 'dir')
       mkdir('CA5_figures')
end
% Open file
fileID = fopen('General_Results.txt','a+');

%% Algorithms: core processing
[w, history] = ADMM(X_train, y_train, n_train, lambda, num_workers, 0.1, 1.0);
K = length(history.val);
% plot(1:k, history.objval, 'k', 'MarkerSize', 10, 'LineWidth', 2);
% ylabel('f(x^k) + g(z^k)'); xlabel('iter (k)');
% print('-depsc','-r300',admm_t);
h = figure;
plot(18:18:K*18, history.val, 'k', 'MarkerSize', 10, 'LineWidth', 2);
ylabel('cost function'); xlabel('T');
%%%%%% only K values %%%%%%%%
[w_KK, history_KK] = ADMM_K(X_train, y_train, n_train, lambda, num_workers, 1, 0.8,0.8);
K = length(history_KK.val);
% plot(1:k, history.objval, 'k', 'MarkerSize', 10, 'LineWidth', 2);
% ylabel('f(x^k) + g(z^k)'); xlabel('iter (k)');
% print('-depsc','-r300',admm_t);
h = figure;
plot(18:18:K*18, history_KK.val, 'k', 'MarkerSize', 10, 'LineWidth', 2);
ylabel('cost function'); xlabel('T');

%%%%% only Quantize into 4 bits %%%%%%%%
[w, history_Q] = ADMM_Q(X_train, y_train, n_train, lambda, num_workers, 1, 1.0,4);
K = length(history_Q.val);
% plot(1:k, history.objval, 'k', 'MarkerSize', 10, 'LineWidth', 2);
% ylabel('f(x^k) + g(z^k)'); xlabel('iter (k)');
% print('-depsc','-r300',admm_t);
h = figure;
plot(18:18:K*18, history_Q.val, 'k', 'MarkerSize', 10, 'LineWidth', 2);
ylabel('cost function'); xlabel('T');

fclose(fileID);
end % of main function

%% Plotting functions
function plot_2d_with_4_curves(figNr, clf_flag, subplot_nr, cost_multidim_array, x_label_txt, y_label_txt)

figure(figNr); 
if clf_flag
clf;
end
% Colors
colors{1} = [1 0 0]; % red
colors{2} = [0 0 1]; % blue
colors{3} = [0 0 0]; % black
colors{4} = [141 20 223]./ 255; % dark purple
hold on;grid;box on;
plot(10*log10(squeeze(cost_multidim_array)),'LineWidth',2,'Color',colors{subplot_nr});
xlabel(x_label_txt);
ylabel(y_label_txt);
end

function plot_2d(cost_multidim_array, x_label_txt, y_label_txt)
plot(10*log10(squeeze(cost_multidim_array)),'LineWidth',2,'Color',[0 0 1]);
xlabel(x_label_txt);
ylabel(y_label_txt);
end

function plot_2d_with_4_curves_and_subplots(figNr, subplot_nr, cost_multidim_array, x_label_txt, y_label_txt,title_txt)

figure(figNr);
% Colors
colors{1} = [1 0 0]; % red
colors{2} = [0 0 1]; % blue
colors{3} = [0 0 0]; % black
colors{4} = [141 20 223]./ 255; % dark purple
hold on;grid;box on;
subplot(2,2,figNr-1);
plot(10*log10(squeeze(cost_multidim_array)),'LineWidth',2,'Color',colors{subplot_nr});
xlabel(x_label_txt);
ylabel(y_label_txt);
title(title_txt);
end

function plot_3d_mesh_with_4_subplots(figNr, clf_flag, subplot_nr, cost_multidim_array, x_label_txt, y_label_txt, z_label_txt, title_txt)

figure(figNr); 
if clf_flag
clf;
end
subplot(2,2,subplot_nr);
mesh(10*log10(squeeze(cost_multidim_array)));
view(30, 30);
shading interp;
xlabel(x_label_txt);
ylabel(y_label_txt);
zlabel(z_label_txt);
title(title_txt);
end

function plot_2d_with_4_subplots(figNr, clf_flag, subplot_nr, cost_multidim_array, x_label_txt, y_label_txt, title_txt)

figure(figNr); 
if clf_flag
clf;
end
subplot(2,2,subplot_nr);
plot(10*log10(squeeze(cost_multidim_array)));
xlabel(x_label_txt);
ylabel(y_label_txt);
title(title_txt);
end