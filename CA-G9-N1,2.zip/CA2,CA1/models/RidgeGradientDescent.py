"""
Code for Ridge Regression
"""

import numpy as np


class RidgeRegression():
    """
        Defining the hyper parameters and variables

        alpha   -
        LAMBDA  -
        J	    - Cost Function
    """
    def __init__(self, num_iters=1, alpha=0.1, LAMBDA=0.1):
        self.num_iters = num_iters
        self.alpha = alpha
        self.LAMBDA = LAMBDA

    def _compute_cost(self, X, y, w, LAMBDA):
        """Compute the value of cost function, J.
            Here J is cost function
        """
        n = X.shape[0]

        pass1 = np.dot(X,w)
        scores = np.dot(y.T,pass1)

        f_i_w = np.log(1 + np.exp(-1.0 * scores))
        L2_regularization_cost = LAMBDA * np.dot(w.T, w)
        J = 1/n * (f_i_w + L2_regularization_cost)

        return J

    def _gradient_descent(self, X, y, w, num_iters, alpha, LAMBDA):
        """
            Calculates Gradient Descent based on the parameters

        """
        n = X.shape[0]

        J_all = np.zeros((num_iters, 1))

        # perform gradient descent
        for i in range(num_iters):
            #             print('GD: w: {0}'.format(w.shape))
            J_all[i] = self._compute_cost(X, y, w, LAMBDA)

            w = w - (alpha / n) * (np.dot(X.T, (X.dot(w) - y)) + LAMBDA * w)

        return w, J_all

    def _SVRG_descent(self, X, y, w, num_iters, alpha, LAMBDA):
            """
                Calculates SVRG Descent based on the parameters

            """
            n = X.shape[0]

            J_all = np.zeros((num_iters, 1))

            # perform gradient descent
            for i in range(num_iters):
                #             print('GD: w: {0}'.format(w.shape))
                J_all[i] = self._compute_cost(X, y, w, LAMBDA)

                w = w - (alpha / n) * (np.dot(X.T, (X.dot(w) - y)) + LAMBDA * w)

            return w, J_all

    def _stochastic_gradient_descent(self, X, y, w, num_iters, alpha, LAMBDA):
        """
            Calculates Gradient Descent based on the parameters

        """
        n = X.shape[0]

        J_all = np.zeros((num_iters, 1))

        # perform stochastic gradient descent
        # for gradient decent (GD), we update the parameter by
        #
        # θnew=θold−α1m∑i=1m(hθ(x(i))−y(i))x(i)
        # For stochastic gradient decent we get rid of the sum and 1/m constant, but get the gradient for current data point x(i),y(i), where comes time saving.
        #
        # θnew=θold−α⋅(hθ(x(i))−y(i))x(i
        #
		
        for i in range(num_iters):
            #             print('GD: w: {0}'.format(w.shape))
            J_all[i] = self._compute_cost(X, y, w, LAMBDA)

            w = w - (alpha ) * (np.dot(X.T, (X.dot(w) - y)) + LAMBDA * w)

        return w, J_all


    def _SAG_descent(self, X, y, w, num_iters, alpha, LAMBDA):
        """
            Calculates SAG Descent based on the parameters

        """
        n = X.shape[0]

        J_all = np.zeros((num_iters, 1))

        # perform gradient descent
        for i in range(num_iters):
            #             print('GD: w: {0}'.format(w.shape))
            J_all[i] = self._compute_cost(X, y, w, LAMBDA)

            w = w - (alpha / n) * (np.dot(X.T, (X.dot(w) - y)) + LAMBDA * w)

        return w, J_all
	
    def fit(self, X, y):
        """Fit the model
        """
        Xn = np.ndarray.copy(X)
        yn = np.ndarray.copy(y)

        # initialise w params for linear model, from w0 to w_num_features
        w = np.zeros((Xn.shape[1]+1, 1))
        print(Xn)
        print(yn)
        # normalise the X
        self.X_mean = np.mean(Xn, axis=0)
        self.X_std = np.std(Xn, axis=0)

        print(self.X_mean)
        print(self.X_std)


        Xn = np.subtract(Xn, self.X_mean, out=Xn, casting='unsafe')

        self.X_std[self.X_std == 0] = 1
        Xn = np.divide(Xn, self.X_std, out=Xn, casting='unsafe')
        
        self.y_mean = yn.mean(axis=0)
        yn = np.subtract(yn, self.y_mean, out=yn, casting='unsafe')

        # add ones for intercept term
        Xn = np.hstack((np.ones(Xn.shape[0])[np.newaxis].T, Xn))

        self.w, self.J_all = self._gradient_descent(Xn, yn, w, self.num_iters, self.alpha, self.LAMBDA)

    def fit_stochastic(self, X, y):
        """Fit the model
        """
        Xn = np.ndarray.copy(X)
        yn = np.ndarray.copy(y)

        print(Xn.dtype)
        print(yn.dtype)


        # initialise w params for linear model, from w0 to w_num_features
        w = np.zeros((Xn.shape[1] + 1, 1))

        print(Xn)
        print(yn)
        # normalise the X
        self.X_mean = np.mean(Xn, axis=0)
        self.X_std = np.std(Xn, axis=0)

        print(self.X_mean)
        print(self.X_std)

        Xn = np.subtract(Xn, self.X_mean, out=Xn, casting='unsafe')

        self.X_std[self.X_std == 0] = 1
        Xn = np.divide(Xn, self.X_std, out=Xn, casting='unsafe')

        self.y_mean = yn.mean(axis=0)
        yn = np.subtract(yn, self.y_mean, out=yn, casting='unsafe')

        # add ones for intercept term
        Xn = np.hstack((np.ones(Xn.shape[0])[np.newaxis].T, Xn))

        self.w, self.J_all = self._stochastic_gradient_descent(Xn, yn, w, self.num_iters, self.alpha, self.LAMBDA)

    def predict(self, X):
        """
            Predict values for given X
        """
        Xn = np.ndarray.copy(X)

        Xn = np.subtract(Xn, self.X_mean, out=Xn, casting='unsafe')

        Xn = np.divide(Xn, self.X_std, out=Xn, casting='unsafe')

        Xn = np.hstack((np.ones(Xn.shape[0])[np.newaxis].T, Xn))
        return Xn.dot(self.w) + self.y_mean
