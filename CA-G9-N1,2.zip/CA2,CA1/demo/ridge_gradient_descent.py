"""
Demo of Ridge Regression (using Gradient Descent)

"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#from sklearn import linear_model

import sys
sys.path.append('../models')

# include the OLS class
from RidgeGradientDescent import RidgeRegression

data = pd.read_csv('data/hpc.txt', sep=';', header=0,low_memory=False)#,infer_datetime_format=True, parse_dates={'datetime':[0,1]}, index_col=['datetime'])

data.replace('?', np.nan, inplace=True)
data = data.drop(['Date', 'Time'], axis=1)

values = data.values.astype('float32')
data['sub_metering_4'] = (values[:,0] * 1000 / 60) - (values[:,4] + values[:,5] + values[:,6])

X = data.drop('sub_metering_4', axis = 1)
y = data['sub_metering_4']

X = X.values
n = X.shape[0]
y = y.values
X = np.reshape(np.array(X),(X.shape[0],X.shape[1]))
y = np.reshape(np.array(y),(n,1))
#print X.shape, y.shape
# pyRidge code
rig = RidgeRegression(num_iters=10000, alpha=0.00001, LAMBDA=0.05)

Xa = np.vstack(X[:, :]).astype(np.float)
print(Xa)

rig.fit(Xa, y)
outs = rig.predict(Xa)

#rig.fit_stochastic(X, y)
#outs = rig.predict(X)



plt.scatter(y, outs, color='g', alpha=0.8, label='pyLinear')
#plt.scatter(y, sklearn_pred, color='r', alpha=0.4, label='sklearn')
plt.plot([0, 400], [0, 400], 'k-', lw=2)

plt.legend()
plt.show()
