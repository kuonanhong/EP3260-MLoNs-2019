
figNr= 3;

out = getfigdata(figNr);

amountof_data = length(out);
x             = zeros(amountof_data, 1);
y             = zeros(amountof_data, 1);

for ii = 1:amountof_data
    x(ii) = out{ii}.x; 
    y(ii) = out{ii}.y; 
end

%figure(390); hold all; semilogy(y);
%figure(391); hold all; semilogy(flipud(y));
%figure(391); hold all; plot(flipud(y));