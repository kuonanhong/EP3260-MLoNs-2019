# CA 5 Communication efficiency

Split "MNIST" dataset into 10 random disjoint subsets, each for one worker,
and consider SVM classifier in the form of

$`\min_{w} \sum_{i \in [N]} f_i(\mathbf{w})`$ with $`N=10`$.

![learning curve](learning_curve.png)

With $`\rho = 5000, \lambda=0`$,

![weights](weights_1d.png)

![weights](weights_as_img.png)

## Run decentralized GD

> Run decentralized GD (from Lecture 5) with 10 workers. Characterize the convergence against the total number of signaling exchanges among all nodes, denoted by $`T`$.

## Consider two-star topology

> Consider a two-star topology with communication graph (1,2,3,4)-5-6-(7,8,9,10) and run decentralized subgradient method (from Lecture 5) and ADMM over network (from Lecture 6). Characterize the convergence against $`T`$. Tune hyperparameters to improve the convergence rate.

![topology](topology.png)

## Propose an approach

> Propose an approach to reduce $`T`$ with a marginal impact on the convergence. Do not limit your imaginations and feel free to propose any change or any solution. While being nonsense in some applications, your solution may actually make very sense in some other applications. Discuss pros and cons of your solution and possibly provide numerical evidence that it reduces T.

`FederatedAveraging` from [1] combines local SGD with a model averaging server.
Here this means that local clients do more work before the consensus step.

In the convex setting we can do average-at-the-end [4] (see [4] for more
assumptions). In the non-convex setting however, the more
local work we do, the more we optimize for the local data partition and
averaging the different parameters make less sense since we can end up in
different local minimas and averaging the solutions could make us end up in an
arbitrarily bad place.

In `FederatedAveraging`, the amount of local work is a hyper-parameter.

## Compressing

> An alternative approach to improve communication-efficiency is to compress the information message to be exchanged (usually gradients – either in primal or dual forms). Consider two compression/quantization methods for a vector: (Q1) keep only K val- ues of a vector and set the rest to zero and (Q2) represent every element with fewer bits (e.g., 4 bits instead of 32 bits).

### Q1 - sparse encoding

We set 50 % of the weights to 0 and transmit only those. This works well in
the distributed and decentralized cases where we update the gradient only for
the non-zero elements, but with ADMM we struggle to make this converge.

### Q2 - quantization

We represent the range [-1, 1] with 4 bits, i.e. $`2^{16})`$ bins. There is an
opportunity to compress and quantize these weights adaptively. However, we
choose to simply represent a large range with a few bits here, so far from
optimal. Another approach would be to use K-means quantization (for example) to
more optimally choose the quantization bins.

## Communication efficient SVRG and SAG

Communication efficiency depends on multiple factors, including the number of rounds of communication, the amount of communication per round, and the difference in cost between communication and local computation. The first factor mentioned further depends on the global convergence rate, as fewer faster convergence implies fewer rounds of communication.

An important factor to consider when optimizing the convergence rate of federated ML is the dataset partitioning among the nodes. As nodes are not necessarily homogeneous, the amount of data each node is able to store may vary, meaning that some nodes may be able to learn faster than others. Moreover, dataset partitions may not be uniformly sampled from the global distribution, implying that some features might appear more frequently in certain partitions than others. This negatively impacts the global convergence rate since each node learns a model representing its own local distribution, rather than the global distribution.

Possible solutions to address these problems in Federated SVRG (FSVRG), proposed by [3], are to introduce scaling factors, which include...

 * Scaling the local step size inversely to the partition size, i.e. nodes with few data points should have a larger stepsize.
 * Scaling the contribution of each node's gradient, to the global gradient, proportionally to the partition size, i.e. the local gradient from nodes with many data points should have a greater impact on the global gradient.
 * Scaling each node's local gradient update with a diagonal matrix, where each cell on the diagonal corresponds to the ratio between the global and local appearance frequency of a feature. In other words, a feature that appears frequently, but only locally, should not greatly impact the local gradient's magnitude.

These optimizations were shown to improve the global converegence rate of FSVRG, almost matching the convergence rate of running FSVRG on randomly sampled partitions. As fewer epochs are required for convergence, the communication efficiency also improves.

Another approach to improving communication efficiency in distributed stochastic optimization is to compute multiple local mini-batches, and communicate averages of the resulting gradient, effectively increasing the amount of local work to mask the communication cost [4]. Alternatively, the same effect can be achieved by using a larger batch size. Large batch sizes can however slow down the convergence rate. [5] proposes an algorithm for this problem, based on minibatch proximal updates, which allows an arbitrarily large batch size to be used. 

As in d) it might also be possible in SVRG and SAG to trade convergence rate for bandwidth, and vice-versa, by quantizing gradients. [6] proposes Quantized SVRG (QSVRG) for this purpose. Compared to vanilla distributed SVRG, QSVRG uses roughly 2.8 times as many bits per iteration and 8 times as many iterations. QSVRG however requires less than P(F + 2.8n)(T + 1) bits of communication per processor, with P epochs, an encoding size of F, n communication steps per iteration, and T iterations.

## References

[1] H. B. McMahan, E. Moore, D. Ramage, S. Hampson, and B. A. y Arcas, “Communication-Efficient Learning of Deep Networks from Decentralized Data,” in Proceedings of the 20th International Conference on Artificial Intelligence and Statistics, 2017, vol. 54, pp. 1273–1282.

[2] J. Konečný, “Stochastic, Distributed and Federated Optimization for Machine Learning,” 2017.

[3] J. Konečn, H. B. Mcmahan, D. Ramage, and P. Richtárik, “Federated Optimization: Distributed Machine Learning for On-Device Intelligence,” 2016.

[4] Shamir, O. and Srebro, N., 2014, September. Distributed stochastic optimization and learning. In 2014 52nd Annual Allerton Conference on Communication, Control, and Computing (Allerton) (pp. 850-857). IEEE.

[5] Wang, J., Wang, W. and Srebro, N., 2017. Memory and communication efficient distributed stochastic optimization with minibatch-prox. arXiv preprint arXiv:1702.06269.

[6] Alistarh, D., Grubic, D., Li, J., Tomioka, R. and Vojnovic, M., 2017. QSGD: Communication-efficient SGD via gradient quantization and encoding. In Advances in Neural Information Processing Systems (pp. 1709-1720).
