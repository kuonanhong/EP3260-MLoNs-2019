function d = dSigmoid(x)
d = diag(exp(-x) ./ (1 + exp(-x)) .^ 2);
end

