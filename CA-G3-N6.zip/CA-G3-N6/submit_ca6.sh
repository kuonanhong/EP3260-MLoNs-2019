#!/bin/bash 

# Function to be called in MATLAB: main_ca6
# Inputs are the number of layers and the optimization method

clear
# Inputs
#userNameStr="jmbdsj"
actFunct=$1
regularType=$2
methOptAlg=$3
stepSize=$4

# Name of the file to run - without step size as input
#fileNameStr=RunCA6_ActFunc${actFunct}OptMeth${methOptAlg}.sh
# Partial file name that contains float, which is not allowed
stepPartial=Step${stepSize}
# Removing the . in the 0.001 and replacing by -
stepStr=${stepPartial//./-}
# Concatenate the strings into the file name
fileNameStr=RunCA6_ActFunc${actFunct}OptMeth${methOptAlg}${stepStr}.sh
cat base.sh > $fileNameStr
echo "#SBATCH -J runCA6_A${actFunct}r${regularType}Opt${methOptAlg}${stepStr}.e" >> $fileNameStr
echo "#SBATCH -e error_file_ActFunc${actFunct}regularType${regularType}OptMeth${methOptAlg}${stepStr}.e" >> $fileNameStr
echo "#SBATCH -o output_file_ActFunc${actFunct}regularType${regularType}OptMeth${methOptAlg}${stepStr}.o" >> $fileNameStr
echo "module add matlab" >> $fileNameStr
echo "cd "`pwd` >> $fileNameStr
# Run the file
Prog="Run_All_Centralized_DNN_Func("$actFunct","$regularType","$methOptAlg","$stepSize")"
echo $Prog
Cmd="matlab -nojvm -nosplash -nodesktop -r \"${Prog}; quit\""
echo $Cmd >> $fileNameStr
# Save log
cd ClusterScripts && mv ../$fileNameStr . && sbatch $fileNameStr && cd ..

# Change time limit
#scontrol update jobid=<job_id> TimeLimit=<new_timelimit>
