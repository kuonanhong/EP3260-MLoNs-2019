% Run the given test case corresponding to CA6 subquestions

close all;clear;clc;

%% INPUTS
%%%%%%%%%%%%%%%%%%%%%%%%   
% Deep Neural Network
%%%%%%%%%%%%%%%%%%%%%%%%

select_test_case_nr                 = 4;                                    
                                     % 1 : centralized 5-layers DNN (mini-batch = 100) + SGD/RMSProp/AdaGrad
                                    % 2 : centralized 2-layers DNN (mini-batch = 100) + SGD only + [SeLu; Softmax]
                                       % 3 : centralized 2-layers DNN (mini-batch = 100) + SGD only + [RBF; none]
                                    % 4 : decentralized/distributed 3-layers DNN (mini-batch = 100)
                                    % 5 : centralized 5-layers DNN (mini-batch = 100) + 50%--dropout + SGD only

nrof_epochs                         = 10;

dropout_percent                     = 0; % 0: no dropout, preferably less than 50
batch_norm_flag                     = false; %'not supported yet'
bias_enable_flag                    = false;

step_size_method_number             = 1; % 1: 'fixed',  2: 'decay_inner' (SGD only), 3: 'decay_outer' (SGD only)
step_size_W_initial                 = 0.0275; %225;
step_size_b_initial                 = 0.0275; %225;


mini_batch_size                     = 100;

%% Run the given test case (overwrite some preferred parameters)

if (1==select_test_case_nr) 
    % SGD
    wrapper_to_main_ca6(select_test_case_nr,...
        nrof_epochs, mini_batch_size,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        1);
    
    % AdaGrad
    close all;clc;
    
    wrapper_to_main_ca6(select_test_case_nr,...
        nrof_epochs, mini_batch_size,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        2);
    
    % RMSProp
    close all;clc;
    wrapper_to_main_ca6(select_test_case_nr,...
        nrof_epochs, mini_batch_size,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        3);
            
elseif (2==select_test_case_nr) || (3==select_test_case_nr)
    % SGD
    bias_enable_flag                    = true;
    step_size_W_initial                 = 0.1; % overwrite some parameter
    step_size_b_initial                 = 0.1; % overwrite some parameter

    wrapper_to_main_ca6(select_test_case_nr,...
        nrof_epochs, mini_batch_size,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        1);
    
elseif (4==select_test_case_nr)
    
    %error('RUN DECENTRALIZED HERE');
    wrapper_to_main_ca6(select_test_case_nr,...
        nrof_epochs, mini_batch_size,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        1);
    
elseif (5==select_test_case_nr)
    
    % SGD with dropout
    dropout_percent = 50;
    wrapper_to_main_ca6(select_test_case_nr,...
        nrof_epochs, mini_batch_size,...
        batch_norm_flag,bias_enable_flag,dropout_percent,...
        step_size_method_number, step_size_W_initial, step_size_b_initial,...
        1);
    
else
    error('Unknown test case');
    
end


