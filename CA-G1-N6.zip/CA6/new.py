import numpy as np
import os
import mnist
from scipy.special import expit, logsumexp
import matplotlib.pyplot as plt
from dnn import mk_mlp_ws, mlp, reg


def SGD(X, y, ws_0, lmbda, learning_rate, batch_size=1):
    N, D = X.shape
    sampler = random_sampler(N, batch_size)

    ws = [w.copy() for w in ws_0]

    for ix in sampler:
        loss, f_bp, acc = mlp(ws, X[ix], y[ix])
        f_grad = f_bp(1)

        _, r_bp = reg(ws)
        r_grad = r_bp(1)

        for w, ld, rd in zip(ws, f_grad, r_grad):
            w -= learning_rate * ld
            w -= lmbda * rd
        yield ws



def get_dataset():
    """
    Load and normalize dataset. Download if necessary.
    """
    if not os.path.exists('mnist.pkl'):
        mnist.init()
    x_train, y_train, x_test, y_test = mnist.load()

    #x_train = preprocessing.normalize(x_train, norm='l2')
    #x_test = preprocessing.normalize(x_test, norm='l2')

    return x_train, y_train, x_test, y_test


def random_sampler(N, batch=1, buffersize=10000):
    """
    A generator of random indices from 0 to N.
    params:
    N: upper bound of the indices
    batch: Number of indices to return per iteration
    buffersize: Number of numbers to generate per batch
                (this is only a computational nicety)
    """

    S = int(np.ceil(buffersize / batch))

    while True:
        buffer = np.random.randint(N, size=(S, batch))
        for i in range(S):
            yield buffer[i]


def main():
    x_train, y_train, x_test, y_test = get_dataset()

    B, D = x_train.shape
    B, = y_train.shape
    C = 10

    ws_0 = mk_mlp_ws(D, C, 500, 300)

    opt = SGD(x_train, y_train, ws_0, 0.001, 0.1, batch_size=128)
    for i in range(100):
        for ii, w in zip(range(100), opt):
            pass
        test_loss, _, acc = mlp(w, x_test, y_test)
        print('test loss    : {:.2f}'.format(test_loss))
        print('test accuracy: {:.2f}'.format(test_loss))

main()
