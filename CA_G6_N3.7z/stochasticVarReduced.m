function [W1, W2, w3] = stochasticVarReduced(X, y, W1, W2, w3, alpha, num_iters, lambda, epsilon)
% Initialize some useful values
T = 100;
K = floor(num_iters / T);

% Initialize some useful values
N = length(y); % number of training examples
m = size(W1,1);
n = size(W1,2);
k = size(W2,1);

GavgW1 = zeros(m, n, N);
GavgW2 = zeros(k, m, N);
Gavgw3 = zeros(k, N);

GW1 = zeros(m, n, N);
GW2 = zeros(k, m, N);
Gw3 = zeros(k, N);

gavgW1 = zeros(m, n);
gavgW2 = zeros(k, m);
gavgw3 = zeros(k, 1);

for k = 1:K
    for j = 1:N
        a3 = 2 * (w3' * sigmoid(W2 * sigmoid(W1 * X(:,j))) - y(j));
        Gavgw3(:,j) = a3 * sigmoid(W2 * sigmoid(W1 * X(:,j)));
        a2 = dSigmoid(W2 * sigmoid(W1 * X(:,j)));
        GavgW2(:,:,j) =  a2 * (w3 * sigmoid(W1 * X(:,j))') * a3;
        GavgW1(:,:,j) = dSigmoid(W1 * X(:,j)) * W2' * a2 * w3 * X(:,j)';
    end

    gavgW1 = 1/ N * reshape(sum(GavgW1,3),size(GavgW1,1),size(GavgW1,2));
    gavgW2 = 1/ N * reshape(sum(GavgW2,3),size(GavgW2,1),size(GavgW2,2));
    gavgw3 = 1/ N * sum(Gavgw3,2);
    for t = 1:T
        for j = 1:N
            a3 = 2 * (w3' * sigmoid(W2 * sigmoid(W1 * X(:,j))) - y(j));
            Gw3(:,j) = a3 * sigmoid(W2 * sigmoid(W1 * X(:,j)));
            a2 = dSigmoid(W2 * sigmoid(W1 * X(:,j)));
            GW2(:,:,j) =  a2 * (w3 * sigmoid(W1 * X(:,j))') * a3;
            GW1(:,:,j) = dSigmoid(W1 * X(:,j)) * W2' * a2 * w3 * X(:,j)';
        end
        
        r = randi(N);
        
        gW1 = GW1(:,:,j) + 2 * lambda * W1;
        gW2 = GW2(:,:,j) + 2 * lambda * W2;
        gw3 = Gw3(:,j) + 2 * lambda * w3;

        W1 = W1 - alpha * (GW1(:,:,r) - GavgW1(:,:,r) + gavgW1 + 2 * lambda * W1);
        W2 = W2 - alpha * (GW2(:,:,r) - GavgW2(:,:,r) + gavgW2 + 2 * lambda * W2);
        w3 = w3 - alpha * (Gw3(:,r) - Gavgw3(:,r) + gavgw3 + 2 * lambda * w3);
    end
%     if norm(g) <= epsilon
%         break;
%     end
end

end

