function [Y_pred__mini_batch,h, z, z_prime] = dnn__prediction(X_in, W, b, bias_enable_flag, mini_batch_size, nrof_total_layers, batch_norm_flag, dropout_percent,...
                                                                          h, z, z_prime, ...
                                                                          a_fun, da_fun, hyperparameters_activation_function, training_flag)
% =================================================================
% feedforward (or prediction) mode
% =================================================================
% predict output y given input x based on the current weights
for lyr = 1:nrof_total_layers
    hyper_par  = hyperparameters_activation_function{lyr};
    switch 1
        case lyr==1
            % for the first layer: mapping from input layer -> hidden layer
            % perform: activation(W*x + b)            
            %C            = mul_2dmatsx_1dvecsx(W{lyr},X_in); % linear transformation
            C            = W{lyr} * X_in; 
            %tic; C            = mtimesx(W{lyr},X_in); toc; % linear transformation
            
            h{lyr}       = C + bias_enable_flag * repmat(b{lyr}, [1, mini_batch_size]); % apply biases
            
            z{lyr}       = a_fun{lyr}(h{lyr}, hyper_par);  % apply activation function
            z_prime{lyr} = da_fun{lyr}(h{lyr}, hyper_par); % applying the derivative of the activation function--used for the gradient computation
            
            % Dropout
            switch 1
                case (dropout_percent>0)
                    if (training_flag==1)    % train mode                        
                        y_dropout     = drop_out(z{lyr}, dropout_percent);                        
                        z{lyr}        = z{lyr} .* y_dropout;
                        z_prime{lyr}  = z_prime{lyr} .* y_dropout;
                    else % test mode
                        W{lyr} = W{lyr}; %.* p; % scale the weights by the probability
                    end
            end
            
            % for batch normalization
            switch 1 
                case batch_norm_flag==1
                    disp('batch norm is NOT done'); % write batch normalization
            end
            
%         case lyr==nrof_total_layers
%                        
%             % no dropout for the output layer
%             
%             % for the output layer
%             C                   = W{lyr} * z{lyr-1}; %mul_2dmatsx_1dvecsx(W{lyr},z{lyr-1}); % linear transformation
%             Y_pred__mini_batch  = C + bias_enable_flag * repmat(b{lyr}, [1, mini_batch_size]); %W{lyr} * z{lyr-1} + (b{lyr});
%             
%             switch 1
%                 case batch_norm_flag==1
%                     disp('batch norm is NOT done'); % [Question] Do we need batch normalization at the output layer?
%             end
%                         
            
        otherwise                                  
                  
            C            = W{lyr} * z{lyr-1}; %mul_2dmatsx_1dvecsx(W{lyr},z{lyr-1}); % linear transformation             
            h{lyr}       = C + bias_enable_flag * repmat(b{lyr}, [1, mini_batch_size]);            
            z{lyr}       = a_fun{lyr}(h{lyr}, hyper_par);
            z_prime{lyr} = da_fun{lyr}(h{lyr}, hyper_par);
            
            % Dropout (and no dropout for the output layer)
            switch 1
                case (dropout_percent>0) && (lyr<nrof_total_layers)
                    if (training_flag==1)    % train mode                        
                        y_dropout       = drop_out(z{lyr}, dropout_percent);   %   z{lyr-1} input is used only for the size                   
                        z{lyr}          = z{lyr} .* y_dropout;
                        z_prime{lyr}    = z_prime{lyr} .* y_dropout;
                    else % test mode
                        W{lyr} = W{lyr}; %.* p; % scale the weights by the probability
                    end
            end
                        
            switch 1 
                case batch_norm_flag==1
                    disp('batch norm is NOT done'); % write batch normalization
            end
            
             if lyr==nrof_total_layers
                 Y_pred__mini_batch = z{lyr}; % for the output layer
            end
            
    end
end
end