% Run for the three algorithms when using 9 epochs each
%close all;clear;clc;

function Run_All_Centralized_DNN_2(activation_function_number,regularization_method_number,methOptAlg,step_size_initial)
%% INPUTS
%%%%%%%%%%%%%%%%%%%%%%%%
% For DNN
%%%%%%%%%%%%%%%%%%%%%%%%
nrof_epochs                = 10;

nrof_hidden_layers         = 3; % not including the input and output layers
nrof_nodes_hidden          = 2000; % total number of nodes to be split in layers 
split_nodes_layers_equal   = false; % true means equal splitting and false means the first layer gets half and the others are equal
% Ex: 2000 and true with 3 layers -> [1e3 500 500]

%activation_function_number          = 3; %{1 is 'sigmoid', 2 is 'ReLu', and 3 is 'se'
hyperparameters_activation_function = ones(1,nrof_hidden_layers+1); % only used for SE/RBF kernel

%regularization_method_number        = 2; % 1: 'nuclear' norm (TBD); 2: 'l2' norm; >3 is no regularization
regularization_factor               = 0.01; 

batch_norm_flag                     = false; %'not supported yet'
bias_enable_flag                    = true;

step_size_method_number             = 1; % 1: 'fixed',  2: 'decay_inner' (SGD only), 3: 'decay_outer' (SGD only)
step_size_W_initial                 = step_size_initial;
step_size_b_initial                 = step_size_initial;



%% Run all three optimization methods
% SGD
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
%                   activation_function_number,hyperparameters_activation_function,...
%                   regularization_method_number, regularization_factor,...
%                   batch_norm_flag,bias_enable_flag,...
%                   step_size_method_number, step_size_W_initial, step_size_b_initial,...
%                   1);
% % RMSprop
% close all;clc;
% main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
%                   activation_function_number,hyperparameters_activation_function,...
%                   regularization_method_number, regularization_factor,...
%                   batch_norm_flag,bias_enable_flag,...
%                   step_size_method_number, step_size_W_initial, step_size_b_initial,...
%                   3);
% AdaGrad
close all;clc;
main_ca6(nrof_epochs,nrof_hidden_layers,nrof_nodes_hidden,...
                  activation_function_number,hyperparameters_activation_function,...
                  regularization_method_number, regularization_factor,...
                  batch_norm_flag,bias_enable_flag,...
                  step_size_method_number, step_size_W_initial, step_size_b_initial,...
                  methOptAlg);


end