%% AdaGrad
function [W, b, step_struct, grad_struct] = nesterovag(W, b, grad_struct, step_struct, iter_nr)

% Define epsilon value for avoiding division by zero

% Define gamma as the dampening effect for close and previous iterations
% gamma = 0.9;
% % Number of accumulated past gradients
% omega = 5;

[alpha_W_step_size, alpha_b_step_size] = update_step_size(step_struct, iter_nr);

gt__dW   = grad_struct.dW;
gt__db   = grad_struct.db;

if iter_nr > 1
    vt__dW_prev = grad_struct.vt__dW_prev;
    vt__db_prev = grad_struct.vt__db_prev;
else
    vt__dW_prev = zeros(size(grad_struct.dW));
    vt__db_prev = zeros(size(grad_struct.db));
end

%% Update mt and Vt for both Weights and biases 

vt__dW                  = step_struct.W_mu * vt__dW_prev + (gt__dW);
grad_struct.vt__dW_prev = vt__dW;

vt__db                  = step_struct.b_mu * vt__db_prev + (gt__db);
grad_struct.vt__db_prev = vt__db;

%% Update Weights and biases
W  = W - alpha_W_step_size * (gt__dW + step_struct.W_mu * vt__dW);

b  = b - alpha_b_step_size * (gt__db + step_struct.b_mu * vt__db);