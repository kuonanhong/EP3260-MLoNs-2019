%% (mini-batch) Stochastic Gradient Descent
function [W, b, step_struct] = sgd(W, b, grad_struct, step_struct, iter_nr)

% switch lower(step_struct.step_size_method)
%     case 'fixed'
%         alpha_W_step_size = step_struct.W_step_size;
%         alpha_b_step_size = step_struct.b_step_size;       
%    
%     case 'adaptive' % different from other methods
%         alpha_W_step_size = step_struct.W_step_size / (1 + step_struct.W_step_size * step_struct.lambda * iter_nr);
%         alpha_b_step_size = step_struct.b_step_size / (1 + step_struct.b_step_size * step_struct.lambda * iter_nr);
%         
%     otherwise
%         error('unknown step size computation method');
% end

[alpha_W_step_size, alpha_b_step_size] = update_step_size(step_struct, iter_nr);

W_prev = W;
b_prev = b;

dW_prev = grad_struct.dW;
db_prev = grad_struct.db;

% Update Weights and biases
W  = W_prev - alpha_W_step_size * dW_prev;

b  = b_prev - alpha_b_step_size * db_prev;

% Update the step-sizes
%step_struct.W_step_size = alpha_W_step_size; 
%step_struct.b_step_size = alpha_b_step_size; 

% % Saving data
% % Gradient Descent
% str_GD = strcat('CA2_results/fullGD_',algo_struct.alpha_str,'_Lambda',num2str(lambda));
% save(strcat(str_GD,'.mat'),'w_vs_iter','cost_vs_iter','step_vs_iter',...
%     'norm_grad_vs_iter');