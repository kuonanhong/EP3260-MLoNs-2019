%% AdaGrad
function [W, b, step_struct, grad_struct] = adam(W, b, grad_struct, step_struct, iter_nr)

% Define epsilon value for avoiding division by zero

% Define gamma as the dampening effect for close and previous iterations
% gamma = 0.9;
% % Number of accumulated past gradients
% omega = 5;

[alpha_W_step_size, alpha_b_step_size] = update_step_size(step_struct, iter_nr);

gt__dW   = grad_struct.dW;
gt__db   = grad_struct.db;
a1__dW   = ones(size(gt__dW)); % matrix of ones
a1__db   = ones(size(gt__db)); % matrix of ones

if iter_nr > 1
    mt__dW_prev = grad_struct.mt__dW_prev;
    mt__db_prev = grad_struct.mt__db_prev;
    
    vt__dW_prev = grad_struct.vt__dW_prev;
    vt__db_prev = grad_struct.vt__db_prev;
else
    mt__dW_prev = zeros(size(grad_struct.dW));
    mt__db_prev = zeros(size(grad_struct.db));
    
    vt__dW_prev = zeros(size(grad_struct.dW));
    vt__db_prev = zeros(size(grad_struct.db));
end

%% Update mt and Vt for both Weights and biases 

mt__dW                  = step_struct.W_beta1 * mt__dW_prev + (1 - step_struct.W_beta1) * (gt__dW);
vt__dW                  = step_struct.W_beta2 * vt__dW_prev + (1 - step_struct.W_beta2) * (gt__dW.^2);
inv_sqrt__vt__dW        = 1./sqrt(vt__dW + step_struct.W_epsilon * a1__dW); % element-wise square-root and inverse
grad_struct.mt__dW_prev = mt__dW;
grad_struct.vt__dW_prev = vt__dW;

mt__db                  = step_struct.b_beta1 * mt__db_prev + (1 - step_struct.b_beta1) * (gt__db);
vt__db                  = step_struct.b_beta2 * vt__db_prev + (1 - step_struct.b_beta2) * (gt__db.^2);
inv_sqrt__vt__db        = 1./sqrt(vt__db + step_struct.b_epsilon * a1__db); % element-wise square-root and inverse
grad_struct.mt__db_prev = mt__db;
grad_struct.vt__db_prev = vt__db;

%% Update Weights and biases
W  = W - alpha_W_step_size * inv_sqrt__vt__dW .* mt__dW;

b  = b - alpha_b_step_size * inv_sqrt__vt__db .* mt__db;