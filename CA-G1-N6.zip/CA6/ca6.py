import matplotlib.pyplot as plt
import os
import numpy as np
import argparse
import sys
import time
import dnn
import mnist  # From https://github.com/hsjeong5/MNIST-for-Numpy
from scipy.special import expit, logit
from sklearn import preprocessing
import copy
import math


def two_star_topology_adj_matrix(num_workers=6):
    """
    Consider a two-star topology with communication graph
    (1,2)-3-4-(5,6) and run decentralized subgradient method.
    =>
    (0,1)-2,3-(4,5) and run decentralized subgradient method.

    Note that if we have more workers, the extra workers will not be
    connected to anyone else.
    """

    A = np.zeros((num_workers, num_workers))

    # Everyone is connected to themselves
    for m in range(num_workers):
        A[m, m] = 1

    # Nodes 0-1 are connected to node 2
    for m in [0, 1]:
        A[m, 2] = A[2, m] = 1

    # Nodes 6-9 are connected to node 5
    for m in [4, 5]:
        A[m, 3] = A[3, m] = 1

    # Nodes 4 and 5 are connected to each other
    A[2, 3] = A[3, 2] = 1

    # Divide a column of the matrix with the sum of the column.
    A = A / np.sum(A, axis=0)

    print("Adjacency matrix A: {}".format(A))
    return A


def get_data_slice(x_train, y_train, n_gp, num_workers=6):
    """
    Slice the data for this client
    """

    batchsize = math.floor(x_train.shape[0] / num_workers)

    end_idx = min((n_gp + 1) * batchsize, x_train.shape[0]) - 1
    start_idx = n_gp * batchsize

    A_slice = x_train[start_idx:end_idx, :]
    b_slice = y_train[start_idx:end_idx]

    return A_slice, b_slice


def cost(X, y, ws):
    loss, backward, acc = dnn.mlp(ws, X, y)
    return loss, acc


def random_sampler(N, batch=1, buffersize=10000):
    """
    A generator of random indices from 0 to N.
    params:
    N: upper bound of the indices
    batch: Number of indices to return per iteration
    buffersize: Number of numbers to generate per batch
                (this is only a computational nicety)
    """

    S = int(np.ceil(buffersize / batch))

    while True:
        buffer = np.random.randint(N, size=(S, batch))
        for i in range(S):
            yield buffer[i]


def DecentralizedSGD(X, y, ws_0, lmbda, global_learning_rate, learning_rate_policy=None, batch_size=1):
    N, D = X.shape
    num_workers = 6
    ws = [w.copy() for w in ws_0]
    n = len(ws)
    A = two_star_topology_adj_matrix(num_workers)

    worker_ws = [[w.copy() for w in ws_0] for _ in range(num_workers)]

    while True:
        for n_gp in range(num_workers):

            A_slice, b_slice = get_data_slice(X, y, n_gp)

            opt = SGD(A_slice, b_slice, worker_ws[n_gp], lmbda, global_learning_rate, learning_rate_policy, batch_size=batch_size)
            worker_ws[n_gp] = next(opt)
            #ws_prime.append(next(opt))


        for layer_ix, layer_ws in enumerate(zip(*worker_ws)):
            new_layer_weights = np.split(np.einsum('ij,ixy->jxy', A, np.stack(layer_ws)), num_workers)
            for worker_ix in range(num_workers):
                worker_ws[worker_ix][layer_ix] = new_layer_weights[worker_ix][0]


        yield worker_ws[3]



def DistributedSGD(X, y, ws_0, lmbda, global_learning_rate, learning_rate_policy=None, batch_size=1):
    N, D = X.shape
    num_workers = 6
    ws = [w.copy() for w in ws_0]
    n = len(ws)

    while True:

        ws_agg = [np.zeros_like(w) for w in ws]

        for n_gp in range(num_workers):

            A_slice, b_slice = get_data_slice(X, y, n_gp)

            opt = SGD(A_slice, b_slice, ws, lmbda, global_learning_rate,
                      learning_rate_policy, batch_size=batch_size)

            ws_prime = next(opt)
            for w_a, w_p in zip(ws_agg, ws_prime):
                w_a += w_p / num_workers
        ws = ws_agg
        yield ws


def SGD(X, y, ws_0, lmbda, global_learning_rate, learning_rate_policy=None, batch_size=1, smoothing_factor = 1e-8, gamma = 0.9, norm=dnn.l2):
    N, D = X.shape
    sampler = random_sampler(N, batch_size)
    previousG = [np.zeros((l.shape[0], 1)) for l in ws_0]
    previousv = [np.zeros(l.shape) for l in ws_0]

    ws = [w.copy() for w in ws_0]

    n = len(ws)
    # previousGrads = [np.zeros((l.shape[0],1)) for l in ws]
    for ix in sampler:

        loss, backward, acc = dnn.mlp(ws, X[ix], y[ix])
        cost, backward1 = dnn.reg(ws, norm)

        grads = backward(1)
        grads2 = backward1(1)
        for w_ix, ld, rd, G, v in zip(ws, grads, grads2, previousG, previousv):


            if learning_rate_policy == "AdaGrad":
                G += np.sum(ld ** 2, axis=1)[:, np.newaxis]
                learning_rate = global_learning_rate / (np.sqrt(G + smoothing_factor))
                w_ix -= np.multiply(learning_rate, ld) + (lmbda / N) * rd
            elif learning_rate_policy == "RMSProp":
                v += (1 - gamma) * ((ld ** 2) - v)
                # v = gamma * v + (1 - gamma) * (ld ** 2)
                learning_rate = global_learning_rate / np.sqrt(v + smoothing_factor)
                w_ix -= learning_rate * ld + (lmbda / N) * rd
            elif learning_rate_policy == "Constant":
                w_ix -= global_learning_rate * ld + (lmbda / N) * rd
            elif learning_rate_policy == "Diminishing":
                global_learning_rate -= np.exp(smoothing_factor)
                w_ix -= global_learning_rate * ld + (lmbda / N) * rd


        yield ws


def SVRG(X, y, ws, lmbda, learning_rate, T=100):
    """
    Stochastic variance reduced gradient
    """
    N, D = X.shape

    sampler = random_sampler(N, T)


    for batch in sampler:
        ws_t = [w.copy() for w in ws]
        loss, backward, acc = dnn.mlp(ws_t, X, y)
        mean_grads = backward(1)

        for ix in batch:

            _, backward_s, _ = dnn.mlp(ws, X[[ix]], y[[ix]])
            _, backward_t, _ = dnn.mlp(ws_t, X[[ix]], y[[ix]])
            grads_s = backward_s(1)
            grads_t = backward_t(1)

            #_, backward_req = dnn.reg(ws)

            #grads_iter = backward_iter(1)
            #grad_req = backward_req(1)
            #m = X[ix][np.newaxis, :].shape[0]
            for w_ix, ld, fg, mg in zip(ws, grads_s, grads_t, mean_grads):
                w_ix -= learning_rate * (ld - fg + mg)

        yield ws



def iterate(opt, NN, training_loss,
            testing_loss, iterations=100, inner=1, name="NoName", lr_type="NoName", batch_size=1):
    """
    This function takes an optimizer and returns a loss history for the
    training and test sets.
    """
    train_loss, train_acc = training_loss(NN)
    test_loss, test_acc = testing_loss(NN)
    loss_hist_train = [train_loss]
    loss_hist_test = [test_loss]
    acc_hist_train = [train_acc()]
    acc_hist_test = [test_acc()]

    nn = [NN]
    clock = [0]
    #
    sys.stdout.flush()
    start = time.time()
    for iteration in range(iterations):
        for _ in range(inner):
            NN = next(opt)
        clock.append(time.time() - start)
        nn.extend([NN])
        # ws.extend([W])

        train_loss,train_acc = training_loss(NN)
        loss_hist_train.append(train_loss)
        acc_hist_train.append(train_acc())

        test_loss,test_acc = testing_loss(NN)
        loss_hist_test.append(test_loss)
        acc_hist_test.append(test_acc())

        print("{}; Learning Type: {}; Batch Size: {}; Iteration: {}; Training Loss:{}; Test Loss:{}; Train Acc:{}; Test Acc:{}".format(name, lr_type, batch_size, iteration + 1, train_loss, test_loss, train_acc(), test_acc()))
        sys.stdout.flush()

    return loss_hist_train, loss_hist_test, acc_hist_train, acc_hist_test, clock

def get_dataset():
    """
    Load and normalize dataset. Download if necessary.
    """
    if not os.path.exists('mnist.pkl'):
        mnist.init()
    x_train, y_train, x_test, y_test = mnist.load()

    return x_train, y_train, x_test, y_test


def main():

    # Should be a hyperparameter that we tune, not an argument
    parser = argparse.ArgumentParser()
    parser.add_argument('--lambda', type=float, default=0.01, dest='lmbda')
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--iterations', type=int, default=100)

    args = parser.parse_args()

    print("Lambda {}".format(args.lmbda))
    print("LR {}".format(args.lr))
    print("Iterations {}".format(args.iterations))

    x_train, y_train, x_test, y_test = get_dataset()
    N,D = x_train.shape

    # #
    # BEGIN testing code for optimizers
    #
    def training_loss(NN):
        loss, acc = cost(x_train, y_train,NN)
        return loss, acc
    #
    def testing_loss(NN):
        loss, acc = cost(x_test, y_test, NN)
        return loss, acc
    # #
    iterations = args.iterations
    # #
    fig, ax = plt.subplots(4, 1, figsize=(16, 8))
    # #
    optimizer_settings = [
        {
            "name": "SGD_l1",
            "lmbda": args.lmbda,
            "lr_value": args.lr,
            "lr_type": "Constant",
            "inner": 100,
            "batch_size": 1,
            "norm": dnn.l2
        },
        {
            "name": "DistributedSGD",
            "lmbda": args.lmbda,
            "lr_value": args.lr,
            "lr_type": "Constant",
            "inner": 100,
            "batch_size": 64,
            "norm": dnn.l2
        },
        {
            "name": "DecentralizedSGD",
            "lmbda": args.lmbda,
            "lr_value": args.lr,
            "lr_type": "Constant",
            "inner": 100,
            "batch_size": 64,
            "norm": dnn.l2
        },


        # {
        #     "name": "SGD",
        #     "lmbda": args.lmbda,
        #     "lr_value": args.lr,
        #     "lr_type": "Constant",
        #     "inner": 1000,
        #     "batch_size": 64,
        #     "norm": dnn.l2
        # },
        # {
        #     "name": "SVRG",
        #     "lmbda": args.lmbda,
        #     "lr_value": args.lr,
        #     "lr_type": "Constant",
        #     "inner": 1,
        #     "batch_size": 1
        # }

    ]
    # #
    # number_of_layers = np.arange(1,10)
    # number_of_neurons = np.arange(500,1000,100)
    # for num_of_layers in number_of_layers:
    #     for num_of_neurons in number_of_neurons:
    for opt_props in optimizer_settings:
        # print("Number of layers {}; Number of Neurons{}".format(num_of_layers, number_of_neurons))
        NN = dnn.mk_mlp_ws(D, 10, 400, 200)
        # NN = construct_neural_network(D, 10, args.n_hidden_layers, args.n_size)
        # print(opt_props)
        optimizer = {
            "SGD_l1": SGD(x_train, y_train, NN, opt_props["lmbda"], opt_props["lr_value"], opt_props["lr_type"],
                       opt_props["batch_size"], norm=opt_props["norm"]),
            "DecentralizedSGD": DecentralizedSGD(x_train, y_train, NN, opt_props["lmbda"], opt_props["lr_value"], opt_props["lr_type"],
                       opt_props["batch_size"]),
            "DistributedSGD": DistributedSGD(x_train, y_train, NN, opt_props["lmbda"], opt_props["lr_value"], opt_props["lr_type"],
                       opt_props["batch_size"]),
            "SGD": SGD(x_train, y_train, NN, opt_props["lmbda"], opt_props["lr_value"], opt_props["lr_type"],
                       opt_props["batch_size"]),
            "MiniBatch": SGD(x_train, y_train, NN, opt_props["lmbda"], opt_props["lr_value"],
                             opt_props["lr_type"], opt_props["batch_size"]),
            "SVRG": SVRG(x_train, y_train, NN, opt_props["lmbda"], opt_props["lr_value"])
        }

        #
        #     # training_loss and testing_loss includes references to the training
        #     # and test set respectively.
        #
        loss_hist_train, loss_hist_test, acc_hist_train, acc_hist_test, clock = iterate(
            optimizer[opt_props['name']],
            NN,
            training_loss, testing_loss, iterations, inner=opt_props['inner'],
            name=opt_props['name'], lr_type=opt_props['lr_type'], batch_size=opt_props['batch_size'])

        color = next(ax[0]._get_lines.prop_cycler)['color']

        iterations_axis = range(0, iterations + 1)
        ax[0].plot(iterations_axis, loss_hist_train,
                   label="Train loss ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="-",
                   color=color)

        ax[0].plot(iterations_axis, loss_hist_test,
                   label="Test loss ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="--",
                   color=color)

        ax[1].plot(clock, loss_hist_train,
                   label="Train loss ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="-",
                   color=color)

        ax[1].plot(clock, loss_hist_test,
                   label="Test loss ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="--",
                   color=color)

        ax[2].plot(iterations_axis, acc_hist_train,
                   label="Train Acc ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="-",
                   color=color)

        ax[2].plot(iterations_axis, acc_hist_test,
                   label="Test Acc ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="--",
                   color=color)

        ax[3].plot(clock, acc_hist_train,
                   label="Train Acc ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="-",
                   color=color)

        ax[3].plot(clock, acc_hist_test,
                   label="Test Acc ({}):LT ({})".format(opt_props['name'], opt_props["lr_type"]), linestyle="--",
                   color=color)

    ax[0].legend(loc="upper right")
    ax[0].set_xlabel(r"Iteration", fontsize=16)
    ax[0].set_ylabel("Loss", fontsize=16)
    ax[0].set_title("CA6 - Training a deep neural network")
    ax[0].set_ylim(ymin=0)

    ax[1].legend(loc="upper right")
    ax[1].set_xlabel(r"Time [s]", fontsize=16)
    ax[1].set_ylabel("Loss", fontsize=16)
    ax[1].set_ylim(ymin=0)


    ax[2].legend(loc="lower right")
    ax[2].set_xlabel(r"Iteration", fontsize=16)
    ax[2].set_ylabel("Accuracy", fontsize=16)
    ax[2].set_ylim(ymin=0)

    ax[3].legend(loc="lower right")
    ax[3].set_xlabel(r"Time [s]", fontsize=16)
    ax[3].set_ylabel("Accuracy", fontsize=16)
    ax[3].set_ylim(ymin=0)

    plt.savefig("ca6_dist.png")


if __name__ == "__main__":
    main()
