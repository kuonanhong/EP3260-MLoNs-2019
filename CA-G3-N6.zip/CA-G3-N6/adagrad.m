%% (mini-batch) Adaptive step sizes (AdaGrad)
function [W, b, step_struct, grad_prev_struct] = adagrad(W, b, grad_struct, grad_prev_struct, step_struct, step_size_method, kk_inner, avg_index, nrof_total_layers)

% Define epsilon value for avoiding division by zero
epsilon = 1e-8;
% Number of accumulated past gradients
omega = 5;

for lyr = 1:nrof_total_layers
    
    switch lower(step_size_method)
        case 'fixed'
            step_struct.W(lyr).step_size = step_struct.W(lyr).step_size;
            step_struct.b(lyr).step_size = step_struct.b(lyr).step_size;
            
        case {'decay_inner'; 'decay1'} % do
            step_struct.W(lyr).step_size = step_struct.W(lyr).step_size / (1 + kk_inner);
            step_struct.b(lyr).step_size = step_struct.b(lyr).step_size / (1 + kk_inner);
            
        case {'decay_outer'; 'decay2'}
            if kk_inner==1
                step_struct.W(lyr).step_size = step_struct.W(lyr).step_size / (1 + avg_index);
                step_struct.b(lyr).step_size = step_struct.b(lyr).step_size / (1 + avg_index);
            end
            
        case 'adaptive' % different from other methods
            step_struct.W(lyr).step_size = step_struct.W(lyr).step_size / (1 + step_struct.W(lyr).step_size * step_struct.lambda * kk_inner);
            step_struct.b(lyr).step_size = step_struct.b(lyr).step_size / (1 + step_struct.b(lyr).step_size * step_struct.lambda * kk_inner);
            
        otherwise
            error('unknown step size computation method');
    end
    
    W_prev = W{lyr};
    b_prev = b{lyr};
    
    dW_prev = grad_struct.W{lyr};
    db_prev = grad_struct.b{lyr};
    
    % If initial iteration, consider only current gradient, otherwise get
    % all of them
    if mod(avg_index,omega) == 1%avg_index == 1
        % Evaluating the updated matrix that sums previous gradient outer
        % products - Weights and biases
        dW_sum = dW_prev*dW_prev';
        grad_prev_struct.dW_sum{lyr} = dW_sum;
        db_sum = db_prev*db_prev';
        grad_prev_struct.db_sum{lyr} = db_sum;
    else
        % Evaluating the updated matrix that sums previous gradient outer
        % products - Weights and biases
        dW_sum = dW_prev*dW_prev' + grad_prev_struct.dW_sum{lyr};
        grad_prev_struct.dW_sum{lyr} = dW_sum;
        db_sum = db_prev*db_prev' + grad_prev_struct.db_sum{lyr};
        grad_prev_struct.db_sum{lyr} = db_sum;
    end
    
    % Obtain matrix "B = epsilon + sqrt(dW_sum)^-1" for weights and bias
    Bmat_W_condition = epsilon + diag(dW_sum);
    Bmat_W_condition = bsxfun(@rdivide, ones(size(Bmat_W_condition)), Bmat_W_condition);
    Bmat_b_condition = epsilon + diag(db_sum);
    Bmat_b_condition = bsxfun(@rdivide, ones(size(Bmat_b_condition)), Bmat_b_condition);
    
    % Update Weights and biases
    W{lyr}  = W_prev - step_struct.W(lyr).step_size * diag(Bmat_W_condition) * dW_prev;
    
    b{lyr}  = b_prev - step_struct.W(lyr).step_size * diag(Bmat_b_condition) * db_prev;
    
    % % Saving data
    % % Gradient Descent
    % str_GD = strcat('CA2_results/fullGD_',algo_struct.alpha_str,'_Lambda',num2str(lambda));
    % save(strcat(str_GD,'.mat'),'w_vs_iter','cost_vs_iter','step_vs_iter',...
    %     'norm_grad_vs_iter');
    
end