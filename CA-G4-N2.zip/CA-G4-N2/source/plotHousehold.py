'''
Date;
Time;
Global_active_power;
Global_reactive_power;
Voltage;
Global_intensity;
Sub_metering_1;
Sub_metering_2;
Sub_metering_3
'''


import matplotlib.pyplot as plt 
import numpy as np 

household = np.load('household_power_consumption.npy').item()

print(len(household['Date']))
print(len(household['Time']))
print(len(household['Global_active_power']))
print(len(household['Global_reactive_power']))
print(len(household['Voltage']))
print(len(household['Global_intensity']))
print(len(household['Sub_metering_1']))
print(len(household['Sub_metering_2']))
print(len(household['Sub_metering_3']))

#ftr = [3600,60,1]
#time = [sum([a*b for a,b in zip(ftr, map(int,timestr.split(':')))]) for timestr in household['Time']]
#plt.plot(time, household['Voltage'],'.')

plt.plot(household['Global_active_power'],household['Global_reactive_power'],'.')

plt.show()

