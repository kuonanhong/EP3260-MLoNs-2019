function g = sigmoid(x)
g = 1.0 ./ (1.0 + exp(-x));
end
