function [out_avg, avg_index] = recursive_average_DC(out_avg, input_instant, avg_index,avg_index_DC)

avg_index = avg_index + 1;
switch 1
    case any(avg_index == 1)
        out_avg = input_instant;
    otherwise
        
        try
            out_avg       = out_avg +  bsxfun(@times, (1./avg_index_DC), (input_instant - out_avg));            
        catch
           out_avg       = out_avg +  bsxfun(@times, (1./avg_index_DC'), (input_instant - out_avg));
        end
end