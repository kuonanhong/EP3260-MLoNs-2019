clear variables;

close all;


list_of_fig_files_to_be_converted = dir('.\fig\CA5_exercise_a_unquantized\*.fig');
path_for_tikz_file_to_be_saved    = list_of_fig_files_to_be_converted;

% font_size = 14;
% f_width   = 3;
% f_height  = 2.75;
options.fontname_txt         = 'times';
options.gca_font_size        = 14;
options.line_width           = 3;
options.marker_size          = 12;
options.xylabel_fontsize     = 18;

x_label_txt = {'nr of iterations'; ...1
               'nr of signaling exchanges (T)';...2
               'nr of iterations'; ...3
               'nr of signaling exchanges (T)';...4
               };
y_label_txt = {'(test) classification accuracy [%]';...1
               'cost '; ...2
               '(test) classification accuracy [%]';...3
               'cost '; ...4
               };
legend_location_txt = { 'southeast'; ...1
                        'southeast';...2
                        'northeast';...3
                        'southwest';...4
                        };

for ii = 1:numel(list_of_fig_files_to_be_converted)    
    openfig(list_of_fig_files_to_be_converted(ii).name);        
    %tightfigadv();
    if (1)        
        set(gca,'fontname', options.fontname_txt, 'fontsize', options.gca_font_size);
        xlabel(x_label_txt{ii}, 'fontname', options.fontname_txt, 'fontsize', options.xylabel_fontsize);
        ylabel(y_label_txt{ii},'fontname', options.fontname_txt, 'fontsize', options.xylabel_fontsize);
        legend('location', legend_location_txt{ii});
        grid on
        grid minor
    end
    cleanfigure    
    tightfig();
    
    filename_to_be_converted = strcat(path_for_tikz_file_to_be_saved, 'fig', num2str(ii),'__',list_of_fig_files_to_be_converted(ii).name);
    saveas(gcf, strrep(filename_to_be_converted,'.fig','.svg'));
    %matlab2tikz(filename_to_be_converted);
    close all;
end