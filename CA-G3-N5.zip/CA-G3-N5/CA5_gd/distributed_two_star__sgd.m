function [res_struct, weights, grad_struct, step_struct] ...
            = distributed_two_star__sgd( ...
                parameters, weights, ...
                X_train, Y_train_matrix__zeros_ones, ...
                y_train_, ...
                n_train__per_worker, perm_indices__set, ...
                X_test,y_test_,...
                loss_function, ...
                grad_struct, ...
                step_struct, ...
                nrof_nodes_input, nrof_nodes_output, nrof_nodes_two_star_topology, ...
                nrof_epochs, epoch_count, ...
                res_struct,...
                enable_online_plotting, file_name)

            
if epoch_count==1
    res_struct.total_iter_nr            = 0;
    res_struct.total_nr_of_signaling    = 0;
    weights.weights_per_worker          = struct('W',repmat({[]}, 1, nrof_nodes_two_star_topology));    
    step_struct.step_struct_per_worker  = struct('dummy',repmat({[]}, 1, nrof_nodes_two_star_topology)); 
    % initialization
    for i_nodes = 1:nrof_nodes_two_star_topology
        weights.weights_per_worker(i_nodes).W = weights.W;
        weights.weights_per_worker(i_nodes).b = weights.b;
        
        res_struct.total_iter_nr__per_worker(i_nodes)         = 0;
        res_struct.total_nr_of_signaling__per_worker(i_nodes) = 0;
                      
        for fn = fieldnames(step_struct)'
            if ~contains(fn{1}, 'step_struct_per_worker')
                step_struct.step_struct_per_worker(i_nodes).(fn{1}) = step_struct.(fn{1});
            end
        end
        
        grad_struct.grad_struct_per_worker(i_nodes).dW          = zeros(size(weights.W));
        grad_struct.grad_struct_per_worker(i_nodes).db          = zeros(size(weights.b));
        grad_struct.grad_struct_per_worker(i_nodes).vt__dW_prev = zeros(size(weights.W));
        grad_struct.grad_struct_per_worker(i_nodes).vt__db_prev = zeros(size(weights.b));
        grad_struct.grad_struct_per_worker(i_nodes).mt__dW_prev = zeros(size(weights.W));
        grad_struct.grad_struct_per_worker(i_nodes).mt__db_prev = zeros(size(weights.b));
        
    end
    weights.W = []; % just flush them out to avoid confusion
    weights.b = []; % just flush them out to avoid confusion
end

res_struct.total_iter_nr = res_struct.total_iter_nr + 1; % in case of DGD, iterations are outer since no mini-batch is considered per worker

%% Decompose the training the data for each mini-batch

X_train_per_minibatch             = zeros(nrof_nodes_two_star_topology, nrof_nodes_input, n_train__per_worker);
Y_train_per_minibatch             = zeros(nrof_nodes_two_star_topology, nrof_nodes_output, n_train__per_worker);
y_train_lin_indices_per_minibatch = zeros(nrof_nodes_two_star_topology, 1, n_train__per_worker);

for i_nodes = 1:nrof_nodes_two_star_topology
    X_train_per_minibatch(i_nodes,:,:)             = X_train(:, perm_indices__set(i_nodes,:));
    Y_train_per_minibatch(i_nodes,:,:)             = Y_train_matrix__zeros_ones(:, perm_indices__set(i_nodes,:));       
    y_train_lin_indices_per_minibatch(i_nodes,:,:) = sub2ind([nrof_nodes_output,n_train__per_worker],y_train_(perm_indices__set(i_nodes,:)), (1:n_train__per_worker).');

end

signaling_factor_per_node = zeros(nrof_nodes_two_star_topology, 1);
%% training on given training-data-set per worker in distributed fashion

for i_nodes = 1:nrof_nodes_two_star_topology
    
    res_struct.total_iter_nr__per_worker(i_nodes) = res_struct.total_iter_nr__per_worker(i_nodes) + 1;
    
    %% Update gradients and also compute the loss/cost at every node
    
    % run SGD
    switch lower(loss_function)
        case {'softmax'; 'logistic'}
            
            X = squeeze(X_train_per_minibatch(i_nodes,:,:));
            Y = squeeze(Y_train_per_minibatch(i_nodes,:,:));
                        
            grad_struct_i_node_worker                         = gradient_softmax_loss_fun(X, Y, ...
                                                                            weights.weights_per_worker(i_nodes).W, ...
                                                                            weights.weights_per_worker(i_nodes).b, ...
                                                                            parameters.hyper_par);                         
            res_struct.loss__per_worker(i_nodes, epoch_count) = cost_softmax(X, Y, ...
                                                                            weights.weights_per_worker(i_nodes).W, ...
                                                                            weights.weights_per_worker(i_nodes).b, ...
                                                                            parameters.hyper_par);
                        
        otherwise
            % for multi-class SVM (without bias)
            X                        = squeeze(X_train_per_minibatch(i_nodes,:,:));
            y_labels__linear_indices = squeeze(y_train_lin_indices_per_minibatch(i_nodes,:,:));
                        
            grad_struct_i_node_worker                         = subgradient_weight__svm_cost__per_sample(X, y_labels__linear_indices, ...
                                                                weights.weights_per_worker(i_nodes).W, ...
                                                                parameters.hyper_par);
            res_struct.loss__per_worker(i_nodes, epoch_count) = cost_function_svm(X, y_labels__linear_indices, ...
                                                                weights.weights_per_worker(i_nodes).W, ...
                                                                parameters.hyper_par);
            
    end
    
    % only W:s are required though
    [grad_struct_i_node_worker.dW, signaling_factor_per_node(i_nodes)] = quantize_sparsify_vector(grad_struct_i_node_worker.dW, parameters, i_nodes);   
    [grad_struct_i_node_worker.db]                                     = quantize_sparsify_vector(grad_struct_i_node_worker.db, parameters, i_nodes); 
    
    % Copy the structs    
    grad_struct.grad_struct_per_worker(i_nodes).dW = grad_struct_i_node_worker.dW;
    grad_struct.grad_struct_per_worker(i_nodes).db = grad_struct_i_node_worker.db;
    
    
    %% Update the weights per node accoording to the considered "A" matrix
    % step-1: form the consensus or the weights, 
    % or equivalently one could say the weighted average of weights according to A
    consensus_weights_i_node.W = zeros(size(weights.weights_per_worker(i_nodes).W));
    consensus_weights_i_node.b = zeros(size(weights.weights_per_worker(i_nodes).b));
    for j_nodes = 1:nrof_nodes_two_star_topology
        consensus_weights_i_node.W = parameters.A(i_nodes, j_nodes) * weights.weights_per_worker(j_nodes).W  + consensus_weights_i_node.W;
        consensus_weights_i_node.b = parameters.A(i_nodes, j_nodes) * weights.weights_per_worker(j_nodes).b  + consensus_weights_i_node.b;
    end
    
    
    switch 1
      case contains(lower(parameters.select_optimization_method), {'dsgd'; 'dgd'}) 
          [weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, step_struct.step_struct_per_worker(i_nodes)] ...
                                = sgd(consensus_weights_i_node.W, consensus_weights_i_node.b, ...
                                      grad_struct_i_node_worker, step_struct.step_struct_per_worker(i_nodes), res_struct.total_iter_nr__per_worker(i_nodes));
                    
      case contains(lower(parameters.select_optimization_method), {'dadagrad'}) 
          [weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, ...
              step_struct.step_struct_per_worker(i_nodes), grad_struct.grad_struct_per_worker(i_nodes)] ...
                                = adagrad(consensus_weights_i_node.W, consensus_weights_i_node.b, ...
                                    grad_struct.grad_struct_per_worker(i_nodes), step_struct.step_struct_per_worker(i_nodes), res_struct.total_iter_nr__per_worker(i_nodes));
                                
      case contains(lower(parameters.select_optimization_method), {'drmsprop'})           
          [weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, ...
              step_struct.step_struct_per_worker(i_nodes), grad_struct.grad_struct_per_worker(i_nodes)] ...
                                = rmsprop(consensus_weights_i_node.W, consensus_weights_i_node.b, ...
                                    grad_struct.grad_struct_per_worker(i_nodes), step_struct.step_struct_per_worker(i_nodes), res_struct.total_iter_nr__per_worker(i_nodes));
                                
      case contains(lower(parameters.select_optimization_method), {'dadam'}) 
          [weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, ...
              step_struct.step_struct_per_worker(i_nodes), grad_struct.grad_struct_per_worker(i_nodes)] ...
                                = adam(consensus_weights_i_node.W, consensus_weights_i_node.b, ...
                                    grad_struct.grad_struct_per_worker(i_nodes), step_struct.step_struct_per_worker(i_nodes), res_struct.total_iter_nr__per_worker(i_nodes));
                                
          
      case contains(lower(parameters.select_optimization_method), {'dnag'}) 
          [weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, ...
              step_struct.step_struct_per_worker(i_nodes), grad_struct.grad_struct_per_worker(i_nodes)] ...
                                = nesterovag(consensus_weights_i_node.W, consensus_weights_i_node.b, ...
                                    grad_struct.grad_struct_per_worker(i_nodes), step_struct.step_struct_per_worker(i_nodes), res_struct.total_iter_nr__per_worker(i_nodes));
          
          
        
    end
    
    % update the gradient structure
    
    
    
    %% Update Signaling exchanges
    % increase by number of Weight exchanges among the nodes governed by
    % the non-zero rows of the (doubly stochastic) weight matrix A
    % excluding the given node whose weights are utilized for the consensus
    res_struct.total_nr_of_signaling__per_worker(i_nodes) = res_struct.total_nr_of_signaling__per_worker(i_nodes) ...
                                                            + signaling_factor_per_node(i_nodes) * parameters.nrof_signaling_exchange(i_nodes); 
end



%% Plots per node


for i_nodes = 1:nrof_nodes_two_star_topology
    
    P                       = prediction_softmax_regression(X_test, weights.weights_per_worker(i_nodes).W, weights.weights_per_worker(i_nodes).b, parameters.hyper_par);
    [~, y_pred__final]      = max(P, [], 1);
    y_pred__final           = (y_pred__final).';
    [ind, ~]                = find(y_pred__final==y_test_);
    classification_accuracy = (numel(ind)/numel(y_test_))*100;
    res_struct.classification_accuracy(i_nodes, epoch_count) = classification_accuracy;
    fprintf('classification accuracy (%d epoch and %d node) = %1.2f\n', res_struct.total_iter_nr, i_nodes, classification_accuracy);
    
    if enable_online_plotting
        fig1 = figure(1);
        switch 1
            case (res_struct.total_iter_nr__per_worker(i_nodes)==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        plot(res_struct.total_iter_nr__per_worker(i_nodes), classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('iterations');
        ylabel('test accuracy [%]');    
        if (res_struct.total_iter_nr==1) 
            title(sprintf('node #%d', i_nodes));
        end
        ylim([0 100])
        saveas(fig1,strcat('./res/classfy_vs_iter__', file_name));
    end
    
    if enable_online_plotting
        fig2 = figure(2);
        switch 1
            case (res_struct.total_iter_nr__per_worker(i_nodes)==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        plot(res_struct.total_nr_of_signaling__per_worker(i_nodes), classification_accuracy, 'o');
        hold on;
        drawnow;
        xlabel('signaling (T)');
        ylabel('test accuracy [%]');    
        if (res_struct.total_iter_nr==1) 
            title(sprintf('node #%d', i_nodes));
        end
        ylim([0 100])
        saveas(fig2,strcat('./res/classfy_vs_signalng__', file_name));
    end


   
    if enable_online_plotting
        fig3 = figure(3);        
        switch 1
            case (res_struct.total_iter_nr==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        semilogy(res_struct.total_iter_nr, res_struct.loss__per_worker(i_nodes, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('iterations');
        ylabel('cost');
        if (res_struct.total_iter_nr==1)
            title(sprintf('node #%d', i_nodes));
        end
        saveas(fig3,strcat('./res/loss_vs_iter__', file_name));
    end
    %name_fig=strcat('MSE_NrOfMiniBatches',num2str(epoch_count),'_',select_optimization_method);
    %cd result/plot;
    %savefig(name_fig);
    %cd ../../;
    %switch 1
    %    case enable_online_plotting.inner_loop==false
    %        close;
    %end
    
    if enable_online_plotting
        fig4 = figure(4);        
        switch 1
            case (res_struct.total_iter_nr==1) && (i_nodes==1)
                clf;
        end
        subplot(2,5,i_nodes)
        semilogy(res_struct.total_nr_of_signaling__per_worker(i_nodes), res_struct.loss__per_worker(i_nodes, epoch_count), 'o');
        hold on;
        drawnow;
        xlabel('signaling (T)');
        ylabel('cost');
        if (res_struct.total_iter_nr==1)
            title(sprintf('node #%d', i_nodes));
        end
        
        saveas(fig4,strcat('./res/loss_vs_signalng__', file_name));
    end
end


end
