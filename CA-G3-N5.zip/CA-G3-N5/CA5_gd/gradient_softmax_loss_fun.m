function [grad] = gradient_softmax_loss_fun(X, Y, W, b, hyper_par)



n_out     = size(W,1);
n_samples = size(X,2);

Z         = exp(W*X + b);
P         = bsxfun(@times, Z, repmat(1./sum(Z,1), [n_out,1]));  

S         = P - Y; 
grad.dW   = (S * X.')./n_samples + hyper_par.lambda * W; % takimg mean over the samples

grad.db   = mean(S,2);


end