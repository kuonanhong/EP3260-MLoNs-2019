%% 
clear variables;
% 
close all;
% % 
clc; 
% % 


rand('seed', 3);
randn('seed', 3);

% =====================================
% Load the training and test MNIST data
% =====================================

% training data
train_x_data_file_name = 'train-images.idx3-ubyte'; % X: INPUT (images)
train_y_data_file_name = 'train-labels.idx1-ubyte'; % y: OUTPUT (label)
[X_train, y_train]    = load_mnist_data(train_x_data_file_name, train_y_data_file_name);
%%%%%%%%% for accelerating when debugging
X_train = X_train(:,1:100);
y_train = y_train(1:100,1);

% test data
test_x_data_file_name = 't10k-images.idx3-ubyte'; % X: INPUT (images)
test_y_data_file_name = 't10k-labels.idx1-ubyte'; % y: OUTPUT (label)
[X_test, y_test]      = load_mnist_data(test_x_data_file_name, test_y_data_file_name);

% derived parameters from the data
n_train            = size(X_train, 2); % total nr of samples
d                  = size(X_train, 1); % dimension of the feature vector
n_test             = size(X_test, 2);  % total nr of samples
d_                 = size(X_test, 1);  % dimension of the feature vector (test) should be same as train
assert(d==d_);




s1_label = 5;
s2_label = 7;

s1 = X_train(:, y_train == s1_label);
s2 = X_train(:, y_train == s2_label);


n = size(s1,1);
assert(n==size(s2,1));

N = size(s1,2);
M = size(s2,2);
m = N + M;

% positive examples
Y = s1;

% negative examples
X = s2;

x = [X Y];
y = [ones(1,N) -ones(1,M)];
A = [ -((ones(n,1)*y).*x)' -y'];
xdat = x';
lambda = 1.0;

% partition the examples up in the worst possible way
% (subsystems only have positive or negative examples)
p = zeros(1,m);
p(y == 1)  = sort(randi([1 2], sum(y==1),1));
p(y == -1) = sort(randi([3 4], sum(y==-1),1));

%% solve problem
[x history] = linear_svm(A, lambda, p, 1.0, 1.0);

%% Reporting

K = length(history.objval);

h = figure;
plot(1:K, history.objval, 'k', 'MarkerSize', 10, 'LineWidth', 2);
ylabel('f(x^k) + g(z^k)'); xlabel('iter (k)');

g = figure;
subplot(2,1,1);
semilogy(1:K, max(1e-8, history.r_norm), 'k', ...
    1:K, history.eps_pri, 'k--',  'LineWidth', 2);
ylabel('||r||_2');

subplot(2,1,2);
semilogy(1:K, max(1e-8, history.s_norm), 'k', ...
    1:K, history.eps_dual, 'k--', 'LineWidth', 2);
ylabel('||s||_2'); xlabel('iter (k)');
%% ploting data
%load('svm_data.mat')
%X = Data(:,1:100);
%Y = Data(:, 101:end);
%x = [W;b]
figure;
plot(X(1,:), X(2,:), 'o'); hold on;
plot(Y(1,:), Y(2,:), 'x'); hold on;
minx = min(min(X(1,:)), min(Y(1,:)));
miny = min(min(X(2,:)), min(Y(2,:)));
maxx = max(max(X(1,:)), max(Y(1,:)));
maxy = max(max(X(2,:)), max(Y(2,:)));

xx = linspace(minx, maxx);
yy = -(x(1)*xx + x(3))/x(2);
plot(xx, yy, 'k--')
xlim(1.01*[minx, maxx])
ylim(1.01*[miny, maxy])
