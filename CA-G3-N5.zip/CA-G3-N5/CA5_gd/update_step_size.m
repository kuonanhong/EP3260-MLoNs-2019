function [alpha_W_step_size, alpha_b_step_size] = update_step_size(step_struct, iter_nr)

switch lower(step_struct.step_size_method)
    case 'fixed'
        alpha_W_step_size = step_struct.W_step_size;
        alpha_b_step_size = step_struct.b_step_size;
        
    case 'decay1' % different from other methods
        alpha_W_step_size = step_struct.W_step_size / (1 + step_struct.W_step_size * step_struct.lambda * iter_nr);
        alpha_b_step_size = step_struct.b_step_size / (1 + step_struct.b_step_size * step_struct.lambda * iter_nr);
   
    case 'decay2' % different from other methods
        alpha_W_step_size = step_struct.W_step_size * step_struct.W_drop_rate^(floor(iter_nr / step_struct.W_epochs_drop_rate));
        alpha_b_step_size = step_struct.b_step_size * step_struct.b_drop_rate^(floor(iter_nr / step_struct.b_epochs_drop_rate));
        
    otherwise
        error('unknown step size computation method');
end