import numpy as np
#import os
#import mnist
from scipy.special import expit, logsumexp
#import matplotlib.pyplot as plt


def l2(x):
    """
    x : Any shape
    ret: l2 norm of x and gradient wrt. x
    """

    ret = np.sum(x ** 2)

    def backward(g):
        return g * 2 * x

    return ret, backward


def l1(x):
    """
    x: Any shape
    ret: l1 norm of x and gradient wrt. x
    """
    ret = np.sum(np.abs(x))

    def backward(g):
        return g * (np.sign(x))

    return ret, backward


def mean_f(x):
    """
    x : Any shape
    ret: scalar mean of x and gradient wrt. x
    """
    n = x.size
    a = x.mean()
    def backward(g):
        return np.ones_like(x) * g / n
    return a, backward


def logsoftmax(x, y):
    """
    x : (Batch, Classes)
    y : Batch
    ret: model log-probability of correct classes and gradient wrt. x (and accuracy function)
    """
    B, C = x.shape

    log_denominator = logsumexp(x, axis=1, keepdims=True)
    log_full = x - log_denominator
    log_py = -log_full[range(B), y][:, np.newaxis]

    def backward(g):
        onehot = np.eye(C)[y]
        return g * (np.exp(log_full) - onehot)

    def accuracy():
        return (log_full.argmax(1) == y).mean()

    return log_py, backward, accuracy


def cross_entropy_loss(x, y):
    """
    Cross entropy loss
    x : (Batch, Classes)
    y : Batch
    ret: Average loss and gradient function wrt x
    """
    lp, gp = logsoftmax(x, y)
    lm, gm = mean_f(lp)

    def backward(g):
        return gp(gm(g))

    return lm, backward


def final_layer(w, x, y):
    """
    Combination of a linear layer and cross entropy loss
    w : (N, Classes)
    x : (Batch, N)
    y : Batch
    ret: Average loss and gradient function wrt. w and x (and accuracy function)
    """
    l, gl = linear(w, x)
    a, ga, accuracy = logsoftmax(l, y)
    m, gm = mean_f(a)
    def backward(g):
        return gl(ga(gm(g)))
    return m, backward, accuracy


def nop(x):
    """
    Identity function
    """
    return x, lambda g: g


def linear(w, x):
    """
    Linear function
    w : (D1, D2)
    x : (B, D1)
    ret : (B, D2) and gradient function wrt. w and x
    """
    a = x @ w

    def backward(g):
        return (
            x.T @ g,
            g @ w.T,
        )

    return a, backward


def sigmoid(x):
    """
    x : Any shape
    ret : sigmoid of x, and gradient function wrt. x
    """
    sigm = expit(x)

    def backward(g):
        return g * sigm * (1 - sigm)

    return sigm, backward


def layer(w, x, nonlinearity=sigmoid):
    """
    Combination of linear layer and a nonlinearity
    w : (D1, D2)
    x : (B, D1)
    ret : (B, D2) and gradient function wrt. w and x
    """
    l, gl = linear(w, x)
    a, ga = nonlinearity(l)

    def backward(g):
        return gl(ga(g))

    return a, backward


def mlp(ws, x, y):
    """
    Multilayer perceptron with cross entropy loss
    ws : List of weights such that ws[i].shape[1] == ws[i+1].shape[0]
    x : (Batch, Features)
    y : (Batch)
    ret : cross entropy loss of the model and gradients wrt. ws
    """
    n = len(ws)
    grad = [None] * n
    acc = x

    for i in range(n-1):
        acc, grad[i] = layer(ws[i], acc, sigmoid)

    loss, grad[-1], acc = final_layer(ws[-1], acc, y)

    def backward(g):
        w_delta = [None] * n
        acc = g
        for i in reversed(range(n)):
            w_delta[i], acc = grad[i](acc)
        return w_delta

    return loss, backward, acc


def reg(ws, norm=l2):
    cost = 0
    N = len(ws)
    grads = [None]*N
    costs, grads = zip(*[norm(w) for w in ws])

    cost = sum(costs)

    def backward(g):
        return [grad(g) for grad in grads]

    return cost, backward





def init_xavier(l, r):
    return np.random.randn(l, r) * np.sqrt( 2 / (l + r))


def init_normal(l, r):
    return np.random.randn(l, r)


def mk_mlp_ws(in_dim, out_dim, *hidden):
    dims = [in_dim, *hidden, out_dim]
    ws = [init_xavier(l, r) for l, r in zip(dims, dims[1:])]
    return ws

