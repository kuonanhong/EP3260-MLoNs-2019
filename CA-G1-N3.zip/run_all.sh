#!/bin/bash

TIMEOUT=10


for LAMBDA in 0.1 0.01 0.001
do
  for LR in 0.1 0.01 0.001
  do
    python ca2.py --timeout $TIMEOUT --lambda $LAMBDA --lr $LR gd >> runs.json
    for BATCH_SIZE in 1
    do
      python ca2.py --timeout $TIMEOUT --lambda $LAMBDA --lr $LR sgd --batch_size $BATCH_SIZE >> runs.json
      python ca2.py --timeout $TIMEOUT --lambda $LAMBDA --lr $LR sag --batch_size $BATCH_SIZE >> runs.json
      for EPOCH_SIZE in 1 2 3 4 5 6 7 8 9 10
      do
        python ca2.py --timeout $TIMEOUT --lambda $LAMBDA --lr $LR svrg --batch_size $BATCH_SIZE --epoch_size $EPOCH_SIZE >> runs.json
      done
    done
  done

done
